<?php

declare(strict_types=1);

namespace App\Traits;

use App\Services\Tenant\TenantManager;
use Illuminate\Database\Eloquent\Builder;

/**
 * HasTenant - Trait for models that require tenant isolation.
 * 
 * Usage:
 * 
 * class Invoice extends Model
 * {
 *     use HasTenant;
 * 
 *     protected string $tenantColumn = 'company_id'; // Default is 'tenant_id'
 * }
 * 
 * // Tenant scoping is automatic on all queries
 * Invoice::all(); // Only returns invoices for current tenant
 */
trait HasTenant
{
    /**
     * Boot the trait.
     */
    public static function bootHasTenant(): void
    {
        // Add global scope for tenant isolation
        static::addGlobalScope('tenant', function (Builder $builder) {
            $model = new static;
            $manager = app(TenantManager::class);
            
            $entityName = $model->getTable();
            
            if ($manager->hasTenantConfig($entityName)) {
                $manager->applyScope($builder, $entityName);
            } else {
                // Apply default tenant scoping
                $column = $model->getTenantColumn();
                $tenantId = $manager->getCurrentTenantId();
                
                if ($tenantId !== null) {
                    $builder->where($column, $tenantId);
                }
            }
        });

        // Auto-set tenant on create
        static::creating(function ($model) {
            $column = $model->getTenantColumn();
            
            if (empty($model->$column)) {
                $manager = app(TenantManager::class);
                $tenantId = $manager->getCurrentTenantId();
                
                if ($tenantId !== null) {
                    $model->$column = $tenantId;
                }
            }
        });
    }

    /**
     * Get the tenant column name.
     */
    public function getTenantColumn(): string
    {
        return $this->tenantColumn ?? 'tenant_id';
    }

    /**
     * Get the tenant ID for this record.
     */
    public function getTenantId(): ?int
    {
        $column = $this->getTenantColumn();
        return $this->$column;
    }

    /**
     * Check if record belongs to current tenant.
     */
    public function belongsToCurrentTenant(): bool
    {
        $manager = app(TenantManager::class);
        return $this->getTenantId() === $manager->getCurrentTenantId();
    }

    /**
     * Scope to include all tenants (bypass tenant filtering).
     */
    public function scopeWithoutTenantScope($query)
    {
        return $query->withoutGlobalScope('tenant');
    }

    /**
     * Scope to a specific tenant.
     */
    public function scopeForTenant($query, int $tenantId)
    {
        return $query->withoutGlobalScope('tenant')
                     ->where($this->getTenantColumn(), $tenantId);
    }
}
