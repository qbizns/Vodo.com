@extends('owner::layouts.app', [
    'currentPage' => 'system/settings',
    'currentPageLabel' => 'Settings',
    'currentPageIcon' => 'settings',
])

@section('page-title', 'Settings')
@section('page-header', 'Settings')

@section('page-content')
    @include('backend.settings.index', [
        'activeSection' => $activeSection,
        'pluginsWithSettings' => $pluginsWithSettings,
        'sectionContent' => $sectionContent,
    ])
@endsection
