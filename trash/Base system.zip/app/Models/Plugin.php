<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Plugin extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'slug',
        'version',
        'description',
        'author',
        'author_url',
        'status',
        'settings',
        'requires',
        'main_class',
        'path',
        'activated_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'settings' => 'array',
        'requires' => 'array',
        'activated_at' => 'datetime',
    ];

    /**
     * Plugin status constants.
     */
    public const STATUS_INACTIVE = 'inactive';
    public const STATUS_ACTIVE = 'active';
    public const STATUS_ERROR = 'error';

    /**
     * Get the migrations for this plugin.
     */
    public function migrations(): HasMany
    {
        return $this->hasMany(PluginMigration::class);
    }

    /**
     * Check if the plugin is active.
     */
    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    /**
     * Check if the plugin is inactive.
     */
    public function isInactive(): bool
    {
        return $this->status === self::STATUS_INACTIVE;
    }

    /**
     * Check if the plugin has an error.
     */
    public function hasError(): bool
    {
        return $this->status === self::STATUS_ERROR;
    }

    /**
     * Get the full path to the plugin directory.
     */
    public function getFullPath(): string
    {
        return $this->path ?? app_path("Plugins/{$this->slug}");
    }

    /**
     * Get the main plugin class name with namespace.
     */
    public function getMainClassName(): string
    {
        if ($this->main_class) {
            return $this->main_class;
        }
        
        // Convert slug hyphens to underscores for valid PHP namespace
        $namespaceSlug = str_replace('-', '_', $this->slug);
        return "App\\Plugins\\{$namespaceSlug}\\{$this->getMainClassBaseName()}";
    }

    /**
     * Get the base name of the main class from the manifest.
     */
    protected function getMainClassBaseName(): string
    {
        $manifestPath = $this->getFullPath() . '/plugin.json';
        
        if (file_exists($manifestPath)) {
            $manifest = json_decode(file_get_contents($manifestPath), true);
            if (isset($manifest['main'])) {
                return pathinfo($manifest['main'], PATHINFO_FILENAME);
            }
        }

        // Default to StudlyCase version of slug
        return str_replace(' ', '', ucwords(str_replace('-', ' ', $this->slug))) . 'Plugin';
    }

    /**
     * Scope to get only active plugins.
     */
    public function scopeActive($query)
    {
        return $query->where('status', self::STATUS_ACTIVE);
    }

    /**
     * Scope to get only inactive plugins.
     */
    public function scopeInactive($query)
    {
        return $query->where('status', self::STATUS_INACTIVE);
    }
}
