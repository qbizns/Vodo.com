<?php

namespace App\Services\View;

use App\Models\ViewDefinition;
use App\Models\ViewExtension;
use App\Models\CompiledView;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;

class ViewRegistry
{
    protected ViewCompiler $compiler;
    protected array $runtimeViews = [];
    protected array $runtimeExtensions = [];
    protected bool $cacheEnabled;
    protected int $cacheTtl;

    public function __construct(ViewCompiler $compiler)
    {
        $this->compiler = $compiler;
        $this->cacheEnabled = config('view-system.cache.enabled', true);
        $this->cacheTtl = config('view-system.cache.ttl', 3600);
    }

    // =========================================================================
    // View Registration
    // =========================================================================

    /**
     * Register a new view
     */
    public function register(string $name, string $content, array $config = [], ?string $pluginSlug = null): ViewDefinition
    {
        $this->validateName($name);

        // Check if exists
        $existing = ViewDefinition::findByName($name);
        if ($existing) {
            // Only allow owner to update
            if ($existing->plugin_slug !== $pluginSlug) {
                throw new \RuntimeException("View '{$name}' is owned by another plugin");
            }
            return $this->update($name, $content, $config, $pluginSlug);
        }

        $view = ViewDefinition::create([
            'name' => $name,
            'slug' => $config['slug'] ?? Str::slug($name, '_'),
            'type' => $config['type'] ?? ViewDefinition::TYPE_BLADE,
            'category' => $config['category'] ?? null,
            'description' => $config['description'] ?? null,
            'content' => $content,
            'inherit_id' => $config['inherit'] ?? null,
            'priority' => $config['priority'] ?? 100,
            'config' => $config['config'] ?? null,
            'slots' => $config['slots'] ?? null,
            'plugin_slug' => $pluginSlug,
            'is_system' => $config['system'] ?? false,
            'is_active' => $config['active'] ?? true,
            'is_cacheable' => $config['cacheable'] ?? true,
            'version' => $config['version'] ?? '1.0.0',
        ]);

        // Fire hook
        do_action('view_registered', $view);
        do_action("view_{$name}_registered", $view);

        return $view;
    }

    /**
     * Update an existing view
     */
    public function update(string $name, string $content, array $config = [], ?string $pluginSlug = null): ViewDefinition
    {
        $view = ViewDefinition::findByName($name);
        if (!$view) {
            throw new \RuntimeException("View '{$name}' not found");
        }

        // Check ownership
        if ($view->plugin_slug !== $pluginSlug && !$view->is_system) {
            throw new \RuntimeException("Cannot update view '{$name}' - owned by another plugin");
        }

        $view->update([
            'content' => $content,
            'type' => $config['type'] ?? $view->type,
            'category' => $config['category'] ?? $view->category,
            'description' => $config['description'] ?? $view->description,
            'config' => array_merge($view->config ?? [], $config['config'] ?? []),
            'slots' => $config['slots'] ?? $view->slots,
            'is_active' => $config['active'] ?? $view->is_active,
            'is_cacheable' => $config['cacheable'] ?? $view->is_cacheable,
            'version' => $config['version'] ?? $view->version,
        ]);

        // Invalidate cache
        CompiledView::invalidate($name);

        do_action('view_updated', $view);

        return $view;
    }

    /**
     * Unregister a view
     */
    public function unregister(string $name, ?string $pluginSlug = null): bool
    {
        $view = ViewDefinition::findByName($name);
        if (!$view) {
            return false;
        }

        // Check ownership
        if ($view->plugin_slug !== $pluginSlug) {
            throw new \RuntimeException("Cannot unregister view '{$name}' - owned by another plugin");
        }

        // Check if system view
        if ($view->is_system) {
            throw new \RuntimeException("Cannot unregister system view '{$name}'");
        }

        // Check for dependent views
        $dependents = ViewDefinition::where('inherit_id', $name)->count();
        if ($dependents > 0) {
            throw new \RuntimeException("Cannot unregister view '{$name}' - {$dependents} view(s) inherit from it");
        }

        // Delete extensions targeting this view (if configured)
        if (config('view-system.delete_extensions_on_unregister', true)) {
            ViewExtension::where('view_name', $name)
                ->where('plugin_slug', $pluginSlug)
                ->delete();
        }

        // Invalidate cache
        CompiledView::invalidate($name);

        $view->delete();

        do_action('view_unregistered', $name, $pluginSlug);

        return true;
    }

    // =========================================================================
    // View Extension
    // =========================================================================

    /**
     * Extend a view with XPath modification
     */
    public function extend(
        string $viewName,
        string $xpath,
        string $operation,
        ?string $content = null,
        array $config = [],
        ?string $pluginSlug = null
    ): ViewExtension {
        // Generate unique name if not provided
        $name = $config['name'] ?? $this->generateExtensionName($viewName, $pluginSlug);

        // Validate operation
        $validOps = array_keys(ViewExtension::getOperations());
        if (!in_array($operation, $validOps)) {
            throw new \InvalidArgumentException("Invalid operation: {$operation}");
        }

        // Check if content is required
        if (in_array($operation, ['before', 'after', 'replace', 'inside_first', 'inside_last', 'wrap'])) {
            if (empty($content)) {
                throw new \InvalidArgumentException("Content is required for '{$operation}' operation");
            }
        }

        $extension = ViewExtension::create([
            'name' => $name,
            'view_name' => $viewName,
            'xpath' => $xpath,
            'operation' => $operation,
            'content' => $content,
            'attribute_changes' => $config['attributes'] ?? null,
            'priority' => $config['priority'] ?? 100,
            'sequence' => $config['sequence'] ?? $this->getNextSequence($viewName, $config['priority'] ?? 100),
            'conditions' => $config['conditions'] ?? null,
            'plugin_slug' => $pluginSlug,
            'is_system' => $config['system'] ?? false,
            'is_active' => $config['active'] ?? true,
            'description' => $config['description'] ?? null,
        ]);

        // Validate XPath
        if (!$extension->validateXpath()) {
            $extension->delete();
            throw new \InvalidArgumentException("Invalid XPath expression: {$xpath}");
        }

        // Invalidate cache
        CompiledView::invalidate($viewName);

        do_action('view_extended', $extension);
        do_action("view_{$viewName}_extended", $extension);

        return $extension;
    }

    /**
     * Remove an extension
     */
    public function removeExtension(string $name, ?string $pluginSlug = null): bool
    {
        $extension = ViewExtension::where('name', $name)
            ->where('plugin_slug', $pluginSlug)
            ->first();

        if (!$extension) {
            return false;
        }

        if ($extension->is_system) {
            throw new \RuntimeException("Cannot remove system extension");
        }

        $viewName = $extension->view_name;
        $extension->delete();

        // Invalidate cache
        CompiledView::invalidate($viewName);

        do_action('view_extension_removed', $name, $viewName);

        return true;
    }

    /**
     * Update extension priority/sequence
     */
    public function reorderExtension(string $name, int $priority, int $sequence = 0, ?string $pluginSlug = null): bool
    {
        $extension = ViewExtension::where('name', $name)
            ->where('plugin_slug', $pluginSlug)
            ->first();

        if (!$extension) {
            return false;
        }

        $extension->update([
            'priority' => $priority,
            'sequence' => $sequence,
        ]);

        CompiledView::invalidate($extension->view_name);

        return true;
    }

    // =========================================================================
    // View Compilation & Rendering
    // =========================================================================

    /**
     * Compile a view (apply all extensions)
     */
    public function compile(string $name, array $context = []): string
    {
        $view = ViewDefinition::findByName($name);
        if (!$view) {
            throw new \RuntimeException("View '{$name}' not found");
        }

        if (!$view->is_active) {
            throw new \RuntimeException("View '{$name}' is inactive");
        }

        // Check cache
        if ($this->cacheEnabled && $view->is_cacheable) {
            $hash = $view->computeContentHash();
            $cached = CompiledView::getCached($name, $hash);
            if ($cached) {
                return $cached->compiled_content;
            }
        }

        return $this->compiler->compile($view, $context);
    }

    /**
     * Render a view with data
     */
    public function render(string $name, array $data = [], array $context = []): string
    {
        $compiled = $this->compile($name, $context);

        // For Blade views, we need to compile and render
        $view = ViewDefinition::findByName($name);
        
        if ($view && $view->type === ViewDefinition::TYPE_BLADE) {
            return $this->renderBlade($compiled, $data);
        }

        // For HTML views, just replace simple placeholders
        if ($view && $view->type === ViewDefinition::TYPE_HTML) {
            return $this->renderHtml($compiled, $data);
        }

        return $compiled;
    }

    /**
     * Render Blade content
     */
    protected function renderBlade(string $content, array $data = []): string
    {
        // Create temporary view file
        $tempPath = storage_path('framework/views/' . md5($content) . '.blade.php');
        
        if (!file_exists($tempPath)) {
            file_put_contents($tempPath, $content);
        }

        // Get view name from path
        $viewName = 'dynamic_' . md5($content);

        // Register the view path
        View::addNamespace('dynamic', storage_path('framework/views'));

        try {
            return View::make('dynamic::' . basename($tempPath, '.blade.php'), $data)->render();
        } finally {
            // Optionally clean up temp file
            // @unlink($tempPath);
        }
    }

    /**
     * Render HTML with simple placeholder replacement
     */
    protected function renderHtml(string $content, array $data = []): string
    {
        foreach ($data as $key => $value) {
            if (is_scalar($value)) {
                $content = str_replace('{{ ' . $key . ' }}', e($value), $content);
                $content = str_replace('{{' . $key . '}}', e($value), $content);
                $content = str_replace('{!! ' . $key . ' !!}', $value, $content);
                $content = str_replace('{!!' . $key . '!!}', $value, $content);
            }
        }

        return $content;
    }

    // =========================================================================
    // Runtime Views (Non-Persistent)
    // =========================================================================

    /**
     * Register a runtime view (not persisted to database)
     */
    public function registerRuntime(string $name, string $content, array $config = []): void
    {
        $this->runtimeViews[$name] = [
            'content' => $content,
            'config' => $config,
        ];
    }

    /**
     * Register a runtime extension
     */
    public function extendRuntime(string $viewName, string $xpath, string $operation, ?string $content = null, array $config = []): void
    {
        if (!isset($this->runtimeExtensions[$viewName])) {
            $this->runtimeExtensions[$viewName] = [];
        }

        $this->runtimeExtensions[$viewName][] = [
            'xpath' => $xpath,
            'operation' => $operation,
            'content' => $content,
            'config' => $config,
        ];
    }

    // =========================================================================
    // Query Methods
    // =========================================================================

    /**
     * Get a view by name
     */
    public function get(string $name): ?ViewDefinition
    {
        return ViewDefinition::findByName($name);
    }

    /**
     * Check if view exists
     */
    public function exists(string $name): bool
    {
        return ViewDefinition::where('name', $name)->exists();
    }

    /**
     * Get all views
     */
    public function all(): Collection
    {
        return ViewDefinition::active()->orderBy('name')->get();
    }

    /**
     * Get views by category
     */
    public function getByCategory(string $category): Collection
    {
        return ViewDefinition::active()->inCategory($category)->get();
    }

    /**
     * Get views by plugin
     */
    public function getByPlugin(string $pluginSlug): Collection
    {
        return ViewDefinition::forPlugin($pluginSlug)->get();
    }

    /**
     * Get extensions for a view
     */
    public function getExtensions(string $viewName): Collection
    {
        return ViewExtension::forView($viewName)->active()->ordered()->get();
    }

    /**
     * Get extension count for a view
     */
    public function getExtensionCount(string $viewName): int
    {
        return ViewExtension::forView($viewName)->active()->count();
    }

    // =========================================================================
    // Cache Management
    // =========================================================================

    /**
     * Clear cache for a view
     */
    public function clearCache(string $name): bool
    {
        return CompiledView::invalidate($name);
    }

    /**
     * Clear all caches
     */
    public function clearAllCaches(): int
    {
        return CompiledView::invalidateAll();
    }

    /**
     * Clear caches for a plugin
     */
    public function clearPluginCaches(string $pluginSlug): int
    {
        return CompiledView::invalidateForPlugin($pluginSlug);
    }

    /**
     * Warm cache for a view
     */
    public function warmCache(string $name): bool
    {
        try {
            $this->compile($name);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Warm all caches
     */
    public function warmAllCaches(): array
    {
        $results = ['success' => 0, 'failed' => 0];

        $views = ViewDefinition::active()->cacheable()->get();
        foreach ($views as $view) {
            if ($this->warmCache($view->name)) {
                $results['success']++;
            } else {
                $results['failed']++;
            }
        }

        return $results;
    }

    // =========================================================================
    // Helper Methods
    // =========================================================================

    /**
     * Validate view name
     */
    protected function validateName(string $name): void
    {
        if (!preg_match('/^[a-z][a-z0-9_.-]*$/i', $name)) {
            throw new \InvalidArgumentException(
                "Invalid view name '{$name}'. Must start with a letter and contain only letters, numbers, underscores, dots, and hyphens."
            );
        }

        if (strlen($name) > 100) {
            throw new \InvalidArgumentException("View name must not exceed 100 characters");
        }
    }

    /**
     * Generate unique extension name
     */
    protected function generateExtensionName(string $viewName, ?string $pluginSlug): string
    {
        $base = ($pluginSlug ?? 'ext') . '_' . $viewName;
        $count = ViewExtension::where('name', 'like', $base . '%')->count();
        return $base . '_' . ($count + 1);
    }

    /**
     * Get next sequence number for priority
     */
    protected function getNextSequence(string $viewName, int $priority): int
    {
        $max = ViewExtension::where('view_name', $viewName)
            ->where('priority', $priority)
            ->max('sequence');

        return ($max ?? -1) + 1;
    }

    /**
     * Get compiler instance
     */
    public function getCompiler(): ViewCompiler
    {
        return $this->compiler;
    }

    /**
     * Get cache statistics
     */
    public function getCacheStats(): array
    {
        return CompiledView::getStats();
    }
}
