<?php

namespace App\Services\Plugins;

use App\Models\Plugin;
use App\Services\Plugins\Contracts\PluginInterface;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

class PluginManager
{
    /**
     * Loaded plugin instances.
     *
     * @var array<string, PluginInterface>
     */
    protected array $loadedPlugins = [];

    /**
     * Create a new plugin manager instance.
     */
    public function __construct(
        protected PluginInstaller $installer,
        protected PluginMigrator $migrator,
        protected HookManager $hooks
    ) {}

    /**
     * Get all plugins from the database.
     */
    public function all(): Collection
    {
        return Plugin::orderBy('name')->get();
    }

    /**
     * Get all active plugins.
     */
    public function getActive(): Collection
    {
        return Plugin::active()->orderBy('name')->get();
    }

    /**
     * Get all inactive plugins.
     */
    public function getInactive(): Collection
    {
        return Plugin::inactive()->orderBy('name')->get();
    }

    /**
     * Find a plugin by slug.
     */
    public function find(string $slug): ?Plugin
    {
        return Plugin::where('slug', $slug)->first();
    }

    /**
     * Find a plugin by slug or fail.
     */
    public function findOrFail(string $slug): Plugin
    {
        return Plugin::where('slug', $slug)->firstOrFail();
    }

    /**
     * Install a plugin from an uploaded ZIP file.
     *
     * @throws \Exception
     */
    public function install(UploadedFile $zipFile): Plugin
    {
        return $this->installer->install($zipFile);
    }

    /**
     * Activate a plugin.
     *
     * @throws \Exception
     */
    public function activate(string $slug): Plugin
    {
        $plugin = $this->findOrFail($slug);

        if ($plugin->isActive()) {
            return $plugin;
        }

        try {
            // Load and instantiate the plugin class
            $instance = $this->loadPluginInstance($plugin);

            // Register the plugin
            $instance->register();

            // Run migrations
            $this->migrator->runMigrations($plugin);

            // Boot the plugin
            $instance->boot();

            // Call activate hook
            $instance->activate();

            // Update database status
            $plugin->update([
                'status' => Plugin::STATUS_ACTIVE,
                'activated_at' => now(),
            ]);

            // Fire activation hook
            $this->hooks->doAction('plugin_activated', $plugin, $instance);

            // Store loaded instance
            $this->loadedPlugins[$slug] = $instance;

            return $plugin->fresh();
        } catch (\Throwable $e) {
            // Mark plugin as error state
            $plugin->update(['status' => Plugin::STATUS_ERROR]);
            
            Log::error("Plugin activation failed: {$slug}", [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            throw $e;
        }
    }

    /**
     * Deactivate a plugin.
     *
     * @throws \Exception
     */
    public function deactivate(string $slug): Plugin
    {
        $plugin = $this->findOrFail($slug);

        if ($plugin->isInactive()) {
            return $plugin;
        }

        try {
            // Load instance if available
            $instance = $this->loadedPlugins[$slug] ?? $this->loadPluginInstance($plugin);

            // Call deactivate hook
            $instance->deactivate();

            // Update database status
            $plugin->update([
                'status' => Plugin::STATUS_INACTIVE,
                'activated_at' => null,
            ]);

            // Fire deactivation hook
            $this->hooks->doAction('plugin_deactivated', $plugin, $instance);

            // Remove from loaded plugins
            unset($this->loadedPlugins[$slug]);

            return $plugin->fresh();
        } catch (\Throwable $e) {
            Log::error("Plugin deactivation failed: {$slug}", [
                'error' => $e->getMessage(),
            ]);

            throw $e;
        }
    }

    /**
     * Uninstall a plugin completely.
     *
     * @throws \Exception
     */
    public function uninstall(string $slug): bool
    {
        $plugin = $this->findOrFail($slug);

        try {
            // Deactivate first if active
            if ($plugin->isActive()) {
                $this->deactivate($slug);
                $plugin->refresh();
            }

            // Load instance for uninstall hook
            $instance = $this->loadPluginInstance($plugin);

            // Call uninstall hook
            $instance->uninstall();

            // Rollback all migrations
            $this->migrator->rollbackAllMigrations($plugin);

            // Fire uninstall hook
            $this->hooks->doAction('plugin_uninstalled', $plugin);

            // Delete plugin files
            $this->installer->deletePluginFiles($plugin);

            // Delete from database
            $plugin->delete();

            return true;
        } catch (\Throwable $e) {
            Log::error("Plugin uninstall failed: {$slug}", [
                'error' => $e->getMessage(),
            ]);

            throw $e;
        }
    }

    /**
     * Load and instantiate a plugin class.
     *
     * @throws \Exception
     */
    public function loadPluginInstance(Plugin $plugin): PluginInterface
    {
        $className = $plugin->getMainClassName();

        // Require the main file if class doesn't exist
        if (!class_exists($className)) {
            $mainFile = $this->getMainFilePath($plugin);
            
            if (!file_exists($mainFile)) {
                throw new \Exception("Plugin main file not found: {$mainFile}");
            }

            require_once $mainFile;

            if (!class_exists($className)) {
                throw new \Exception("Plugin class not found: {$className}");
            }
        }

        $instance = new $className();

        if (!$instance instanceof PluginInterface) {
            throw new \Exception("Plugin class must implement PluginInterface: {$className}");
        }

        $instance->setPlugin($plugin);

        return $instance;
    }

    /**
     * Get the path to the plugin's main file.
     */
    protected function getMainFilePath(Plugin $plugin): string
    {
        $manifestPath = $plugin->getFullPath() . '/plugin.json';
        
        if (file_exists($manifestPath)) {
            $manifest = json_decode(file_get_contents($manifestPath), true);
            if (isset($manifest['main'])) {
                return $plugin->getFullPath() . '/' . $manifest['main'];
            }
        }

        // Default main file name
        $className = str_replace(' ', '', ucwords(str_replace('-', ' ', $plugin->slug)));
        return $plugin->getFullPath() . "/{$className}Plugin.php";
    }

    /**
     * Get a loaded plugin instance.
     */
    public function getLoadedPlugin(string $slug): ?PluginInterface
    {
        return $this->loadedPlugins[$slug] ?? null;
    }

    /**
     * Get all loaded plugin instances.
     *
     * @return array<string, PluginInterface>
     */
    public function getLoadedPlugins(): array
    {
        return $this->loadedPlugins;
    }

    /**
     * Check if a plugin is loaded.
     */
    public function isLoaded(string $slug): bool
    {
        return isset($this->loadedPlugins[$slug]);
    }

    /**
     * Store a loaded plugin instance.
     */
    public function setLoadedPlugin(string $slug, PluginInterface $instance): void
    {
        $this->loadedPlugins[$slug] = $instance;
    }

    /**
     * Get the hook manager.
     */
    public function hooks(): HookManager
    {
        return $this->hooks;
    }

    /**
     * Get the plugin installer.
     */
    public function installer(): PluginInstaller
    {
        return $this->installer;
    }

    /**
     * Get the plugin migrator.
     */
    public function migrator(): PluginMigrator
    {
        return $this->migrator;
    }

    /**
     * Refresh a plugin (reload from disk).
     */
    public function refresh(string $slug): Plugin
    {
        $plugin = $this->findOrFail($slug);
        
        // Re-read manifest
        $manifestPath = $plugin->getFullPath() . '/plugin.json';
        
        if (file_exists($manifestPath)) {
            $manifest = json_decode(file_get_contents($manifestPath), true);
            
            $plugin->update([
                'name' => $manifest['name'] ?? $plugin->name,
                'version' => $manifest['version'] ?? $plugin->version,
                'description' => $manifest['description'] ?? $plugin->description,
                'author' => $manifest['author'] ?? $plugin->author,
                'author_url' => $manifest['author_url'] ?? $plugin->author_url,
                'requires' => $manifest['requires'] ?? $plugin->requires,
            ]);
        }

        return $plugin->fresh();
    }
}
