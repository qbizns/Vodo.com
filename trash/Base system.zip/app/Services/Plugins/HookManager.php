<?php

namespace App\Services\Plugins;

class HookManager
{
    /**
     * Registered actions.
     *
     * @var array<string, array<int, array<callable>>>
     */
    protected array $actions = [];

    /**
     * Registered filters.
     *
     * @var array<string, array<int, array<callable>>>
     */
    protected array $filters = [];

    /**
     * Current filter being applied (for nested filters).
     *
     * @var array<string>
     */
    protected array $currentFilter = [];

    /**
     * Default priority for hooks.
     */
    public const DEFAULT_PRIORITY = 10;

    /**
     * Register an action hook.
     *
     * @param string $hook The name of the action hook
     * @param callable $callback The callback to execute
     * @param int $priority The priority (lower = earlier execution)
     * @return void
     */
    public function addAction(string $hook, callable $callback, int $priority = self::DEFAULT_PRIORITY): void
    {
        if (!isset($this->actions[$hook])) {
            $this->actions[$hook] = [];
        }

        if (!isset($this->actions[$hook][$priority])) {
            $this->actions[$hook][$priority] = [];
        }

        $this->actions[$hook][$priority][] = $callback;
    }

    /**
     * Execute all callbacks registered for an action hook.
     *
     * @param string $hook The name of the action hook
     * @param mixed ...$args Arguments to pass to the callbacks
     * @return void
     */
    public function doAction(string $hook, mixed ...$args): void
    {
        if (!isset($this->actions[$hook])) {
            return;
        }

        $callbacks = $this->actions[$hook];
        ksort($callbacks);

        foreach ($callbacks as $priorityCallbacks) {
            foreach ($priorityCallbacks as $callback) {
                call_user_func_array($callback, $args);
            }
        }
    }

    /**
     * Check if an action hook has any registered callbacks.
     *
     * @param string $hook The name of the action hook
     * @param callable|null $callback Optional specific callback to check for
     * @return bool
     */
    public function hasAction(string $hook, ?callable $callback = null): bool
    {
        if (!isset($this->actions[$hook])) {
            return false;
        }

        if ($callback === null) {
            return true;
        }

        foreach ($this->actions[$hook] as $priorityCallbacks) {
            if (in_array($callback, $priorityCallbacks, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Remove an action hook callback.
     *
     * @param string $hook The name of the action hook
     * @param callable $callback The callback to remove
     * @param int $priority The priority it was registered with
     * @return bool
     */
    public function removeAction(string $hook, callable $callback, int $priority = self::DEFAULT_PRIORITY): bool
    {
        if (!isset($this->actions[$hook][$priority])) {
            return false;
        }

        $key = array_search($callback, $this->actions[$hook][$priority], true);
        
        if ($key !== false) {
            unset($this->actions[$hook][$priority][$key]);
            return true;
        }

        return false;
    }

    /**
     * Remove all callbacks for an action hook.
     *
     * @param string $hook The name of the action hook
     * @param int|null $priority Optional specific priority to remove
     * @return bool
     */
    public function removeAllActions(string $hook, ?int $priority = null): bool
    {
        if (!isset($this->actions[$hook])) {
            return false;
        }

        if ($priority === null) {
            unset($this->actions[$hook]);
        } else {
            unset($this->actions[$hook][$priority]);
        }

        return true;
    }

    /**
     * Register a filter hook.
     *
     * @param string $hook The name of the filter hook
     * @param callable $callback The callback to execute
     * @param int $priority The priority (lower = earlier execution)
     * @return void
     */
    public function addFilter(string $hook, callable $callback, int $priority = self::DEFAULT_PRIORITY): void
    {
        if (!isset($this->filters[$hook])) {
            $this->filters[$hook] = [];
        }

        if (!isset($this->filters[$hook][$priority])) {
            $this->filters[$hook][$priority] = [];
        }

        $this->filters[$hook][$priority][] = $callback;
    }

    /**
     * Apply all filters registered for a hook and return the modified value.
     *
     * @param string $hook The name of the filter hook
     * @param mixed $value The value to filter
     * @param mixed ...$args Additional arguments to pass to the callbacks
     * @return mixed The filtered value
     */
    public function applyFilters(string $hook, mixed $value, mixed ...$args): mixed
    {
        if (!isset($this->filters[$hook])) {
            return $value;
        }

        $this->currentFilter[] = $hook;

        $callbacks = $this->filters[$hook];
        ksort($callbacks);

        foreach ($callbacks as $priorityCallbacks) {
            foreach ($priorityCallbacks as $callback) {
                $value = call_user_func_array($callback, array_merge([$value], $args));
            }
        }

        array_pop($this->currentFilter);

        return $value;
    }

    /**
     * Check if a filter hook has any registered callbacks.
     *
     * @param string $hook The name of the filter hook
     * @param callable|null $callback Optional specific callback to check for
     * @return bool
     */
    public function hasFilter(string $hook, ?callable $callback = null): bool
    {
        if (!isset($this->filters[$hook])) {
            return false;
        }

        if ($callback === null) {
            return true;
        }

        foreach ($this->filters[$hook] as $priorityCallbacks) {
            if (in_array($callback, $priorityCallbacks, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Remove a filter hook callback.
     *
     * @param string $hook The name of the filter hook
     * @param callable $callback The callback to remove
     * @param int $priority The priority it was registered with
     * @return bool
     */
    public function removeFilter(string $hook, callable $callback, int $priority = self::DEFAULT_PRIORITY): bool
    {
        if (!isset($this->filters[$hook][$priority])) {
            return false;
        }

        $key = array_search($callback, $this->filters[$hook][$priority], true);
        
        if ($key !== false) {
            unset($this->filters[$hook][$priority][$key]);
            return true;
        }

        return false;
    }

    /**
     * Remove all callbacks for a filter hook.
     *
     * @param string $hook The name of the filter hook
     * @param int|null $priority Optional specific priority to remove
     * @return bool
     */
    public function removeAllFilters(string $hook, ?int $priority = null): bool
    {
        if (!isset($this->filters[$hook])) {
            return false;
        }

        if ($priority === null) {
            unset($this->filters[$hook]);
        } else {
            unset($this->filters[$hook][$priority]);
        }

        return true;
    }

    /**
     * Get the name of the current filter being applied.
     *
     * @return string|null
     */
    public function currentFilter(): ?string
    {
        return end($this->currentFilter) ?: null;
    }

    /**
     * Check if a specific filter is currently being applied.
     *
     * @param string|null $hook The hook to check, or null to check if any filter is running
     * @return bool
     */
    public function doingFilter(?string $hook = null): bool
    {
        if ($hook === null) {
            return !empty($this->currentFilter);
        }

        return in_array($hook, $this->currentFilter, true);
    }

    /**
     * Get all registered actions.
     *
     * @return array
     */
    public function getActions(): array
    {
        return $this->actions;
    }

    /**
     * Get all registered filters.
     *
     * @return array
     */
    public function getFilters(): array
    {
        return $this->filters;
    }

    /**
     * Clear all registered hooks.
     *
     * @return void
     */
    public function clear(): void
    {
        $this->actions = [];
        $this->filters = [];
        $this->currentFilter = [];
    }
}
