<?php $__env->startSection('title'); ?>
    <?php echo $__env->yieldContent('page-title', 'Dashboard'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->yieldContent('page-header', 'Dashboard'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldContent('page-content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('command-bar'); ?>
    <?php echo $__env->yieldContent('page-command-bar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-actions'); ?>
    <?php echo $__env->yieldContent('page-header-actions'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', [
    'guard' => 'admin',
    'modulePrefix' => 'admin',
    'brandName' => 'Vodo Admin',
    'version' => 'v.1.0.0',
    'baseUrl' => '',
    'currentPage' => $currentPage ?? 'dashboard',
    'currentPageLabel' => $currentPageLabel ?? 'Dashboard',
    'currentPageIcon' => $currentPageIcon ?? 'layoutDashboard',
    'splashTitle' => 'VODO',
    'splashSubtitle' => 'Admin',
    'splashVersion' => 'Version 1.0.0',
    'splashCopyright' => '© ' . date('Y') . ' VODO Systems',
    'profileUrl' => '/profile',
    'settingsUrl' => '/settings',
    'logoutUrl' => route('admin.logout'),
    'navBoardUrl' => route('admin.navigation-board'),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/layouts/app.blade.php ENDPATH**/ ?>