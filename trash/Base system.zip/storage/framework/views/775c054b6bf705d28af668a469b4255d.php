
<div class="modal-overlay" id="addWidgetModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3>Add Widget</h3>
            <button type="button" class="modal-close" id="closeWidgetModal">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'x'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </button>
        </div>
        <div class="modal-body">
            <?php if(count($unusedWidgets) > 0): ?>
                <div class="widget-list">
                    <?php $__currentLoopData = $unusedWidgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widgetId => $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="widget-option" data-widget-id="<?php echo e($widgetId); ?>" data-plugin-slug="<?php echo e($widget['plugin_slug'] ?? ''); ?>">
                            <div class="widget-option-icon">
                                <?php echo $__env->make('backend.partials.icon', ['icon' => $widget['icon'] ?? 'box'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                            <div class="widget-option-info">
                                <h4><?php echo e($widget['title'] ?? 'Widget'); ?></h4>
                                <p><?php echo e($widget['description'] ?? ''); ?></p>
                                <?php if(isset($widget['plugin_name'])): ?>
                                    <span class="widget-option-plugin"><?php echo e($widget['plugin_name']); ?></span>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="btn-add-this-widget">
                                <?php echo $__env->make('backend.partials.icon', ['icon' => 'plus'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="modal-empty">
                    <p>All available widgets have been added to this dashboard.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /var/www/resources/views/backend/dashboard/partials/add-widget-modal.blade.php ENDPATH**/ ?>