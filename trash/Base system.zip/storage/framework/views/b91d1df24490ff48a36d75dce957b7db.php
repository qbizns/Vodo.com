<?php $__env->startSection('page-title', 'Plugins Management'); ?>
<?php $__env->startSection('page-header', 'Plugins Management'); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'checkCircle'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-error">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'alertCircle'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <div class="plugins-container">
        <?php if($plugins->isEmpty()): ?>
            <div class="empty-state">
                <h3>Upload Plugin</h3>
                
                <div class="upload-section">
                    <form action="<?php echo e(route('admin.plugins.upload')); ?>" method="POST" enctype="multipart/form-data" class="upload-form-inline" id="uploadForm">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="plugin" id="pluginFile" accept=".zip" required class="file-input-inline">
                        <div class="file-selected" id="fileSelectedName" style="display: none;">
                            <span id="fileNameDisplay"></span>
                        </div>
                        <button type="submit" class="btn-large" id="uploadBtn">
                            Upload & Install
                        </button>
                    </form>
                    <p class="upload-hint">Maximum file size: <?php echo e(config('plugins.max_upload_size', 10240) / 1024); ?>MB</p>
                </div>
            </div>
        <?php else: ?>
            
            <div style="margin-bottom: 32px; padding: 24px; background: #f9f9f9; border-radius: 8px;">
                <form action="<?php echo e(route('admin.plugins.upload')); ?>" method="POST" enctype="multipart/form-data" style="display: flex; gap: 12px; align-items: center;">
                    <?php echo csrf_field(); ?>
                    <input type="file" name="plugin" id="pluginFile" accept=".zip" required style="flex: 1; padding: 12px; font-size: 14px; background: white; border: none; border-radius: 6px;">
                    <button type="submit" class="btn-large" style="width: auto; padding: 12px 24px;">
                        Upload & Install
                    </button>
                </form>
            </div>

            
            <div class="plugins-grid">
                <?php $__currentLoopData = $plugins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plugin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="plugin-card">
                        <div class="plugin-header">
                            <h3 class="plugin-name"><?php echo e($plugin->name); ?></h3>
                            <div class="plugin-status-badge <?php echo e($plugin->status); ?>">
                                <?php if($plugin->isActive()): ?>
                                    Active
                                <?php elseif($plugin->hasError()): ?>
                                    Error
                                <?php else: ?>
                                    Inactive
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="plugin-body">
                            <p class="plugin-version">Version <?php echo e($plugin->version); ?></p>
                            <?php if($plugin->description): ?>
                                <p class="plugin-description"><?php echo e(Str::limit($plugin->description, 150)); ?></p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="plugin-actions">
                            <?php if($plugin->isActive()): ?>
                                <form action="<?php echo e(route('admin.plugins.deactivate', $plugin->slug)); ?>" method="POST" class="inline-form">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-secondary">
                                        Deactivate
                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('admin.plugins.activate', $plugin->slug)); ?>" method="POST" class="inline-form">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success">
                                        Activate
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <form action="<?php echo e(route('admin.plugins.destroy', $plugin->slug)); ?>" method="POST" class="inline-form" 
                                  onsubmit="return confirm('Uninstall this plugin?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    Uninstall
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.plugins.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('backend.plugins.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin::layouts.app', [
    'currentPage' => 'system/plugins',
    'currentPageLabel' => 'Plugins Management',
    'currentPageIcon' => 'plug',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/plugins/index.blade.php ENDPATH**/ ?>