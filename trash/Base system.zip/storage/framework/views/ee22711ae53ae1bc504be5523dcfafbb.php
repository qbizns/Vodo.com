<?php $__env->startSection('page-title', 'Settings'); ?>
<?php $__env->startSection('page-header', 'Settings'); ?>

<?php $__env->startSection('page-content'); ?>
    <?php echo $__env->make('backend.settings.index', [
        'activeSection' => $activeSection,
        'pluginsWithSettings' => $pluginsWithSettings,
        'sectionContent' => $sectionContent,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.app', [
    'currentPage' => 'system/settings',
    'currentPageLabel' => 'Settings',
    'currentPageIcon' => 'settings',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/settings/index.blade.php ENDPATH**/ ?>