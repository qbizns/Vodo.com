<?php $__env->startPush('styles'); ?>
<style>
    .plugins-container {
        padding: 40px;
        max-width: 900px;
        margin: 0 auto;
    }

    /* Simple Empty State */
    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state h3 {
        margin: 0 0 40px;
        font-size: 24px;
        font-weight: 600;
        color: #1a1a1a;
    }

    /* Simple Upload Form */
    .upload-section {
        max-width: 500px;
        margin: 0 auto;
    }

    .upload-form-inline {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .file-input-inline {
        width: 100%;
        padding: 16px;
        font-size: 16px;
        background: #f5f5f5;
        border: none;
        border-radius: 8px;
        cursor: pointer;
    }

    .file-input-inline:hover {
        background: #eeeeee;
    }

    .file-selected {
        padding: 12px;
        background: #e8f5e9;
        border-radius: 8px;
        font-size: 14px;
        color: #2e7d32;
        text-align: left;
    }

    .btn-large {
        width: 100%;
        padding: 16px;
        font-size: 16px;
        font-weight: 600;
        background: #3b82f6;
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background 0.2s;
    }

    .btn-large:hover {
        background: #2563eb;
    }

    .btn-large:disabled {
        background: #9ca3af;
        cursor: not-allowed;
    }

    .upload-hint {
        margin-top: 10px;
        font-size: 13px;
        color: #666;
    }

    /* Simple Plugin List */
    .plugins-grid {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .plugin-card {
        background: #f9f9f9;
        border-radius: 8px;
        padding: 24px;
    }

    .plugin-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
    }

    .plugin-name {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
        color: #1a1a1a;
    }

    .plugin-status-badge {
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
    }

    .plugin-status-badge.active {
        background: #d1fae5;
        color: #065f46;
    }

    .plugin-status-badge.inactive {
        background: #f1f5f9;
        color: #475569;
    }

    .plugin-body {
        margin-bottom: 16px;
    }

    .plugin-version {
        margin: 8px 0;
        font-size: 14px;
        color: #666;
    }

    .plugin-description {
        margin: 8px 0;
        font-size: 14px;
        color: #666;
        line-height: 1.5;
    }

    .plugin-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }

    .btn {
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: opacity 0.2s;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .btn:hover {
        opacity: 0.9;
    }

    .btn-success {
        background: #10b981;
        color: white;
    }

    .btn-secondary {
        background: #e5e7eb;
        color: #374151;
    }

    .btn-danger {
        background: #ef4444;
        color: white;
    }

    .btn-outline {
        background: transparent;
        color: #3b82f6;
        border: 1px solid #3b82f6;
    }

    .btn-outline:hover {
        background: #3b82f6;
        color: white;
    }

    .btn svg {
        width: 16px;
        height: 16px;
    }

    .inline-form {
        display: inline;
    }

    /* Simple Alerts */
    .alert {
        padding: 16px;
        border-radius: 8px;
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
    }

    .alert-error {
        background: #fee2e2;
        color: #991b1b;
    }

    .alert svg {
        width: 20px;
        height: 20px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/resources/views/backend/plugins/styles.blade.php ENDPATH**/ ?>