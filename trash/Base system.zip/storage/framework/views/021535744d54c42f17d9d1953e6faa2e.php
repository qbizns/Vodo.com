<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - <?php echo e($brandName ?? 'VODO'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div id="app" class="flex flex-col h-screen" style="background-color: var(--bg-window); font-family: var(--font-family-base);">
        
        
        <?php echo $__env->make('backend.partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="flex flex-1" style="overflow: hidden;">
            
            <?php echo $__env->make('backend.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <div class="flex-1 flex flex-col" style="background-color: var(--bg-surface-1);">
                
                <?php if(!($hidePageTitle ?? false)): ?>
                <div class="page-title-bar flex items-center justify-between">
                    <h2 id="pageTitle" class="page-title"><?php echo $__env->yieldContent('header', 'Dashboard'); ?></h2>
                    <?php if (! empty(trim($__env->yieldContent('header-actions')))): ?>
                        <div class="flex items-center" style="gap: var(--spacing-3);">
                            <?php echo $__env->yieldContent('header-actions'); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                
                <div id="pageContent" class="page-content flex-1 overflow-y-auto">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>

                
                <?php if (! empty(trim($__env->yieldContent('command-bar')))): ?>
                <div class="command-bar flex items-center justify-between">
                    <?php echo $__env->yieldContent('command-bar'); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div id="overlay" class="overlay" style="display: none;"></div>

    
    <script>
        window.BackendConfig = {
            modulePrefix: '<?php echo e($modulePrefix ?? ""); ?>',
            baseUrl: '<?php echo e($baseUrl ?? ""); ?>',
            csrfToken: '<?php echo e(csrf_token()); ?>',
            currentPage: '<?php echo e($currentPage ?? "dashboard"); ?>',
            currentPageLabel: '<?php echo e($currentPageLabel ?? "Dashboard"); ?>',
            currentPageIcon: '<?php echo e($currentPageIcon ?? "layoutDashboard"); ?>',
            navGroups: <?php echo json_encode($navGroups ?? [], 15, 512) ?>
        };
    </script>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="<?php echo e(asset('backend/js/main.js')); ?>"></script>
    
    
    <?php if(isset($notifications) && count($notifications) > 0): ?>
    <script>
        $(document).ready(function() {
            window.setNotifications(<?php echo json_encode($notifications, 15, 512) ?>);
        });
    </script>
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/resources/views/backend/layouts/app.blade.php ENDPATH**/ ?>