
<div class="widget-list-items" data-widget-id="<?php echo e($widget->widget_id); ?>">
    
    <div class="list-placeholder">
        <span>Loading items...</span>
    </div>
</div>
<?php /**PATH /var/www/resources/views/backend/dashboard/widgets/list.blade.php ENDPATH**/ ?>