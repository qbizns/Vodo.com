

<div class="settings-section">
    <div class="settings-section-header" style="display: none !important; visibility: hidden;">
        <h2>General Settings</h2>
        <p>Configure your application's basic settings</p>
    </div>

    <form action="<?php echo e($saveUrl); ?>" method="POST" class="settings-form" id="generalSettingsForm">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $definitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="settings-card">
                <div class="settings-card-header">
                    <h3><?php echo e($group['title']); ?></h3>
                    <?php if(isset($group['description'])): ?>
                        <p><?php echo e($group['description']); ?></p>
                    <?php endif; ?>
                </div>

                <div class="settings-card-body">
                    <?php $__currentLoopData = $group['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldKey => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="settings-field <?php echo e($field['type'] === 'toggle' ? 'settings-field-toggle' : ''); ?>">
                            <div class="settings-field-label">
                                <label for="<?php echo e($fieldKey); ?>"><?php echo e($field['label']); ?></label>
                                <?php if(isset($field['description'])): ?>
                                    <span class="settings-field-description"><?php echo e($field['description']); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="settings-field-input">
                                <?php
                                    $value = $values[$fieldKey] ?? $field['default'] ?? '';
                                ?>

                                <?php switch($field['type']):
                                    case ('text'): ?>
                                    <?php case ('email'): ?>
                                        <input 
                                            type="<?php echo e($field['type']); ?>" 
                                            name="<?php echo e($fieldKey); ?>" 
                                            id="<?php echo e($fieldKey); ?>" 
                                            value="<?php echo e($value); ?>"
                                            class="settings-input"
                                            <?php if(isset($field['placeholder'])): ?> placeholder="<?php echo e($field['placeholder']); ?>" <?php endif; ?>
                                        >
                                        <?php break; ?>

                                    <?php case ('number'): ?>
                                        <input 
                                            type="number" 
                                            name="<?php echo e($fieldKey); ?>" 
                                            id="<?php echo e($fieldKey); ?>" 
                                            value="<?php echo e($value); ?>"
                                            class="settings-input settings-input-number"
                                            <?php if(isset($field['min'])): ?> min="<?php echo e($field['min']); ?>" <?php endif; ?>
                                            <?php if(isset($field['max'])): ?> max="<?php echo e($field['max']); ?>" <?php endif; ?>
                                        >
                                        <?php break; ?>

                                    <?php case ('select'): ?>
                                        <select name="<?php echo e($fieldKey); ?>" id="<?php echo e($fieldKey); ?>" class="settings-select">
                                            <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($optionKey); ?>" <?php echo e($value == $optionKey ? 'selected' : ''); ?>>
                                                    <?php echo e($optionLabel); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php break; ?>

                                    <?php case ('toggle'): ?>
                                        <label class="toggle-switch">
                                            <input 
                                                type="checkbox" 
                                                name="<?php echo e($fieldKey); ?>" 
                                                id="<?php echo e($fieldKey); ?>"
                                                value="1"
                                                <?php echo e($value ? 'checked' : ''); ?>

                                            >
                                            <span class="toggle-slider"></span>
                                        </label>
                                        <?php break; ?>

                                    <?php case ('textarea'): ?>
                                        <textarea 
                                            name="<?php echo e($fieldKey); ?>" 
                                            id="<?php echo e($fieldKey); ?>" 
                                            class="settings-textarea"
                                            rows="3"
                                        ><?php echo e($value); ?></textarea>
                                        <?php break; ?>

                                    <?php default: ?>
                                        <input 
                                            type="text" 
                                            name="<?php echo e($fieldKey); ?>" 
                                            id="<?php echo e($fieldKey); ?>" 
                                            value="<?php echo e($value); ?>"
                                            class="settings-input"
                                        >
                                <?php endswitch; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="settings-actions">
            <button type="submit" class="btn-primary">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                Save Settings
            </button>
        </div>
    </form>
</div>
<?php /**PATH /var/www/resources/views/backend/settings/partials/general.blade.php ENDPATH**/ ?>