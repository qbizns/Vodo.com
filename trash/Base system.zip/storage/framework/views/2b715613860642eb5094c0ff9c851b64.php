
<div id="topBar" class="flex items-center justify-between" style="height: 48px; background-color: #2B2B2B; border-bottom: 1px solid #1A1A1A; padding: 0 var(--spacing-4);">
    
    <div class="flex items-center flex-1" style="gap: var(--spacing-4); min-width: 0; overflow: hidden;">
        <div class="flex items-center" style="gap: var(--spacing-4); flex-shrink: 0;">
            <div style="font-size: 15px; font-weight: var(--font-weight-semibold); color: #FFFFFF; letter-spacing: -0.02em;">
                <?php echo e($brandName ?? 'VODO'); ?>

            </div>
            <div style="width: 1px; height: 20px; background-color: #404040;"></div>
            <div style="font-size: var(--text-caption); color: #A0A0A0;"><?php echo e($version ?? 'v.1.0.0'); ?></div>
        </div>

        
        <div id="tabsContainer" 
             class="flex items-center" 
             style="gap: 2px; margin-left: var(--spacing-4); overflow: hidden; flex: 1 1 auto; min-width: 0;"
             data-current-page="<?php echo e($currentPage ?? 'dashboard'); ?>"
             data-current-label="<?php echo e($currentPageLabel ?? 'Dashboard'); ?>"
             data-current-icon="<?php echo e($currentPageIcon ?? 'layoutDashboard'); ?>"
             data-base-url="<?php echo e($baseUrl ?? ''); ?>">
            
        </div>
    </div>

    
    <div class="flex items-center" style="gap: var(--spacing-2); flex-shrink: 0;">
        <button class="topbar-icon-btn" title="Search">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
        </button>
        <button class="topbar-icon-btn" title="Help">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
        </button>
        
        
        <?php echo $__env->make('backend.partials.notifications', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div style="width: 1px; height: 20px; background-color: #404040; margin: 0 var(--spacing-2);"></div>

        
        <?php echo $__env->make('backend.partials.user-menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php /**PATH /var/www/resources/views/backend/partials/topbar.blade.php ENDPATH**/ ?>