<?php $__env->startSection('page-title', 'Navigation Board'); ?>
<?php $__env->startSection('page-header', 'Navigation Board'); ?>

<?php $__env->startSection('page-content'); ?>
    <?php echo $__env->make('backend.pages.navigation-board', [
        'allNavGroups' => $allNavGroups,
        'visibleItems' => $visibleItems,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.app', [
    'currentPage' => 'navigation-board',
    'currentPageLabel' => 'Navigation Board',
    'currentPageIcon' => 'layoutDashboard',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/navigation-board.blade.php ENDPATH**/ ?>