
<div class="widget" 
     data-widget-id="<?php echo e($widget->widget_id); ?>"
     data-plugin-slug="<?php echo e($widget->plugin_slug ?? ''); ?>"
     data-position="<?php echo e($widget->position); ?>"
     data-col="<?php echo e($widget->col); ?>"
     data-row="<?php echo e($widget->row); ?>"
     data-width="<?php echo e($widget->width); ?>"
     data-height="<?php echo e($widget->height); ?>"
     style="grid-column: span <?php echo e($widget->width); ?>; grid-row: span <?php echo e($widget->height); ?>;">
    
    
    <div class="widget-header">
        <div class="widget-drag-handle">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'gripVertical'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="widget-title-group">
            <span class="widget-icon">
                <?php echo $__env->make('backend.partials.icon', ['icon' => $widget->definition['icon'] ?? 'box'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </span>
            <h4 class="widget-title"><?php echo e($widget->definition['title'] ?? 'Widget'); ?></h4>
        </div>
        <div class="widget-actions">
            <?php if($widget->definition['refreshable'] ?? false): ?>
                <button type="button" class="widget-action-btn widget-refresh" title="Refresh">
                    <?php echo $__env->make('backend.partials.icon', ['icon' => 'refreshCw'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>
            <?php endif; ?>
            <?php if($widget->definition['configurable'] ?? false): ?>
                <button type="button" class="widget-action-btn widget-settings" title="Settings">
                    <?php echo $__env->make('backend.partials.icon', ['icon' => 'settings'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>
            <?php endif; ?>
            <button type="button" class="widget-action-btn widget-remove" title="Remove">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'x'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </button>
        </div>
    </div>

    
    <div class="widget-content" data-component="<?php echo e($widget->definition['component'] ?? 'custom'); ?>">
        <div class="widget-loading">
            <div class="widget-spinner"></div>
        </div>
        <div class="widget-body">
            <?php
                $component = $widget->definition['component'] ?? 'custom';
            ?>
            
            <?php switch($component):
                case ('stats'): ?>
                    <?php echo $__env->make('backend.dashboard.widgets.stats', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php break; ?>
                <?php case ('chart'): ?>
                    <?php echo $__env->make('backend.dashboard.widgets.chart', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php break; ?>
                <?php case ('list'): ?>
                    <?php echo $__env->make('backend.dashboard.widgets.list', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php break; ?>
                <?php case ('table'): ?>
                    <?php echo $__env->make('backend.dashboard.widgets.table', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php break; ?>
                <?php case ('welcome'): ?>
                    <?php echo $__env->make('backend.dashboard.widgets.welcome', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php break; ?>
                <?php case ('quick-actions'): ?>
                    <?php echo $__env->make('backend.dashboard.widgets.quick-actions', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php break; ?>
                <?php default: ?>
                    <?php echo $__env->make('backend.dashboard.widgets.custom', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endswitch; ?>
        </div>
    </div>

    
    <div class="widget-resize-handle"></div>
</div>
<?php /**PATH /var/www/resources/views/backend/dashboard/widgets/wrapper.blade.php ENDPATH**/ ?>