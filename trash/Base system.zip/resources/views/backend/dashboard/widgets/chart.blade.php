{{-- Chart Widget Component --}}
<div class="widget-chart">
    <canvas class="chart-canvas" data-widget-id="{{ $widget->widget_id }}"></canvas>
    <div class="chart-placeholder">
        <span>Loading chart...</span>
    </div>
</div>
