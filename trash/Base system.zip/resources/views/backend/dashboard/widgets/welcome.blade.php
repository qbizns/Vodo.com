{{-- Welcome Widget Component --}}
<div class="widget-welcome">
    <div class="welcome-content">
        <div class="welcome-text">
            <h3 class="welcome-greeting" data-greeting>Good morning</h3>
            <p class="welcome-date" data-date>{{ now()->format('l, F j, Y') }}</p>
        </div>
        <div class="welcome-stats">
            <div class="welcome-stat">
                <span class="stat-value" data-stat="plugins">{{ \App\Models\Plugin::active()->count() }}</span>
                <span class="stat-label">Active Plugins</span>
            </div>
            <div class="welcome-stat">
                <span class="stat-value" data-stat="users">1</span>
                <span class="stat-label">Online Users</span>
            </div>
        </div>
    </div>
</div>
