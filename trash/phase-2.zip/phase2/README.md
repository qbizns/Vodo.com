# Phase 2: View Inheritance System

## Overview

This phase implements an Odoo-style view inheritance system for Laravel, enabling plugins to extend and modify views without conflicts. Multiple plugins can extend the same view, each adding their own modifications that merge seamlessly.

**Key Features:**
- XPath-based DOM modifications (Odoo-style)
- Named slots/stacks for content injection (WordPress-style)
- View composers for data injection
- View replacement as last resort
- No conflicts between plugins

## Installation

### 1. Extract Files

Extract `phase-2.zip` into your Laravel project root:

```
app/
├── Facades/
│   └── ViewExtension.php
├── Http/Middleware/
│   └── ProcessViewExtensions.php
├── Providers/
│   └── ViewExtensionServiceProvider.php
├── Services/View/
│   ├── ViewExtensionRegistry.php
│   ├── ViewExtender.php
│   └── SlotManager.php
└── Traits/
    └── HasViewExtensions.php

config/
└── view-extensions.php

resources/views/components/
├── extension-point.blade.php
└── extension-area.blade.php
```

### 2. Register Service Provider

Add to `config/app.php`:

```php
'providers' => [
    // ... other providers
    App\Providers\ViewExtensionServiceProvider::class,
],

'aliases' => [
    // ... other aliases
    'ViewExtension' => App\Facades\ViewExtension::class,
],
```

### 3. Register Middleware

Add to `app/Http/Kernel.php` (Laravel 10) or `bootstrap/app.php` (Laravel 11):

```php
// Laravel 10 - in Kernel.php
protected $middlewareGroups = [
    'web' => [
        // ... other middleware
        \App\Http\Middleware\ProcessViewExtensions::class,
    ],
];

// Laravel 11 - in bootstrap/app.php
->withMiddleware(function (Middleware $middleware) {
    $middleware->appendToGroup('web', [
        \App\Http\Middleware\ProcessViewExtensions::class,
    ]);
})
```

### 4. Publish Config (Optional)

```bash
php artisan vendor:publish --tag=view-extensions-config
```

## Usage

### In Your Plugin

```php
<?php

namespace App\Plugins\CRM;

use App\Plugins\BasePlugin;
use App\Traits\HasViewExtensions;

class CRMPlugin extends BasePlugin
{
    use HasViewExtensions;

    public function activate(): void
    {
        // Add custom field after email in user form
        $this->extendView('admin.users.form', [
            'selector' => '//input[@name="email"]/..',  // Parent of email input
            'position' => 'after',
            'view' => 'crm::partials.customer-id-field',
        ]);

        // Add tab to user profile
        $this->extendView('admin.users.show', [
            'selector' => '//ul[contains(@class, "nav-tabs")]',
            'position' => 'inside_end',
            'content' => '<li class="nav-item"><a class="nav-link" href="#crm">CRM Data</a></li>',
        ]);

        // Add tab content
        $this->extendView('admin.users.show', [
            'selector' => '//div[contains(@class, "tab-content")]',
            'position' => 'inside_end',
            'view' => 'crm::partials.user-crm-tab',
        ]);

        // Add widget to dashboard using slots
        $this->addToSlot('admin.dashboard', 'widgets')
            ->priority(5)  // Show early
            ->view('crm::widgets.leads-summary');

        // Add CSS class to sidebar
        $this->addClass('admin.layout', '//nav[@id="sidebar"]', 'has-crm-module');

        // Inject data into all admin views
        $this->addViewComposer('admin.*', function($view) {
            $view->with('crmEnabled', true);
        });
    }
}
```

### Preparing Views for Extension

Add extension points to your views:

```blade
{{-- resources/views/admin/users/form.blade.php --}}

<form action="{{ route('users.store') }}" method="POST">
    @csrf
    
    {{-- Extension point for plugins to add content --}}
    <x-extension-point name="user-form-start" />
    
    <div class="form-group" data-field="name">
        <label>Name</label>
        <input type="text" name="name" class="form-control">
    </div>
    
    <div class="form-group" data-field="email">
        <label>Email</label>
        <input type="email" name="email" class="form-control">
    </div>
    
    {{-- Slot for additional fields --}}
    @extensionSlot('user-form-fields')
    
    <x-extension-area name="user-form-actions">
        <button type="submit" class="btn btn-primary">Save</button>
    </x-extension-area>
    
    <x-extension-point name="user-form-end" />
</form>
```

### Using Blade Directives

```blade
{{-- Render content from plugins --}}
@extensionSlot('sidebar-widgets')

{{-- Conditional rendering --}}
@hasExtensionSlot('premium-features')
    <div class="premium-section">
        @extensionSlot('premium-features')
    </div>
@endHasExtensionSlot

{{-- Named extension point --}}
@extensionPoint('dashboard-top')

{{-- Extendable area --}}
@extensionArea('settings-panel')
    <p>Default settings content</p>
@endExtensionArea
```

## XPath Modification Types

### Position Options

| Position | Description |
|----------|-------------|
| `before` | Insert before the matched element |
| `after` | Insert after the matched element |
| `inside_start` | Prepend inside the matched element |
| `inside_end` | Append inside the matched element |
| `replace` | Replace the matched element entirely |
| `attributes` | Modify element attributes |
| `remove` | Remove the matched element |

### XPath Selector Examples

```php
// By ID
'selector' => '//*[@id="user-form"]'

// By class
'selector' => '//*[contains(@class, "form-group")]'

// By tag
'selector' => '//form'

// By attribute
'selector' => '//input[@name="email"]'

// By data attribute
'selector' => '//*[@data-field="email"]'

// Parent of element
'selector' => '//input[@name="email"]/..'

// First matching element
'selector' => '(//div[@class="widget"])[1]'

// By extension point
'selector' => '//*[@data-extension-point="sidebar-top"]'

// Combined conditions
'selector' => '//div[contains(@class, "form-group") and @data-field="email"]'
```

### Using the Selector Builder

```php
use App\Services\View\ViewExtender;

// Fluent API
$selector = ViewExtender::selector()
    ->id('user-form')
    ->get();

$selector = ViewExtender::selector()
    ->class('form-group')
    ->get();

$selector = ViewExtender::selector()
    ->data('field', 'email')
    ->get();

// In trait
$this->extendView('admin.users.form', [
    'selector' => $this->byId('user-form'),
    'position' => 'inside_end',
    'content' => '<div>New content</div>',
]);
```

## Common Patterns

### Adding a Field to a Form

```php
$this->insertAfter(
    'admin.users.form',
    '//div[@data-field="email"]',
    'my-plugin::partials.phone-field',
    isView: true
);
```

### Adding a Tab

```php
// Add tab link
$this->appendTo(
    'admin.users.show',
    '//ul[contains(@class, "nav-tabs")]',
    '<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#my-tab">My Tab</a></li>'
);

// Add tab content
$this->appendTo(
    'admin.users.show',
    '//div[contains(@class, "tab-content")]',
    'my-plugin::partials.my-tab-content',
    isView: true
);
```

### Adding a Dashboard Widget

```php
$this->addToSlot('admin.dashboard', 'widgets')
    ->priority(10)
    ->view('my-plugin::widgets.stats', [
        'title' => 'My Stats',
    ]);
```

### Modifying Element Attributes

```php
// Add CSS class
$this->addClass('admin.layout', '//body', 'my-plugin-active');

// Set attribute
$this->setAttribute('admin.users.form', '//form', 'data-validate', 'true');

// Multiple attribute changes
$this->modifyAttributes('admin.users.form', '//input[@name="email"]', [
    'set' => ['required' => 'required', 'data-validate' => 'email'],
    'add_class' => 'validate-email',
]);
```

### Removing an Element

```php
$this->removeElement('admin.dashboard', '//*[@id="default-widget"]');
```

### Replacing an Element

```php
$this->replaceElement(
    'admin.dashboard',
    '//div[@id="stats-widget"]',
    'my-plugin::widgets.enhanced-stats',
    isView: true
);
```

## Global Helper Functions

```php
// Extend a view
extend_view('admin.users.form', [
    'selector' => '//form',
    'position' => 'inside_start',
    'content' => '<input type="hidden" name="plugin_data" value="test">',
], 'my-plugin');

// Add to a slot
add_to_slot('admin.dashboard', 'widgets', '<div>Widget content</div>', 'my-plugin');

// Replace a view completely
replace_view('admin.users.form', 'my-plugin::users.form', 'my-plugin');

// Add view composer
view_composer('admin.*', function($view) {
    $view->with('globalData', 'value');
}, 'my-plugin');

// Create selector
$selector = xpath_selector()->id('my-element')->get();
```

## How Multiple Plugins Work Together

When multiple plugins extend the same view, all modifications are applied in priority order:

```php
// Plugin A (priority 5)
$this->extendView('admin.users.form', [
    'selector' => '//form',
    'position' => 'inside_start',
    'content' => '<div id="plugin-a-field">Field A</div>',
], priority: 5);

// Plugin B (priority 10)
$this->extendView('admin.users.form', [
    'selector' => '//form',
    'position' => 'inside_start',
    'content' => '<div id="plugin-b-field">Field B</div>',
], priority: 10);

// Plugin C (priority 15)
$this->extendView('admin.users.form', [
    'selector' => '//form',
    'position' => 'inside_start',
    'content' => '<div id="plugin-c-field">Field C</div>',
], priority: 15);

// Result: Field A appears first, then B, then C
```

Plugins can also target each other's elements:

```php
// Plugin D adds styling to Plugin A's field
$this->addClass('admin.users.form', '//*[@id="plugin-a-field"]', 'enhanced-field');
```

## Configuration Options

```php
// config/view-extensions.php

return [
    // Process all views automatically
    'auto_process' => false,

    // Specific views to process
    'process_views' => [
        'admin.*',
        'frontend.*',
    ],

    // Views to exclude
    'excluded_views' => [
        'emails.*',
        'errors.*',
    ],

    // Debug mode (adds HTML comments)
    'debug' => false,

    // Safe mode (catches errors)
    'safe_mode' => true,
];
```

## File Structure

```
phase-2/
├── app/
│   ├── Facades/
│   │   └── ViewExtension.php           # Facade for easy access
│   ├── Http/Middleware/
│   │   └── ProcessViewExtensions.php   # Response processing
│   ├── Providers/
│   │   └── ViewExtensionServiceProvider.php
│   ├── Services/View/
│   │   ├── ViewExtensionRegistry.php   # Stores all extensions
│   │   ├── ViewExtender.php            # XPath processing
│   │   └── SlotManager.php             # Slot management
│   └── Traits/
│       └── HasViewExtensions.php       # Plugin trait
├── config/
│   └── view-extensions.php             # Configuration
├── resources/views/components/
│   ├── extension-point.blade.php       # Extension point component
│   └── extension-area.blade.php        # Extension area component
└── README.md
```

## Best Practices

1. **Use specific selectors** - Target elements by ID or data attributes rather than generic classes
2. **Add data attributes** - Add `data-field`, `data-section`, etc. to make views more extensible
3. **Use extension points** - Add `<x-extension-point>` where plugins are likely to add content
4. **Prefer slots for content areas** - Use `@extensionSlot` for predictable content areas
5. **Set appropriate priorities** - Use lower numbers for content that should appear first
6. **Clean up on deactivation** - Call `cleanupViewExtensions()` in your plugin's deactivate method

## What's Next?

**Phase 3: Field System** - Advanced field types, custom field registration, and field rendering.
