<?php

namespace App\Plugins\hello_world;

use App\Services\Plugins\BasePlugin;
use Illuminate\Support\Facades\Log;

class HelloWorldPlugin extends BasePlugin
{
    /**
     * Register plugin services and bindings.
     */
    public function register(): void
    {
        // Register any bindings or services here
        Log::info('Hello World Plugin: Registered');
    }

    /**
     * Bootstrap the plugin.
     */
    public function boot(): void
    {
        parent::boot();

        // Add navigation item to the sidebar
        $this->addNavigationItem([
            'id' => 'hello-world',
            'icon' => 'smile',
            'label' => 'Hello World',
            'url' => '/plugins/hello-world',
        ], 'Plugins');

        // Add a filter to modify dashboard widgets (example)
        $this->addFilter('dashboard_widgets', function (array $widgets) {
            $widgets[] = [
                'id' => 'hello-world-widget',
                'title' => 'Hello World',
                'content' => 'This widget is added by the Hello World plugin!',
            ];
            return $widgets;
        });

        // Add an action for admin footer (example)
        $this->addAction('admin_footer', function () {
            echo '<!-- Hello World Plugin Footer -->';
        });

        Log::info('Hello World Plugin: Booted');
    }

    /**
     * Handle plugin activation.
     */
    public function activate(): void
    {
        // Create default settings
        $this->setSetting('greeting', 'Hello, World!');
        $this->setSetting('show_count', true);
        
        Log::info('Hello World Plugin: Activated');
    }

    /**
     * Handle plugin deactivation.
     */
    public function deactivate(): void
    {
        Log::info('Hello World Plugin: Deactivated');
    }

    /**
     * Handle plugin uninstallation.
     */
    public function uninstall(): void
    {
        // Clean up any plugin-specific data
        Log::info('Hello World Plugin: Uninstalled');
    }

    /**
     * Get the greeting message.
     */
    public function getGreeting(): string
    {
        return $this->getSetting('greeting', 'Hello, World!');
    }
}
