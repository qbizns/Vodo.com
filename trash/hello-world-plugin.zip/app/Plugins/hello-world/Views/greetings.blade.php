<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Greetings - Hello World Plugin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        h1 {
            color: #1a1a2e;
            font-size: 2rem;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: all 0.2s ease;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5a67d8;
        }
        
        .btn-secondary {
            background: white;
            color: #1a1a2e;
            border: 1px solid #dee2e6;
        }
        
        .btn-secondary:hover {
            background: #f8f9fa;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
            padding: 6px 12px;
            font-size: 0.8rem;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #1a1a2e;
        }
        
        .form-input {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .greetings-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .greeting-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .greeting-content {
            flex: 1;
        }
        
        .greeting-message {
            color: #1a1a2e;
            font-size: 1rem;
            margin-bottom: 5px;
        }
        
        .greeting-meta {
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        
        .pagination a, .pagination span {
            padding: 8px 14px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .pagination a {
            background: white;
            color: #667eea;
            border: 1px solid #dee2e6;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .active {
            background: #667eea;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Greetings</h1>
            <a href="{{ route('plugins.hello-world.index') }}" class="btn btn-secondary">
                ← Back to Plugin
            </a>
        </div>
        
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        
        {{-- Add New Greeting Form --}}
        <div class="card">
            <div class="card-header">
                <h3>Add New Greeting</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('plugins.hello-world.greetings.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="message" class="form-label">Message</label>
                        <input type="text" name="message" id="message" class="form-input" 
                               placeholder="Enter your greeting message..." required>
                    </div>
                    <div class="form-group">
                        <label for="author" class="form-label">Author (optional)</label>
                        <input type="text" name="author" id="author" class="form-input" 
                               placeholder="Your name">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Greeting</button>
                </form>
            </div>
        </div>
        
        {{-- Greetings List --}}
        <div class="card">
            <div class="card-header">
                <h3>All Greetings</h3>
            </div>
            <div class="card-body">
                @if($greetings->isEmpty())
                    <div class="empty-state">
                        <p>No greetings yet. Be the first to add one!</p>
                    </div>
                @else
                    <div class="greetings-list">
                        @foreach($greetings as $greeting)
                            <div class="greeting-item">
                                <div class="greeting-content">
                                    <p class="greeting-message">"{{ $greeting->message }}"</p>
                                    <p class="greeting-meta">
                                        By {{ $greeting->author }} • {{ $greeting->created_at->diffForHumans() }}
                                    </p>
                                </div>
                                <form action="{{ route('plugins.hello-world.greetings.destroy', $greeting) }}" 
                                      method="POST" onsubmit="return confirm('Delete this greeting?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        @endforeach
                    </div>
                    
                    @if($greetings->hasPages())
                        <div class="pagination">
                            {{ $greetings->links() }}
                        </div>
                    @endif
                @endif
            </div>
        </div>
    </div>
</body>
</html>
