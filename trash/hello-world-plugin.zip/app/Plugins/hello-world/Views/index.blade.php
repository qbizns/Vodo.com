<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello World Plugin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            padding: 40px;
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        
        .emoji {
            font-size: 80px;
            margin-bottom: 20px;
        }
        
        h1 {
            color: #1a1a2e;
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .greeting {
            color: #667eea;
            font-size: 1.5rem;
            font-weight: 500;
            margin-bottom: 30px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #667eea;
        }
        
        .stat-label {
            color: #6c757d;
            font-size: 0.875rem;
            margin-top: 5px;
        }
        
        .info {
            background: #e8f4f8;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: left;
        }
        
        .info h3 {
            color: #1a1a2e;
            margin-bottom: 10px;
        }
        
        .info p {
            color: #6c757d;
            line-height: 1.6;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5a67d8;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: #f8f9fa;
            color: #1a1a2e;
            border: 1px solid #dee2e6;
        }
        
        .btn-secondary:hover {
            background: #e9ecef;
        }
        
        .actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .version {
            margin-top: 30px;
            color: #adb5bd;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="emoji">👋</div>
        <h1>Hello World Plugin</h1>
        <p class="greeting">{{ $greeting }}</p>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-value">{{ $greetingsCount }}</div>
                <div class="stat-label">Total Greetings</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ $plugin->version }}</div>
                <div class="stat-label">Plugin Version</div>
            </div>
        </div>
        
        <div class="info">
            <h3>About This Plugin</h3>
            <p>
                This is an example plugin demonstrating the capabilities of the Vodo plugin system.
                It showcases routes, views, database migrations, models, and the hook system.
            </p>
        </div>
        
        <div class="actions">
            <a href="{{ route('plugins.hello-world.greetings') }}" class="btn btn-primary">
                View Greetings
            </a>
            <a href="javascript:history.back()" class="btn btn-secondary">
                Go Back
            </a>
        </div>
        
        <p class="version">
            Plugin by {{ $plugin->author ?? 'Vodo' }} • v{{ $plugin->version }}
        </p>
    </div>
</body>
</html>
