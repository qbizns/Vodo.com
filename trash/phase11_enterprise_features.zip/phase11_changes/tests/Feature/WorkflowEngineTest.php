<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Services\Workflow\WorkflowEngine;
use App\Services\Workflow\WorkflowException;
use App\Services\Workflow\WorkflowConditionException;
use App\Services\PluginBus\PluginBus;
use App\Models\WorkflowDefinition;
use App\Models\WorkflowInstance;
use App\Models\WorkflowHistory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;

class WorkflowEngineTest extends TestCase
{
    use RefreshDatabase;

    protected WorkflowEngine $engine;
    protected PluginBus $bus;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->bus = new PluginBus();
        $this->engine = new WorkflowEngine($this->bus);
    }

    // =========================================================================
    // Workflow Definition Tests
    // =========================================================================

    public function test_can_define_workflow(): void
    {
        $workflow = $this->engine->defineWorkflow('invoice_workflow', 'invoice', [
            'name' => 'Invoice Workflow',
            'states' => [
                'draft' => ['label' => 'Draft', 'color' => 'gray'],
                'sent' => ['label' => 'Sent', 'color' => 'blue'],
                'paid' => ['label' => 'Paid', 'color' => 'green', 'is_final' => true],
            ],
            'transitions' => [
                'send' => ['from' => 'draft', 'to' => 'sent', 'label' => 'Send'],
                'pay' => ['from' => 'sent', 'to' => 'paid', 'label' => 'Mark Paid'],
            ],
        ]);

        $this->assertInstanceOf(WorkflowDefinition::class, $workflow);
        $this->assertEquals('invoice_workflow', $workflow->slug);
        $this->assertCount(3, $workflow->states);
        $this->assertCount(2, $workflow->transitions);
    }

    public function test_workflow_requires_states(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        $this->engine->defineWorkflow('invalid', 'entity', [
            'states' => [],
            'transitions' => [
                'go' => ['from' => 'a', 'to' => 'b'],
            ],
        ]);
    }

    public function test_workflow_validates_transition_states(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        $this->engine->defineWorkflow('invalid', 'entity', [
            'states' => [
                'draft' => ['label' => 'Draft'],
            ],
            'transitions' => [
                'go' => ['from' => 'nonexistent', 'to' => 'draft'],
            ],
        ]);
    }

    // =========================================================================
    // Workflow Instance Tests
    // =========================================================================

    public function test_can_initialize_workflow_for_record(): void
    {
        $workflow = $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();

        $instance = $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $this->assertInstanceOf(WorkflowInstance::class, $instance);
        $this->assertEquals('draft', $instance->current_state);
    }

    public function test_does_not_create_duplicate_instances(): void
    {
        $workflow = $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();

        $instance1 = $this->engine->initializeWorkflow($invoice, 'invoice_workflow');
        $instance2 = $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $this->assertEquals($instance1->id, $instance2->id);
    }

    public function test_can_get_current_state(): void
    {
        $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $state = $this->engine->getCurrentState($invoice, 'invoice_workflow');

        $this->assertEquals('draft', $state);
    }

    // =========================================================================
    // Transition Tests
    // =========================================================================

    public function test_can_execute_valid_transition(): void
    {
        $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $instance = $this->engine->transition($invoice, 'send', [], 'invoice_workflow');

        $this->assertEquals('sent', $instance->current_state);
        $this->assertEquals('draft', $instance->previous_state);
    }

    public function test_cannot_execute_invalid_transition(): void
    {
        $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $this->expectException(WorkflowException::class);

        // Cannot go directly from draft to paid
        $this->engine->transition($invoice, 'pay', [], 'invoice_workflow');
    }

    public function test_transition_creates_history(): void
    {
        $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $this->engine->transition($invoice, 'send', [], 'invoice_workflow');

        $history = WorkflowHistory::first();
        $this->assertNotNull($history);
        $this->assertEquals('send', $history->transition_id);
        $this->assertEquals('draft', $history->from_state);
        $this->assertEquals('sent', $history->to_state);
    }

    // =========================================================================
    // Available Transitions Tests
    // =========================================================================

    public function test_gets_available_transitions(): void
    {
        $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'invoice_workflow');

        $transitions = $this->engine->getAvailableTransitions($invoice, 'invoice_workflow');

        $this->assertArrayHasKey('send', $transitions);
        $this->assertEquals('sent', $transitions['send']['to']);
    }

    public function test_no_transitions_from_final_state(): void
    {
        $this->createInvoiceWorkflow();
        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'invoice_workflow');
        $this->engine->transition($invoice, 'send', [], 'invoice_workflow');
        $this->engine->transition($invoice, 'pay', [], 'invoice_workflow');

        $transitions = $this->engine->getAvailableTransitions($invoice, 'invoice_workflow');

        $this->assertEmpty($transitions);
    }

    // =========================================================================
    // Condition Tests
    // =========================================================================

    public function test_transition_respects_conditions(): void
    {
        $workflow = $this->engine->defineWorkflow('conditional_workflow', 'invoice', [
            'states' => [
                'draft' => ['label' => 'Draft'],
                'validated' => ['label' => 'Validated'],
            ],
            'transitions' => [
                'validate' => [
                    'from' => 'draft',
                    'to' => 'validated',
                    'conditions' => ['has_lines'],
                ],
            ],
        ]);

        // Register condition that always fails
        $this->engine->registerCondition('has_lines', fn($record) => false);

        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'conditional_workflow');

        $this->expectException(WorkflowConditionException::class);

        $this->engine->transition($invoice, 'validate', [], 'conditional_workflow');
    }

    // =========================================================================
    // Action Tests
    // =========================================================================

    public function test_transition_executes_actions(): void
    {
        $actionExecuted = false;

        $this->engine->registerAction('mark_sent', function ($record) use (&$actionExecuted) {
            $actionExecuted = true;
        });

        $workflow = $this->engine->defineWorkflow('action_workflow', 'invoice', [
            'states' => [
                'draft' => ['label' => 'Draft'],
                'sent' => ['label' => 'Sent'],
            ],
            'transitions' => [
                'send' => [
                    'from' => 'draft',
                    'to' => 'sent',
                    'actions' => ['mark_sent'],
                ],
            ],
        ]);

        $invoice = $this->createMockInvoice();
        $this->engine->initializeWorkflow($invoice, 'action_workflow');
        $this->engine->transition($invoice, 'send', [], 'action_workflow');

        $this->assertTrue($actionExecuted);
    }

    // =========================================================================
    // Mermaid Diagram Tests
    // =========================================================================

    public function test_generates_mermaid_diagram(): void
    {
        $this->createInvoiceWorkflow();

        $diagram = $this->engine->generateDiagram('invoice_workflow');

        $this->assertStringContainsString('stateDiagram-v2', $diagram);
        $this->assertStringContainsString('draft', $diagram);
        $this->assertStringContainsString('sent', $diagram);
        $this->assertStringContainsString('paid', $diagram);
    }

    // =========================================================================
    // Helper Methods
    // =========================================================================

    protected function createInvoiceWorkflow(): WorkflowDefinition
    {
        return $this->engine->defineWorkflow('invoice_workflow', 'invoice', [
            'name' => 'Invoice Workflow',
            'states' => [
                'draft' => ['label' => 'Draft', 'color' => 'gray'],
                'sent' => ['label' => 'Sent', 'color' => 'blue'],
                'paid' => ['label' => 'Paid', 'color' => 'green', 'is_final' => true],
            ],
            'transitions' => [
                'send' => ['from' => 'draft', 'to' => 'sent', 'label' => 'Send'],
                'pay' => ['from' => 'sent', 'to' => 'paid', 'label' => 'Mark Paid'],
            ],
        ]);
    }

    protected function createMockInvoice()
    {
        // Create a mock model for testing
        return new class extends \Illuminate\Database\Eloquent\Model {
            protected $table = 'invoices';
            public $exists = true;
            protected $attributes = ['id' => 1, 'status' => 'draft'];
            
            public function getKey() { return 1; }
            public function getTable() { return 'invoices'; }
            public function toArray() { return ['id' => 1, 'status' => $this->status ?? 'draft']; }
            public function update(array $attributes = [], array $options = []) {
                foreach ($attributes as $key => $value) {
                    $this->attributes[$key] = $value;
                }
                return true;
            }
        };
    }
}
