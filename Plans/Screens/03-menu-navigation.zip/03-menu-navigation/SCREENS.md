# Menu & Navigation - Screen Specifications

## Screen 1: Menu Builder

### Purpose
Visual interface for managing the navigation menu structure with drag-and-drop reordering.

### URL
`/admin/menus`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Menu Builder                                               [Save Changes]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌────────────────────────────┐ ┌──────────────────────────────────────────┐ │
│ │ Preview                    │ │ Menu Structure                           │ │
│ ├────────────────────────────┤ ├──────────────────────────────────────────┤ │
│ │                            │ │                                          │ │
│ │ ┌────────────────────────┐ │ │ [+ Add Item] [+ Add Divider] [Collapse]  │ │
│ │ │ 📊 Dashboard           │ │ │                                          │ │
│ │ ├────────────────────────┤ │ │ ┌────────────────────────────────────┐   │ │
│ │ │ 👥 Users            ▶  │ │ │ │ ≡ 📊 Dashboard                     │   │ │
│ │ ├────────────────────────┤ │ │ │   System · Position: 10            │   │ │
│ │ │ 📄 Invoices      (5) ▶ │ │ │ │                         [Edit] [×] │   │ │
│ │ ├────────────────────────┤ │ │ └────────────────────────────────────┘   │ │
│ │ │ 📦 Inventory         ▶ │ │ │                                          │ │
│ │ ├────────────────────────┤ │ │ ┌────────────────────────────────────┐   │ │
│ │ │ 📈 Reports           ▶ │ │ │ │ ≡ 👥 Users                         │   │ │
│ │ ├────────────────────────┤ │ │ │   System · Position: 20            │   │ │
│ │ │ ─────────────────────  │ │ │ │                         [Edit] [×] │   │ │
│ │ │ ⚙️ Settings          ▶ │ │ │ │  ├─ ≡ All Users                    │   │ │
│ │ │ 🔌 Plugins           ▶ │ │ │ │  ├─ ≡ Create User                  │   │ │
│ │ └────────────────────────┘ │ │ │  └─ ≡ Roles                        │   │ │
│ │                            │ │ │ └────────────────────────────────────┘   │ │
│ │                            │ │ │                                          │ │
│ │                            │ │ │ ┌────────────────────────────────────┐   │ │
│ │                            │ │ │ │ ≡ 📄 Invoices              🔴 5   │   │ │
│ │                            │ │ │ │   invoice-manager · Position: 30  │   │ │
│ │                            │ │ │ │                         [Edit] [×] │   │ │
│ │                            │ │ │ │  ├─ ≡ All Invoices                │   │ │
│ │                            │ │ │ │  ├─ ≡ Create Invoice              │   │ │
│ │                            │ │ │ │  ├─ ≡ Reports                     │   │ │
│ │                            │ │ │ │  └─ ≡ Settings                    │   │ │
│ │                            │ │ │ └────────────────────────────────────┘   │ │
│ │                            │ │ │                                          │ │
│ │                            │ │ │ ┌────────────────────────────────────┐   │ │
│ │                            │ │ │ │ ── Divider ──────────────────────  │   │ │
│ │                            │ │ │ └────────────────────────────────────┘   │ │
│ │                            │ │ │                                          │ │
│ │                            │ │ │ ┌────────────────────────────────────┐   │ │
│ │                            │ │ │ │ ≡ ⚙️ Settings                      │   │ │
│ │                            │ │ │ │   System · Position: 90           │   │ │
│ │                            │ │ │ └────────────────────────────────────┘   │ │
│ │                            │ │ │                                          │ │
│ └────────────────────────────┘ └──────────────────────────────────────────┘ │
│                                                                             │
│ Legend: 🔒 = Locked (system)  🔌 = Plugin item  ≡ = Drag handle            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Requirements

```php
$data = [
    'menuItems' => MenuItem::with('children')
        ->whereNull('parent_id')
        ->orderBy('position')
        ->get()
        ->map(fn($item) => [
            'id' => $item->id,
            'key' => $item->key,
            'label' => $item->label,
            'icon' => $item->icon,
            'route' => $item->route,
            'url' => $item->url,
            'permission' => $item->permission,
            'position' => $item->position,
            'plugin' => $item->plugin,
            'is_system' => $item->is_system,
            'badge' => $item->getBadgeCount(),
            'children' => $item->children->map(...),
        ]),
    'availableIcons' => config('ui.icons'),
    'availableRoutes' => $this->getAvailableRoutes(),
];
```

### Interactions

- **Drag items**: Reorder within same level or move to different parent
- **Edit button**: Open item editor modal
- **Delete button**: Remove item (with confirmation for plugin items)
- **Add Item**: Create new custom menu item
- **Add Divider**: Insert visual separator

---

## Screen 2: Menu Item Editor

### Purpose
Create or edit individual menu items with full configuration options.

### URL
`/admin/menus/items/{item}/edit` (modal or page)

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Edit Menu Item                                                      [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Label *                                                                 │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Invoices                                                            │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Key (unique identifier)                                                 │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ invoices                                                            │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Icon                                                                    │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 📄 file-text                                    [Browse Icons...]   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Navigation Type                                                         │ │
│ │ ● Route Name    ○ Custom URL    ○ No Link (parent only)                │ │
│ │                                                                         │ │
│ │ Route                                                                   │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ admin.invoices.index                                            ▼   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Required Permission                                                     │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ invoices.view                                                   ▼   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Parent Item                                                             │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ (Root Level)                                                    ▼   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Position       ┌──────┐                                                 │ │
│ │                │  30  │                                                 │ │
│ │                └──────┘                                                 │ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Badge Settings                                              [▼]     │ │ │
│ │ ├─────────────────────────────────────────────────────────────────────┤ │ │
│ │ │ □ Show badge                                                        │ │ │
│ │ │                                                                     │ │ │
│ │ │ Badge Type:  ○ Static Value  ● Dynamic Count  ○ Dot Only           │ │ │
│ │ │                                                                     │ │ │
│ │ │ Badge Source (for dynamic):                                         │ │ │
│ │ │ ┌─────────────────────────────────────────────────────────────────┐ │ │ │
│ │ │ │ Invoice::pending()->count()                                     │ │ │ │
│ │ │ └─────────────────────────────────────────────────────────────────┘ │ │ │
│ │ │                                                                     │ │ │
│ │ │ Badge Color:  [🔴 Red ▼]                                           │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ □ Open in new tab                                                      │ │
│ │ □ Visible (uncheck to hide)                                            │ │
│ │                                                                         │ │
│ │ ⚠️ This is a plugin item from "invoice-manager"                        │ │
│ │    Changes may be overwritten on plugin update.                        │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                        [Cancel] [Delete] [Save Changes]     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Icon Picker Modal
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Select Icon                                                         [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 🔍 Search icons...                                                          │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Common                                                                  │ │
│ │ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ │ │
│ │ │ 🏠 │ │ 📊 │ │ 👥 │ │ ⚙️ │ │ 📄 │ │ 📁 │ │ 📈 │ │ 🔔 │ │ 📧 │ │ 🔍 │ │ │
│ │ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ │ │
│ │ home   chart  users  cog    file   folder graph  bell   mail   search │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │ Files & Documents                                                       │ │
│ │ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ │ │
│ │ │    │ │    │ │    │ │    │ │    │ │    │ │    │ │    │ │    │ │    │ │ │
│ │ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Selected: file-text                                          [Select]      │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 3: Navigation Settings

### Purpose
Configure global navigation behavior and appearance settings.

### URL
`/admin/settings/navigation`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Navigation Settings                                        [Save Settings]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Sidebar Settings                                                        │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Default Sidebar State                                                   │ │
│ │ ● Expanded    ○ Collapsed    ○ Remember last state                     │ │
│ │                                                                         │ │
│ │ Sidebar Position                                                        │ │
│ │ ● Left    ○ Right                                                       │ │
│ │                                                                         │ │
│ │ □ Allow users to collapse sidebar                                       │ │
│ │ □ Show icons only when collapsed                                        │ │
│ │ □ Auto-collapse on mobile                                               │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Menu Behavior                                                           │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Submenu Expansion                                                       │ │
│ │ ● Click to expand    ○ Hover to expand                                 │ │
│ │                                                                         │ │
│ │ □ Auto-expand active section                                           │ │
│ │ □ Collapse other sections when one expands (accordion mode)            │ │
│ │ □ Remember expanded sections                                           │ │
│ │                                                                         │ │
│ │ Maximum nesting depth: [3 ▼]                                           │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Badge Settings                                                          │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ □ Show badges in navigation                                            │ │
│ │                                                                         │ │
│ │ Badge refresh interval: [5 ▼] minutes                                  │ │
│ │                                                                         │ │
│ │ Maximum badge value (show +): [99 ▼]                                   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Breadcrumbs                                                             │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ ☑ Show breadcrumbs                                                     │ │
│ │ □ Include home link                                                    │ │
│ │ □ Show current page in breadcrumbs                                     │ │
│ │                                                                         │ │
│ │ Separator: [ / ▼]  (options: /, >, →, •)                               │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Quick Links / Favorites                                                 │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ ☑ Enable quick links feature                                           │ │
│ │ □ Show quick links in topbar                                           │ │
│ │ □ Allow users to add favorites                                         │ │
│ │                                                                         │ │
│ │ Maximum quick links per user: [10 ▼]                                   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 4: User Menu Preferences

### Purpose
Allow users to customize their personal navigation experience.

### URL
`/admin/profile/menu`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ My Menu Preferences                                       [Save Preferences]│
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Quick Links (Favorites)                                                 │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Drag to reorder your quick access links:                               │ │
│ │                                                                         │ │
│ │ ┌──────────────────────────────────────────────────────────────────┐   │ │
│ │ │ ≡ ⭐ Dashboard                                              [×]  │   │ │
│ │ │ ≡ ⭐ Create Invoice                                         [×]  │   │ │
│ │ │ ≡ ⭐ Pending Orders                                         [×]  │   │ │
│ │ │ ≡ ⭐ My Tasks                                                [×]  │   │ │
│ │ └──────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ │ [+ Add Quick Link]                                                      │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Sidebar Preferences                                                     │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Default sidebar state:                                                  │ │
│ │ ○ Use system default    ● Expanded    ○ Collapsed                      │ │
│ │                                                                         │ │
│ │ □ Remember my expanded/collapsed menu sections                         │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Hidden Menu Items                                                       │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Hide menu items you don't use frequently:                              │ │
│ │                                                                         │ │
│ │ □ Reports > Audit Log                                                  │ │
│ │ □ Settings > Integrations                                              │ │
│ │ ☑ Help & Support (hidden)                                              │ │
│ │                                                                         │ │
│ │ [Show all menu items]                                                   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │                                           [Reset to Defaults]           │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Common Components

### Sidebar Component

```blade
{{-- resources/views/components/navigation/sidebar.blade.php --}}
@props(['menu', 'collapsed' => false])

<aside x-data="sidebar()" 
       :class="{ 'sidebar--collapsed': isCollapsed }"
       class="sidebar">
    
    <div class="sidebar__header">
        <a href="{{ route('admin.dashboard') }}" class="sidebar__logo">
            <img src="{{ asset('images/logo.svg') }}" alt="Logo" class="sidebar__logo-full">
            <img src="{{ asset('images/logo-icon.svg') }}" alt="Logo" class="sidebar__logo-icon">
        </a>
        <button @click="toggle()" class="sidebar__toggle">
            <x-icon name="chevrons-left" x-show="!isCollapsed" />
            <x-icon name="chevrons-right" x-show="isCollapsed" />
        </button>
    </div>
    
    <nav class="sidebar__nav">
        @foreach($menu as $item)
            <x-navigation.menu-item :item="$item" :level="0" />
        @endforeach
    </nav>
    
    <div class="sidebar__footer">
        <x-navigation.user-menu />
    </div>
</aside>
```

### Menu Item Component

```blade
{{-- resources/views/components/navigation/menu-item.blade.php --}}
@props(['item', 'level' => 0])

@php
    $hasChildren = !empty($item['children']);
    $isActive = $item['is_active'] ?? false;
    $isExpanded = $item['is_expanded'] ?? false;
@endphp

@if($item['type'] === 'divider')
    <hr class="sidebar__divider">
@else
    <div x-data="{ open: @js($isExpanded) }" 
         class="menu-item menu-item--level-{{ $level }} {{ $isActive ? 'menu-item--active' : '' }}">
        
        @if($hasChildren)
            <button @click="open = !open" 
                    class="menu-item__link menu-item__link--parent">
                <x-icon :name="$item['icon']" class="menu-item__icon" />
                <span class="menu-item__label">{{ $item['label'] }}</span>
                @if($item['badge'] ?? null)
                    <span class="menu-item__badge badge badge-{{ $item['badge_color'] ?? 'primary' }}">
                        {{ $item['badge'] > 99 ? '99+' : $item['badge'] }}
                    </span>
                @endif
                <x-icon name="chevron-down" class="menu-item__chevron" :class="{ 'rotate-180': open }" />
            </button>
            
            <div x-show="open" x-collapse class="menu-item__children">
                @foreach($item['children'] as $child)
                    <x-navigation.menu-item :item="$child" :level="$level + 1" />
                @endforeach
            </div>
        @else
            <a href="{{ $item['url'] }}" 
               class="menu-item__link"
               @if($item['new_tab'] ?? false) target="_blank" @endif>
                <x-icon :name="$item['icon']" class="menu-item__icon" />
                <span class="menu-item__label">{{ $item['label'] }}</span>
                @if($item['badge'] ?? null)
                    <span class="menu-item__badge badge badge-{{ $item['badge_color'] ?? 'primary' }}">
                        {{ $item['badge'] > 99 ? '99+' : $item['badge'] }}
                    </span>
                @endif
            </a>
        @endif
    </div>
@endif
```

### Breadcrumbs Component

```blade
{{-- resources/views/components/navigation/breadcrumbs.blade.php --}}
@props(['items'])

<nav aria-label="Breadcrumb" class="breadcrumbs">
    <ol class="breadcrumbs__list">
        @if(config('navigation.breadcrumbs.include_home'))
            <li class="breadcrumbs__item">
                <a href="{{ route('admin.dashboard') }}" class="breadcrumbs__link">
                    <x-icon name="home" class="w-4 h-4" />
                </a>
            </li>
        @endif
        
        @foreach($items as $index => $item)
            <li class="breadcrumbs__item">
                @if($index > 0 || config('navigation.breadcrumbs.include_home'))
                    <span class="breadcrumbs__separator">{{ config('navigation.breadcrumbs.separator', '/') }}</span>
                @endif
                
                @if($loop->last && !config('navigation.breadcrumbs.link_current'))
                    <span class="breadcrumbs__current">{{ $item['label'] }}</span>
                @else
                    <a href="{{ $item['url'] }}" class="breadcrumbs__link">
                        {{ $item['label'] }}
                    </a>
                @endif
            </li>
        @endforeach
    </ol>
</nav>
```

### Quick Links Bar

```blade
{{-- resources/views/components/navigation/quick-links.blade.php --}}
@props(['links'])

<div class="quick-links">
    @foreach($links as $link)
        <a href="{{ $link['url'] }}" 
           class="quick-links__item" 
           title="{{ $link['label'] }}">
            <x-icon :name="$link['icon']" class="w-4 h-4" />
            <span>{{ $link['label'] }}</span>
        </a>
    @endforeach
    
    @can('quick-links.create')
        <button @click="$dispatch('open-modal', 'add-quick-link')" 
                class="quick-links__add" 
                title="Add quick link">
            <x-icon name="plus" class="w-4 h-4" />
        </button>
    @endcan
</div>
```
