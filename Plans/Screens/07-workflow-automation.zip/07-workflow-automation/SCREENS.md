# Workflow & Automation - Screen Specifications

## Screen 1: Workflow List

### Purpose
Display all workflows with status, last execution, and quick actions.

### URL
`/admin/workflows`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Workflows                                               [+ Create Workflow] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 🔍 Search workflows...                    [All ▼] [Filter by trigger ▼]    │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 🟢 Invoice Reminder                                      [Toggle]   │ │ │
│ │ │ ⏰ Schedule: Daily at 9:00 AM                                        │ │ │
│ │ │                                                                     │ │ │
│ │ │ Last run: 2 hours ago (Success)        Runs: 156 total             │ │ │
│ │ │                                                                     │ │ │
│ │ │ [Edit] [Run Now] [History] [⋮]                                      │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 🟢 New Order Notification                                [Toggle]   │ │ │
│ │ │ ⚡ Trigger: When Order is created                                   │ │ │
│ │ │                                                                     │ │ │
│ │ │ Last run: 15 minutes ago (Success)     Runs: 1,203 total           │ │ │
│ │ │                                                                     │ │ │
│ │ │ [Edit] [Run Now] [History] [⋮]                                      │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 🔴 Data Sync                                              [Toggle]   │ │ │
│ │ │ 🌐 Trigger: Webhook                                                 │ │ │
│ │ │                                                                     │ │ │
│ │ │ Last run: Yesterday (Failed)           Runs: 45 total              │ │ │
│ │ │ ⚠️ Error: API timeout on step 3                                     │ │ │
│ │ │                                                                     │ │ │
│ │ │ [Edit] [Run Now] [History] [⋮]                                      │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ ⚪ Customer Onboarding                                   [Toggle]   │ │ │
│ │ │ ⚡ Trigger: When Customer is created                                │ │ │
│ │ │                                                                     │ │ │
│ │ │ Never run (Inactive)                   Runs: 0 total               │ │ │
│ │ │                                                                     │ │ │
│ │ │ [Edit] [Run Now] [History] [⋮]                                      │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                               Showing 1-10 of 24 workflows  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 2: Workflow Builder

### Purpose
Visual node-based editor for creating and editing workflows.

### URL
`/admin/workflows/{id}/edit`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Invoice Reminder                    [Test Run] [Save Draft] [Save & Activate]│
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌──────────────┐ ┌─────────────────────────────────────────────────────────┐ │
│ │ Node Palette │ │ Canvas                                    [−][□][×]    │ │
│ ├──────────────┤ ├─────────────────────────────────────────────────────────┤ │
│ │ 🔍 Search... │ │                                                         │ │
│ │              │ │    ┌─────────────┐                                      │ │
│ │ TRIGGERS     │ │    │ ⏰ Schedule │                                      │ │
│ │ ├─ ⏰ Schedule│ │    │ Daily 9 AM  │                                      │ │
│ │ ├─ ⚡ Event   │ │    └──────┬──────┘                                      │ │
│ │ ├─ 🌐 Webhook│ │           │                                             │ │
│ │ └─ 🔘 Manual │ │           ▼                                             │ │
│ │              │ │    ┌─────────────┐                                      │ │
│ │ ACTIONS      │ │    │ 🔍 Query    │                                      │ │
│ │ ├─ 📧 Email  │ │    │ Get overdue │                                      │ │
│ │ ├─ 🌐 HTTP   │ │    │ invoices    │                                      │ │
│ │ ├─ 📝 Create │ │    └──────┬──────┘                                      │ │
│ │ ├─ ✏️ Update │ │           │                                             │ │
│ │ ├─ 🗑️ Delete │ │           ▼                                             │ │
│ │ └─ 🔔 Notify │ │    ┌─────────────┐                                      │ │
│ │              │ │    │ 🔄 Loop     │                                      │ │
│ │ LOGIC        │ │    │ For each    │                                      │ │
│ │ ├─ ❓ If/Else│ │    │ invoice     │────────────┐                         │ │
│ │ ├─ 🔀 Switch │ │    └─────────────┘            │                         │ │
│ │ ├─ 🔄 Loop   │ │                               ▼                         │ │
│ │ ├─ ⏸️ Delay  │ │                        ┌─────────────┐                   │ │
│ │ └─ 🔗 Merge  │ │                        │ 📧 Send     │                   │ │
│ │              │ │                        │ Email       │                   │ │
│ │ PLUGIN       │ │                        │ Reminder    │                   │ │
│ │ ├─ 📄 Invoice│ │                        └─────────────┘                   │ │
│ │ └─ 💳 Payment│ │                                                         │ │
│ └──────────────┘ │                                         [Zoom: 100%]    │ │
│                  └─────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Node Settings: Send Email                                        [×]   │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │ To *           │ {{item.customer.email}}                    [+ Add]    │ │
│ │ Subject *      │ Payment Reminder: Invoice {{item.number}}             │ │
│ │ Template       │ [invoice_reminder ▼]                                   │ │
│ │ Variables      │ invoice: {{item}}, company: {{settings.company}}      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Node Configuration Panel
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Configure: Query                                                    [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [General] [Filters] [Output] [Error Handling]                               │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Entity *                                                                │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Invoice                                                          ▼  │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Filters                                                     [+ Add]    │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ [status     ▼] [equals    ▼] [pending    ]              [×]        │ │ │
│ │ │ [due_date   ▼] [before    ▼] [{{now}}    ]              [×]        │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Order By                                                                │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ [due_date   ▼] [Ascending ▼]                                        │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Limit                                                                   │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 100                                                                 │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                                        [Cancel] [Apply]     │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 3: Execution History

### Purpose
View all workflow executions with status, duration, and debug information.

### URL
`/admin/workflows/{id}/executions`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Invoice Reminder                                                          │
│                                                                             │
│ Execution History                                          [Export] [Filter]│
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ Filter: [All Status ▼] [Last 7 days ▼]                    156 executions   │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Status    │ Started           │ Duration │ Items  │ Trigger    │       │ │
│ ├───────────┼───────────────────┼──────────┼────────┼────────────┼───────┤ │
│ │ 🟢 Success│ Today, 9:00 AM    │ 2.3s     │ 12     │ ⏰ Schedule │ [View]│ │
│ │ 🟢 Success│ Yesterday, 9:00 AM│ 1.8s     │ 8      │ ⏰ Schedule │ [View]│ │
│ │ 🟢 Success│ Dec 13, 9:00 AM   │ 2.1s     │ 15     │ ⏰ Schedule │ [View]│ │
│ │ 🔴 Failed │ Dec 12, 9:00 AM   │ 5.2s     │ 3/10   │ ⏰ Schedule │ [View]│ │
│ │           │ Error: SMTP timeout                                        │ │
│ │ 🟢 Success│ Dec 11, 9:00 AM   │ 1.5s     │ 5      │ ⏰ Schedule │ [View]│ │
│ │ 🟡 Partial│ Dec 10, 9:00 AM   │ 3.4s     │ 18/20  │ ⏰ Schedule │ [View]│ │
│ │           │ Warning: 2 emails bounced                                   │ │
│ │ 🟢 Success│ Dec 9, 9:00 AM    │ 1.9s     │ 7      │ ⏰ Schedule │ [View]│ │
│ │ 🟢 Success│ Dec 8, 2:30 PM    │ 0.8s     │ 1      │ 🔘 Manual   │ [View]│ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                                      [Load More]            │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 4: Execution Detail

### Purpose
Detailed view of a single workflow execution with step-by-step inspection.

### URL
`/admin/workflows/{id}/executions/{execution}`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Execution History                                         [Retry] [Delete]│
│                                                                             │
│ Execution #12847                                                            │
│ Started: Today, 9:00:00 AM | Duration: 2.3s | Status: 🟢 Success           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [Timeline] [Data Flow] [Logs]                                               │
│ ═══════════════════════════════════════════════════════════════════════════ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Execution Timeline                                                      │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ 9:00:00.000  ┌─────────────────────────────────────────────────────┐   │ │
│ │      ●───────│ ⏰ Schedule Trigger                                  │   │ │
│ │      │       │ Triggered by cron: 0 9 * * *                        │   │ │
│ │      │       └─────────────────────────────────────────────────────┘   │ │
│ │      │       Duration: 5ms                                             │ │
│ │      │                                                                 │ │
│ │ 9:00:00.005  ┌─────────────────────────────────────────────────────┐   │ │
│ │      ●───────│ 🔍 Query: Get overdue invoices                       │   │ │
│ │      │       │ Output: 12 records                                   │   │ │
│ │      │       └─────────────────────────────────────────────────────┘   │ │
│ │      │       Duration: 120ms                                           │ │
│ │      │                                                                 │ │
│ │ 9:00:00.125  ┌─────────────────────────────────────────────────────┐   │ │
│ │      ●───────│ 🔄 Loop: For each invoice (12 items)                 │   │ │
│ │      │       │ Processing 12 items...                               │   │ │
│ │      │       └─────────────────────────────────────────────────────┘   │ │
│ │      │                                                                 │ │
│ │      │  9:00:00.130 → 📧 Send Email (INV-001)         ✓ 180ms        │ │
│ │      │  9:00:00.310 → 📧 Send Email (INV-002)         ✓ 165ms        │ │
│ │      │  9:00:00.475 → 📧 Send Email (INV-003)         ✓ 172ms        │ │
│ │      │  ... (9 more)                                                  │ │
│ │      │                                                                 │ │
│ │ 9:00:02.300  ┌─────────────────────────────────────────────────────┐   │ │
│ │      ●───────│ ✅ Workflow Complete                                  │   │ │
│ │              │ 12/12 emails sent successfully                       │   │ │
│ │              └─────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Step Inspector: Send Email (INV-001)                                    │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │ Input:                              Output:                             │ │
│ │ {                                   {                                   │ │
│ │   "to": "john@acme.com",             "success": true,                  │ │
│ │   "subject": "Payment Reminder:      "messageId": "abc123",            │ │
│ │              Invoice INV-001",       "timestamp": "2024-12-15..."      │ │
│ │   "template": "invoice_reminder",  }                                   │ │
│ │   "data": {...}                                                        │ │
│ │ }                                                                       │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Common Components

### Node Component

```blade
{{-- resources/views/components/workflow/node.blade.php --}}
@props(['node', 'selected' => false])

<div class="workflow-node {{ $selected ? 'workflow-node--selected' : '' }}"
     :class="{ 'workflow-node--running': isRunning, 'workflow-node--error': hasError }"
     data-node-id="{{ $node['id'] }}"
     draggable="true">
    
    {{-- Input Connector --}}
    @if($node['type'] !== 'trigger')
        <div class="workflow-node__connector workflow-node__connector--input"
             data-connector="input"></div>
    @endif
    
    {{-- Node Content --}}
    <div class="workflow-node__header">
        <x-icon :name="$node['icon']" class="w-4 h-4" />
        <span class="workflow-node__type">{{ $node['name'] }}</span>
    </div>
    
    <div class="workflow-node__body">
        <span class="workflow-node__label">{{ $node['label'] ?? $node['name'] }}</span>
    </div>
    
    {{-- Status Indicator --}}
    <div class="workflow-node__status" x-show="status">
        <span x-text="status"></span>
    </div>
    
    {{-- Output Connector(s) --}}
    @foreach($node['outputs'] ?? [['name' => 'default']] as $output)
        <div class="workflow-node__connector workflow-node__connector--output"
             data-connector="output-{{ $output['name'] }}"></div>
    @endforeach
</div>
```

### Node Palette Component

```blade
{{-- resources/views/components/workflow/node-palette.blade.php --}}
@props(['categories'])

<div class="node-palette" x-data="nodePalette()">
    <div class="node-palette__search">
        <input type="text" 
               x-model="search" 
               placeholder="Search nodes..."
               class="node-palette__search-input">
    </div>
    
    <div class="node-palette__categories">
        @foreach($categories as $category)
            <div class="node-palette__category" x-show="categoryVisible('{{ $category['key'] }}')">
                <button @click="toggleCategory('{{ $category['key'] }}')" 
                        class="node-palette__category-header">
                    <span>{{ $category['label'] }}</span>
                    <x-icon name="chevron-down" class="w-4 h-4" />
                </button>
                
                <div x-show="isExpanded('{{ $category['key'] }}')" class="node-palette__nodes">
                    @foreach($category['nodes'] as $node)
                        <div class="node-palette__node"
                             x-show="nodeVisible('{{ $node['id'] }}')"
                             draggable="true"
                             @dragstart="startDrag($event, @js($node))">
                            <x-icon :name="$node['icon']" class="w-4 h-4" />
                            <span>{{ $node['name'] }}</span>
                        </div>
                    @endforeach
                </div>
            </div>
        @endforeach
    </div>
</div>

<script>
function nodePalette() {
    return {
        search: '',
        expanded: ['triggers', 'actions'],
        
        toggleCategory(key) {
            const index = this.expanded.indexOf(key);
            if (index > -1) {
                this.expanded.splice(index, 1);
            } else {
                this.expanded.push(key);
            }
        },
        
        isExpanded(key) {
            return this.expanded.includes(key);
        },
        
        categoryVisible(key) {
            if (!this.search) return true;
            // Check if any node in category matches
            return true; // Simplified
        },
        
        nodeVisible(id) {
            if (!this.search) return true;
            return id.toLowerCase().includes(this.search.toLowerCase());
        },
        
        startDrag(event, node) {
            event.dataTransfer.setData('application/json', JSON.stringify(node));
            event.dataTransfer.effectAllowed = 'copy';
        },
    };
}
</script>
```

### Execution Timeline Component

```blade
{{-- resources/views/components/workflow/execution-timeline.blade.php --}}
@props(['steps'])

<div class="execution-timeline">
    @foreach($steps as $step)
        <div class="execution-step {{ 'execution-step--' . $step['status'] }}">
            <div class="execution-step__time">
                {{ $step['started_at']->format('H:i:s.v') }}
            </div>
            
            <div class="execution-step__indicator">
                @if($step['status'] === 'success')
                    <span class="execution-step__dot execution-step__dot--success">✓</span>
                @elseif($step['status'] === 'error')
                    <span class="execution-step__dot execution-step__dot--error">✗</span>
                @elseif($step['status'] === 'running')
                    <span class="execution-step__dot execution-step__dot--running">⟳</span>
                @else
                    <span class="execution-step__dot">○</span>
                @endif
                <div class="execution-step__line"></div>
            </div>
            
            <div class="execution-step__content">
                <div class="execution-step__header">
                    <x-icon :name="$step['icon']" class="w-4 h-4" />
                    <span class="execution-step__name">{{ $step['name'] }}</span>
                    <span class="execution-step__duration">{{ $step['duration'] }}ms</span>
                </div>
                
                @if($step['message'])
                    <div class="execution-step__message">{{ $step['message'] }}</div>
                @endif
                
                @if($step['error'])
                    <div class="execution-step__error">{{ $step['error'] }}</div>
                @endif
                
                <button @click="inspect('{{ $step['id'] }}')" class="execution-step__inspect">
                    Inspect Data
                </button>
            </div>
        </div>
    @endforeach
</div>
```
