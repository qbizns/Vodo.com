# Plugin Management - Screen Specifications

## Screen 1: Plugin Marketplace

### Purpose
Allow administrators to discover, preview, and install plugins from a remote repository or local uploads.

### URL
`/admin/plugins/marketplace`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Plugin Marketplace                                        [Upload Plugin]   │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ 🔍 Search plugins...                              [Category ▼] [Sort ▼] │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Categories: [All] [CRM] [Accounting] [HR] [Inventory] [Reports] [Utils]    │
│                                                                             │
│ ┌─────────────────────┐ ┌─────────────────────┐ ┌─────────────────────┐    │
│ │ ┌─────────────────┐ │ │ ┌─────────────────┐ │ │ ┌─────────────────┐ │    │
│ │ │   Plugin Icon   │ │ │ │   Plugin Icon   │ │ │ │   Plugin Icon   │ │    │
│ │ └─────────────────┘ │ │ └─────────────────┘ │ │ └─────────────────┘ │    │
│ │ Invoice Manager     │ │ HR Management       │ │ Advanced Reports    │    │
│ │ ★★★★☆ (124)        │ │ ★★★★★ (89)         │ │ ★★★★☆ (56)         │    │
│ │ by Vendor Name      │ │ by Vendor Name      │ │ by Vendor Name      │    │
│ │                     │ │                     │ │                     │    │
│ │ Manage invoices,    │ │ Complete HR suite   │ │ Build custom        │    │
│ │ payments, and...    │ │ with employee...    │ │ reports with...     │    │
│ │                     │ │                     │ │                     │    │
│ │ v2.1.0 | 10K+ inst  │ │ v3.0.0 | 5K+ inst  │ │ v1.5.0 | 2K+ inst  │    │
│ │ ✓ Compatible        │ │ ✓ Compatible        │ │ ⚠ Requires v2.0+   │    │
│ │                     │ │                     │ │                     │    │
│ │ [View] [Install]    │ │ [View] [Install]    │ │ [View] [Install]    │    │
│ └─────────────────────┘ └─────────────────────┘ └─────────────────────┘    │
│                                                                             │
│ ┌─────────────────────┐ ┌─────────────────────┐ ┌─────────────────────┐    │
│ │       ...           │ │       ...           │ │       ...           │    │
│ └─────────────────────┘ └─────────────────────┘ └─────────────────────┘    │
│                                                                             │
│                        [1] [2] [3] ... [10] [Next →]                       │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Requirements

```php
// Controller data
$data = [
    'plugins' => $marketplaceClient->search([
        'query' => $request->query('q'),
        'category' => $request->query('category'),
        'sort' => $request->query('sort', 'popular'),
        'page' => $request->query('page', 1),
        'per_page' => 12,
    ]),
    'categories' => $marketplaceClient->getCategories(),
    'installed' => Plugin::pluck('slug')->toArray(),
];
```

### Plugin Card Data Structure
```php
[
    'slug' => 'invoice-manager',
    'name' => 'Invoice Manager',
    'description' => 'Manage invoices, payments, and billing...',
    'short_description' => 'Manage invoices, payments...',
    'version' => '2.1.0',
    'author' => [
        'name' => 'Vendor Name',
        'url' => 'https://vendor.com',
    ],
    'icon' => 'https://marketplace.../icon.png',
    'screenshots' => [...],
    'rating' => 4.2,
    'reviews_count' => 124,
    'downloads' => 10500,
    'category' => 'accounting',
    'tags' => ['invoice', 'billing', 'payment'],
    'requires' => '2.0.0',  // Minimum system version
    'tested' => '2.5.0',    // Tested up to
    'requires_php' => '8.1',
    'dependencies' => ['core-finance'],  // Required plugins
    'is_premium' => false,
    'price' => null,
    'compatibility' => 'compatible', // compatible|requires_update|incompatible
]
```

### User Interactions

| Action | Trigger | Result |
|--------|---------|--------|
| Search | Type in search box | Filter plugins by name/description |
| Filter by category | Click category tab | Show only category plugins |
| Sort | Change sort dropdown | Reorder by popular/newest/rating |
| View details | Click "View" or card | Navigate to plugin details |
| Install | Click "Install" | Start installation wizard |
| Upload | Click "Upload Plugin" | Open upload modal |

### States

1. **Loading**: Skeleton cards while fetching from marketplace
2. **Empty**: No plugins match search/filter criteria
3. **Error**: Marketplace unavailable (show cached or retry option)
4. **Offline Mode**: When marketplace is disabled, show upload only

---

## Screen 2: Installed Plugins List

### Purpose
Display all installed plugins with their status, version, and quick actions.

### URL
`/admin/plugins`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Installed Plugins                    [Check Updates] [Upload] [Marketplace] │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ 🔍 Search installed plugins...        [Status ▼] [Category ▼] [View ▼] │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Showing 12 of 24 plugins                              [□ Select All]       │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ □ │ 🔌 │ Invoice Manager          │ Active  │ v2.1.0 │ Accounting │ ⋮ │ │
│ │   │    │ Manage invoices and...   │ ●       │        │            │   │ │
│ ├───┼────┼──────────────────────────┼─────────┼────────┼────────────┼───┤ │
│ │ □ │ 👥 │ HR Management            │ Active  │ v3.0.0 │ HR         │ ⋮ │ │
│ │   │    │ Complete HR suite...     │ ●       │ ⬆ 3.1  │            │   │ │
│ ├───┼────┼──────────────────────────┼─────────┼────────┼────────────┼───┤ │
│ │ □ │ 📊 │ Advanced Reports         │ Inactive│ v1.5.0 │ Reports    │ ⋮ │ │
│ │   │    │ Build custom reports...  │ ○       │        │            │   │ │
│ ├───┼────┼──────────────────────────┼─────────┼────────┼────────────┼───┤ │
│ │ □ │ 📦 │ Inventory Control        │ Active  │ v1.2.0 │ Inventory  │ ⋮ │ │
│ │   │    │ Stock management...      │ ●       │ ⬆ 1.3  │            │   │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ With selected: [Activate] [Deactivate] [Update] [Delete]                    │
│                                                                             │
│ ─────────────────────────────────────────────────────────────────────────── │
│ Quick Stats:  24 Installed  │  18 Active  │  3 Updates Available  │  2 Lic │
└─────────────────────────────────────────────────────────────────────────────┘

Action Menu (⋮):
┌──────────────────┐
│ ⚙ Settings       │
│ 📖 Documentation │
│ 🔄 Update        │
│ ─────────────────│
│ ✓ Activate       │
│ ○ Deactivate     │
│ ─────────────────│
│ 🗑 Uninstall     │
└──────────────────┘
```

### Data Requirements

```php
$data = [
    'plugins' => Plugin::query()
        ->when($request->status, fn($q, $s) => $q->where('status', $s))
        ->when($request->category, fn($q, $c) => $q->where('category', $c))
        ->when($request->search, fn($q, $s) => $q->search($s))
        ->orderBy($request->sort ?? 'name')
        ->paginate(20),
    'stats' => [
        'total' => Plugin::count(),
        'active' => Plugin::active()->count(),
        'updates' => Plugin::hasUpdate()->count(),
        'licenses_expiring' => PluginLicense::expiringSoon()->count(),
    ],
    'categories' => Plugin::distinct('category')->pluck('category'),
];
```

### Plugin Row Data
```php
[
    'id' => 1,
    'slug' => 'invoice-manager',
    'name' => 'Invoice Manager',
    'description' => 'Manage invoices...',
    'version' => '2.1.0',
    'status' => 'active', // active|inactive|error
    'category' => 'accounting',
    'icon' => '/plugins/invoice-manager/icon.png',
    'has_settings' => true,
    'has_update' => true,
    'latest_version' => '2.2.0',
    'is_core' => false, // Core plugins cannot be deactivated
    'has_license' => true,
    'license_valid' => true,
    'error_message' => null,
]
```

### Bulk Actions Logic

```php
// Bulk activate
public function bulkActivate(Request $request)
{
    $plugins = Plugin::whereIn('id', $request->plugins)->get();
    
    foreach ($plugins as $plugin) {
        if ($plugin->canActivate()) {
            $this->pluginManager->activate($plugin);
        }
    }
    
    return back()->with('success', 'Plugins activated');
}

// Bulk update
public function bulkUpdate(Request $request)
{
    $plugins = Plugin::whereIn('id', $request->plugins)
        ->where('has_update', true)
        ->get();
    
    foreach ($plugins as $plugin) {
        UpdatePluginJob::dispatch($plugin);
    }
    
    return back()->with('success', 'Updates queued');
}
```

---

## Screen 3: Plugin Details

### Purpose
Show comprehensive information about a single plugin including description, screenshots, changelog, permissions, and settings.

### URL
`/admin/plugins/{plugin}`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Back to Plugins                                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │  ┌──────┐                                                              │  │
│ │  │ ICON │  Invoice Manager                              [Deactivate]  │  │
│ │  └──────┘  by Vendor Name                               [Settings]    │  │
│ │            v2.1.0 • Accounting • ★★★★☆ (124 reviews)    [Uninstall]   │  │
│ │            ✓ Active                                                    │  │
│ └────────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│ [Overview] [Screenshots] [Changelog] [Permissions] [Dependencies] [Support] │
│ ════════════════════════════════════════════════════════════════════════════│
│                                                                             │
│ ## Overview Tab                                                             │
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │                                                                        │  │
│ │  Invoice Manager is a comprehensive invoicing solution that allows    │  │
│ │  you to create, send, and track invoices with ease. Features include: │  │
│ │                                                                        │  │
│ │  • Create professional invoices with customizable templates           │  │
│ │  • Send invoices via email directly from the system                   │  │
│ │  • Track payment status and send reminders                            │  │
│ │  • Generate financial reports and analytics                           │  │
│ │  • Multi-currency support                                             │  │
│ │  • Integration with popular payment gateways                          │  │
│ │                                                                        │  │
│ └────────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│ ## Plugin Information                                                       │
│ ┌─────────────────────────────┐ ┌──────────────────────────────────────┐   │
│ │ Version:     2.1.0          │ │ Requirements:                        │   │
│ │ Released:    Dec 10, 2024   │ │ • System: 2.0.0+                     │   │
│ │ Downloads:   10,500+        │ │ • PHP: 8.1+                          │   │
│ │ Last Update: 2 days ago     │ │ • MySQL: 5.7+                        │   │
│ │ License:     Commercial     │ │ • Dependencies: core-finance         │   │
│ └─────────────────────────────┘ └──────────────────────────────────────┘   │
│                                                                             │
│ ## Registered Components                                                    │
│ ┌────────────────────────────────────────────────────────────────────────┐  │
│ │ 📋 Permissions: 12  │ 📊 Widgets: 3  │ 📁 Entities: 4  │ ⚡ Tasks: 2   │  │
│ │ 🔗 API Endpoints: 8 │ 📑 Menu Items: 5│ 🔄 Workflows: 2 │ 🏷 Shortcodes│  │
│ └────────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘

## Screenshots Tab
┌─────────────────────────────────────────────────────────────────────────────┐
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │
│  │             │ │             │ │             │ │             │           │
│  │  Screenshot │ │  Screenshot │ │  Screenshot │ │  Screenshot │           │
│  │      1      │ │      2      │ │      3      │ │      4      │           │
│  │             │ │             │ │             │ │             │           │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘           │
│  Invoice List    Create Invoice  Payment Track   Reports                   │
└─────────────────────────────────────────────────────────────────────────────┘

## Changelog Tab
┌─────────────────────────────────────────────────────────────────────────────┐
│ Version 2.1.0 (December 10, 2024)                                          │
│ ─────────────────────────────────────────────────────────────────────────── │
│ • Added: Multi-currency support                                             │
│ • Added: PayPal integration                                                 │
│ • Fixed: PDF generation on large invoices                                   │
│ • Improved: Invoice list performance                                        │
│                                                                             │
│ Version 2.0.0 (November 1, 2024)                                           │
│ ─────────────────────────────────────────────────────────────────────────── │
│ • Breaking: Updated to new plugin architecture                              │
│ • Added: Recurring invoices                                                 │
│ • Added: Customer portal                                                    │
└─────────────────────────────────────────────────────────────────────────────┘

## Permissions Tab
┌─────────────────────────────────────────────────────────────────────────────┐
│ This plugin registers the following permissions:                            │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Permission                    │ Description                │ Default   │ │
│ ├───────────────────────────────┼────────────────────────────┼───────────┤ │
│ │ invoices.view                 │ View invoices              │ All users │ │
│ │ invoices.create               │ Create new invoices        │ Editors   │ │
│ │ invoices.edit                 │ Edit existing invoices     │ Editors   │ │
│ │ invoices.delete               │ Delete invoices            │ Admins    │ │
│ │ invoices.send                 │ Send invoices via email    │ Editors   │ │
│ │ invoices.export               │ Export invoice data        │ Managers  │ │
│ │ invoices.reports              │ Access invoice reports     │ Managers  │ │
│ │ invoices.settings             │ Configure plugin settings  │ Admins    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

## Dependencies Tab
┌─────────────────────────────────────────────────────────────────────────────┐
│                           invoice-manager                                   │
│                                  │                                          │
│                    ┌─────────────┼─────────────┐                            │
│                    ▼             ▼             ▼                            │
│              core-finance   pdf-generator   email-service                   │
│                    │                              │                          │
│                    ▼                              ▼                          │
│              core-reports                   queue-manager                    │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Plugin          │ Required │ Installed │ Status                         │ │
│ ├─────────────────┼──────────┼───────────┼────────────────────────────────┤ │
│ │ core-finance    │ ^1.5.0   │ 1.6.2     │ ✓ Compatible                   │ │
│ │ pdf-generator   │ ^2.0.0   │ 2.1.0     │ ✓ Compatible                   │ │
│ │ email-service   │ ^1.0.0   │ 1.2.0     │ ✓ Compatible                   │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Dependents (plugins that require this plugin):                              │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ • subscription-billing (requires invoice-manager ^2.0.0)                │ │
│ │ • customer-portal (requires invoice-manager ^1.5.0)                     │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Requirements

```php
public function show(Plugin $plugin)
{
    $pluginInstance = $this->pluginManager->getPluginInstance($plugin->slug);
    
    return view('admin.plugins.show', [
        'plugin' => $plugin,
        'manifest' => $pluginInstance->getManifest(),
        'screenshots' => $pluginInstance->getScreenshots(),
        'changelog' => $pluginInstance->getChangelog(),
        'permissions' => $this->permissionRegistry->getByPlugin($plugin->slug),
        'dependencies' => $this->getDependencyTree($plugin),
        'dependents' => $this->getDependentPlugins($plugin),
        'components' => [
            'permissions' => Permission::where('plugin', $plugin->slug)->count(),
            'widgets' => DashboardWidget::where('plugin', $plugin->slug)->count(),
            'entities' => EntityDefinition::where('plugin', $plugin->slug)->count(),
            'tasks' => ScheduledTask::where('plugin', $plugin->slug)->count(),
            'endpoints' => ApiEndpoint::where('plugin', $plugin->slug)->count(),
            'menus' => MenuItem::where('plugin', $plugin->slug)->count(),
            'workflows' => WorkflowDefinition::where('plugin', $plugin->slug)->count(),
            'shortcodes' => Shortcode::where('plugin', $plugin->slug)->count(),
        ],
    ]);
}
```

---

## Screen 4: Plugin Installation Wizard

### Purpose
Guide users through a multi-step installation process with dependency resolution, permission review, and migration execution.

### URL
`/admin/plugins/install/{slug}/*`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Install Plugin: Invoice Manager                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│    ┌─────┐      ┌─────┐      ┌─────┐      ┌─────┐      ┌─────┐            │
│    │  1  │ ───▶ │  2  │ ───▶ │  3  │ ───▶ │  4  │ ───▶ │  5  │            │
│    │ ●●● │      │ ○○○ │      │ ○○○ │      │ ○○○ │      │ ○○○ │            │
│    └─────┘      └─────┘      └─────┘      └─────┘      └─────┘            │
│    Upload     Dependencies  Permissions   Install     Complete             │
│                                                                             │
│ ═══════════════════════════════════════════════════════════════════════════ │
│                                                                             │
│ ## Step 1: Upload / Select Plugin                                          │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │                                                                         │ │
│ │  ┌─────────────────────────────────────────────────────────────────┐   │ │
│ │  │                                                                 │   │ │
│ │  │                    📁 Drop plugin ZIP here                      │   │ │
│ │  │                         or click to browse                      │   │ │
│ │  │                                                                 │   │ │
│ │  │                    Accepted: .zip (max 50MB)                    │   │ │
│ │  │                                                                 │   │ │
│ │  └─────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ │  ────────────────────────── OR ──────────────────────────────────────  │ │
│ │                                                                         │ │
│ │  Install from Marketplace:                                              │ │
│ │  ┌─────────────────────────────────────────────────────────────────┐   │ │
│ │  │ 🔍 Search marketplace...                                        │   │ │
│ │  └─────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                              [Cancel]  [Next: Dependencies] │
└─────────────────────────────────────────────────────────────────────────────┘

## Step 2: Dependencies Check
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  Invoice Manager requires the following dependencies:                       │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Dependency        │ Required │ Status                               │   │
│  ├───────────────────┼──────────┼──────────────────────────────────────┤   │
│  │ core-finance      │ ^1.5.0   │ ✓ Installed (1.6.2)                  │   │
│  │ pdf-generator     │ ^2.0.0   │ ⚠ Will be installed (2.1.0)         │   │
│  │ email-service     │ ^1.0.0   │ ✓ Installed (1.2.0)                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ⚠ The following plugins will be installed automatically:                  │
│  • pdf-generator v2.1.0 (Required by invoice-manager)                       │
│                                                                             │
│  ℹ System Requirements:                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Requirement       │ Required │ Current  │ Status                    │   │
│  ├───────────────────┼──────────┼──────────┼───────────────────────────┤   │
│  │ PHP Version       │ 8.1+     │ 8.2.0    │ ✓ OK                      │   │
│  │ System Version    │ 2.0.0+   │ 2.3.0    │ ✓ OK                      │   │
│  │ MySQL Version     │ 5.7+     │ 8.0.0    │ ✓ OK                      │   │
│  │ Disk Space        │ 50MB     │ 2.3GB    │ ✓ OK                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│                                    [← Back]  [Cancel]  [Next: Permissions] │
└─────────────────────────────────────────────────────────────────────────────┘

## Step 3: Permissions Review
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  This plugin will register the following permissions:                       │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Permission              │ Description              │ Risk Level     │   │
│  ├─────────────────────────┼──────────────────────────┼────────────────┤   │
│  │ invoices.view           │ View invoices            │ 🟢 Low         │   │
│  │ invoices.create         │ Create new invoices      │ 🟢 Low         │   │
│  │ invoices.edit           │ Edit existing invoices   │ 🟡 Medium      │   │
│  │ invoices.delete         │ Delete invoices          │ 🔴 High        │   │
│  │ invoices.send           │ Send invoices via email  │ 🟡 Medium      │   │
│  │ invoices.export         │ Export invoice data      │ 🟡 Medium      │   │
│  │ invoices.settings       │ Configure plugin         │ 🔴 High        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ⚠ This plugin requests access to:                                         │
│  • Database: Create 4 new tables                                            │
│  • File System: Read/write to storage/invoices                              │
│  • External Services: PayPal, Stripe APIs                                   │
│  • Email: Send emails on behalf of users                                    │
│                                                                             │
│  □ I understand and accept these permissions                                │
│                                                                             │
│                                        [← Back]  [Cancel]  [Next: Install] │
└─────────────────────────────────────────────────────────────────────────────┘

## Step 4: Installation Progress
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  Installing Invoice Manager...                                              │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ ████████████████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  65% │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ✓ Downloading plugin...                                    [Complete]     │
│  ✓ Verifying package integrity...                           [Complete]     │
│  ✓ Extracting files...                                      [Complete]     │
│  ✓ Installing dependencies (pdf-generator)...               [Complete]     │
│  ● Running database migrations...                           [In Progress]  │
│  ○ Registering permissions...                               [Pending]      │
│  ○ Publishing assets...                                     [Pending]      │
│  ○ Clearing caches...                                       [Pending]      │
│                                                                             │
│  Current: Running migration 2024_01_15_create_invoices_table               │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ > Creating table: invoices                                          │   │
│  │ > Creating table: invoice_items                                     │   │
│  │ > Creating table: invoice_payments                                  │   │
│  │ > Adding foreign keys...                                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│                                                              [Cancel]       │
└─────────────────────────────────────────────────────────────────────────────┘

## Step 5: Installation Complete
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                              ✓                                              │
│                                                                             │
│                    Installation Complete!                                   │
│                                                                             │
│  Invoice Manager v2.1.0 has been successfully installed.                   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Summary:                                                            │   │
│  │ • 4 database tables created                                         │   │
│  │ • 8 permissions registered                                          │   │
│  │ • 3 dashboard widgets added                                         │   │
│  │ • 5 menu items added                                                │   │
│  │ • 1 dependency installed (pdf-generator)                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  What's next?                                                               │
│  • Configure plugin settings                                                │
│  • Assign permissions to roles                                              │
│  • Read the documentation                                                   │
│                                                                             │
│       [Go to Settings]  [Assign Permissions]  [View Plugin]  [Done]        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Installation Process Logic

```php
class PluginInstallationService
{
    public function install(string $slug, array $options = []): InstallationResult
    {
        $result = new InstallationResult();
        
        DB::beginTransaction();
        
        try {
            // Step 1: Download/extract
            $this->emit('progress', ['step' => 'download', 'status' => 'running']);
            $path = $this->downloadPlugin($slug);
            $this->emit('progress', ['step' => 'download', 'status' => 'complete']);
            
            // Step 2: Verify
            $this->emit('progress', ['step' => 'verify', 'status' => 'running']);
            $manifest = $this->verifyPlugin($path);
            $this->emit('progress', ['step' => 'verify', 'status' => 'complete']);
            
            // Step 3: Install dependencies
            foreach ($manifest['dependencies'] as $dep => $version) {
                if (!$this->pluginManager->isInstalled($dep)) {
                    $this->emit('progress', ['step' => 'dependency', 'plugin' => $dep, 'status' => 'running']);
                    $this->install($dep); // Recursive
                    $this->emit('progress', ['step' => 'dependency', 'plugin' => $dep, 'status' => 'complete']);
                }
            }
            
            // Step 4: Run migrations
            $this->emit('progress', ['step' => 'migrations', 'status' => 'running']);
            $this->runMigrations($path);
            $this->emit('progress', ['step' => 'migrations', 'status' => 'complete']);
            
            // Step 5: Register plugin
            $this->emit('progress', ['step' => 'register', 'status' => 'running']);
            $plugin = $this->registerPlugin($manifest);
            $this->emit('progress', ['step' => 'register', 'status' => 'complete']);
            
            // Step 6: Publish assets
            $this->emit('progress', ['step' => 'assets', 'status' => 'running']);
            $this->publishAssets($path);
            $this->emit('progress', ['step' => 'assets', 'status' => 'complete']);
            
            // Step 7: Clear caches
            $this->emit('progress', ['step' => 'cache', 'status' => 'running']);
            $this->clearCaches();
            $this->emit('progress', ['step' => 'cache', 'status' => 'complete']);
            
            DB::commit();
            
            $result->success = true;
            $result->plugin = $plugin;
            
        } catch (\Exception $e) {
            DB::rollBack();
            $this->rollback($slug);
            
            $result->success = false;
            $result->error = $e->getMessage();
        }
        
        return $result;
    }
}
```

---

## Screen 5: Plugin Settings

### Purpose
Render dynamic settings form based on plugin's `getSettingsFields()` method.

### URL
`/admin/plugins/{plugin}/settings`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Back to Invoice Manager                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│ Plugin Settings: Invoice Manager                              [Save Changes]│
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [General] [Email] [Templates] [Payment Gateways] [Advanced]                 │
│ ════════════════════════════════════════════════════════════════════════════│
│                                                                             │
│ ## General Settings                                                         │
│                                                                             │
│ Invoice Prefix                                                              │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ INV-                                                                    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│ ℹ This prefix will be added to all invoice numbers                         │
│                                                                             │
│ Default Due Days                                                            │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ 30                                                                      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│ ℹ Number of days until invoice is due                                      │
│                                                                             │
│ Default Currency                                                            │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ USD - US Dollar                                                       ▼ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Tax Settings                                                                │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ □ Enable tax calculation                                                │ │
│ │                                                                         │ │
│ │ Default Tax Rate (%)                                                    │ │
│ │ ┌─────────────┐                                                         │ │
│ │ │ 10          │                                                         │ │
│ │ └─────────────┘                                                         │ │
│ │                                                                         │ │
│ │ Tax Label                                                               │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ VAT                                                                 │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ─────────────────────────────────────────────────────────────────────────── │
│                                                                             │
│ ## Email Settings Tab                                                       │
│                                                                             │
│ Send Invoice Email Automatically                                            │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ ● Yes  ○ No                                                             │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Email Template                                                              │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Dear {customer_name},                                                   │ │
│ │                                                                         │ │
│ │ Please find attached invoice {invoice_number} for {amount}.            │ │
│ │                                                                         │ │
│ │ Due Date: {due_date}                                                    │ │
│ │                                                                         │ │
│ │ Available variables: {customer_name}, {invoice_number}, {amount},      │ │
│ │ {due_date}, {company_name}, {payment_link}                             │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                              [Reset to Defaults] [Save]     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Settings Field Definition (Plugin Side)

```php
// In plugin's BasePlugin class
public function getSettingsFields(): array
{
    return [
        'tabs' => [
            'general' => ['label' => 'General', 'icon' => 'settings'],
            'email' => ['label' => 'Email', 'icon' => 'mail'],
            'templates' => ['label' => 'Templates', 'icon' => 'file-text'],
            'payment' => ['label' => 'Payment Gateways', 'icon' => 'credit-card'],
            'advanced' => ['label' => 'Advanced', 'icon' => 'sliders'],
        ],
        'fields' => [
            [
                'key' => 'invoice_prefix',
                'type' => 'text',
                'label' => 'Invoice Prefix',
                'tab' => 'general',
                'default' => 'INV-',
                'hint' => 'This prefix will be added to all invoice numbers',
                'rules' => 'required|string|max:10',
            ],
            [
                'key' => 'default_due_days',
                'type' => 'number',
                'label' => 'Default Due Days',
                'tab' => 'general',
                'default' => 30,
                'min' => 1,
                'max' => 365,
                'hint' => 'Number of days until invoice is due',
                'rules' => 'required|integer|min:1|max:365',
            ],
            [
                'key' => 'default_currency',
                'type' => 'select',
                'label' => 'Default Currency',
                'tab' => 'general',
                'default' => 'USD',
                'options' => fn() => Currency::pluck('name', 'code'),
                'rules' => 'required|string|size:3',
            ],
            [
                'key' => 'tax_settings',
                'type' => 'group',
                'label' => 'Tax Settings',
                'tab' => 'general',
                'fields' => [
                    [
                        'key' => 'enabled',
                        'type' => 'checkbox',
                        'label' => 'Enable tax calculation',
                        'default' => false,
                    ],
                    [
                        'key' => 'rate',
                        'type' => 'number',
                        'label' => 'Default Tax Rate (%)',
                        'default' => 10,
                        'step' => 0.01,
                        'condition' => ['field' => 'tax_settings.enabled', 'value' => true],
                    ],
                    [
                        'key' => 'label',
                        'type' => 'text',
                        'label' => 'Tax Label',
                        'default' => 'VAT',
                        'condition' => ['field' => 'tax_settings.enabled', 'value' => true],
                    ],
                ],
            ],
            [
                'key' => 'auto_send_email',
                'type' => 'radio',
                'label' => 'Send Invoice Email Automatically',
                'tab' => 'email',
                'default' => true,
                'options' => [
                    true => 'Yes',
                    false => 'No',
                ],
            ],
            [
                'key' => 'email_template',
                'type' => 'textarea',
                'label' => 'Email Template',
                'tab' => 'email',
                'rows' => 10,
                'hint' => 'Available variables: {customer_name}, {invoice_number}, {amount}, {due_date}, {company_name}, {payment_link}',
                'default' => "Dear {customer_name},\n\nPlease find attached invoice {invoice_number} for {amount}.\n\nDue Date: {due_date}",
            ],
        ],
    ];
}
```

### Dynamic Form Renderer

```php
// resources/views/admin/plugins/settings.blade.php
@extends('admin.layouts.app')

@section('content')
<form action="{{ route('admin.plugins.settings.update', $plugin) }}" method="POST">
    @csrf
    @method('PUT')
    
    {{-- Tab Navigation --}}
    <div class="tabs">
        @foreach($settingsFields['tabs'] as $tabKey => $tab)
            <button type="button" class="tab-btn" data-tab="{{ $tabKey }}">
                <x-icon :name="$tab['icon']" />
                {{ $tab['label'] }}
            </button>
        @endforeach
    </div>
    
    {{-- Tab Content --}}
    @foreach($settingsFields['tabs'] as $tabKey => $tab)
        <div class="tab-content" id="tab-{{ $tabKey }}">
            @foreach($settingsFields['fields'] as $field)
                @if(($field['tab'] ?? 'general') === $tabKey)
                    <x-settings-field 
                        :field="$field" 
                        :value="$settings[$field['key']] ?? $field['default'] ?? null"
                        :errors="$errors"
                    />
                @endif
            @endforeach
        </div>
    @endforeach
    
    <div class="form-actions">
        <button type="button" onclick="resetToDefaults()">Reset to Defaults</button>
        <button type="submit">Save Changes</button>
    </div>
</form>
@endsection
```

---

## Screen 6: Plugin Updates

### Purpose
Display available updates for installed plugins with changelog preview and batch update capability.

### URL
`/admin/plugins/updates`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Plugin Updates                                    [Check for Updates] [↻]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ ℹ 3 updates available                                  [Update All]    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ □ │ Invoice Manager                    2.1.0 → 2.2.0  │ [View] [Update]│ │
│ │   │ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │ │
│ │   │ What's new in 2.2.0:                                               │ │
│ │   │ • Added: Stripe payment integration                                │ │
│ │   │ • Fixed: PDF export memory issue                                   │ │
│ │   │ • Improved: Dashboard widget performance                           │ │
│ │   │                                                     [Full changelog]│ │
│ ├───┼─────────────────────────────────────────────────────────────────────┤ │
│ │ □ │ Inventory Control                  1.2.0 → 1.3.0  │ [View] [Update]│ │
│ │   │ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │ │
│ │   │ What's new in 1.3.0:                                               │ │
│ │   │ • Added: Barcode scanner support                                   │ │
│ │   │ • Added: Stock level alerts                                        │ │
│ │   │                                                     [Full changelog]│ │
│ ├───┼─────────────────────────────────────────────────────────────────────┤ │
│ │ □ │ HR Management                      3.0.0 → 3.1.0  │ [View] [Update]│ │
│ │   │ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │ │
│ │   │ ⚠ Breaking changes in this update                                  │ │
│ │   │ • Requires PHP 8.2+                                                │ │
│ │   │ • Database migration required                                       │ │
│ │   │                                                     [Full changelog]│ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ─────────────────────────────────────────────────────────────────────────── │
│ Last checked: 5 minutes ago                         Auto-check: [Enabled ▼] │
└─────────────────────────────────────────────────────────────────────────────┘

## Update Confirmation Modal
┌─────────────────────────────────────────────────────────────────────────────┐
│ Update Invoice Manager                                              [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ You are about to update Invoice Manager from v2.1.0 to v2.2.0              │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ ⚠ Before updating:                                                     │ │
│ │ • A backup of your data will be created automatically                  │ │
│ │ • The plugin will be temporarily deactivated during update             │ │
│ │ • Database migrations will run automatically                           │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ □ I have backed up my database                                              │
│ □ I understand this may cause temporary downtime                            │
│                                                                             │
│                                              [Cancel]  [Update Now]         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 7: Plugin Dependencies Viewer

### Purpose
Visualize the dependency tree for a plugin, showing what it requires and what depends on it.

### URL
`/admin/plugins/{plugin}/dependencies`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Dependencies: Invoice Manager                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [Dependencies] [Dependents] [Conflicts]                                     │
│ ════════════════════════════════════════════════════════════════════════════│
│                                                                             │
│ ## Dependency Tree                                                          │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                      ┌──────────────────┐                          │   │
│  │                      │ invoice-manager  │                          │   │
│  │                      │     v2.1.0       │                          │   │
│  │                      └────────┬─────────┘                          │   │
│  │               ┌───────────────┼───────────────┐                    │   │
│  │               ▼               ▼               ▼                    │   │
│  │      ┌──────────────┐ ┌──────────────┐ ┌──────────────┐           │   │
│  │      │ core-finance │ │pdf-generator │ │email-service │           │   │
│  │      │    v1.6.2    │ │    v2.1.0    │ │    v1.2.0    │           │   │
│  │      │   ✓ OK       │ │   ✓ OK       │ │   ✓ OK       │           │   │
│  │      └──────┬───────┘ └──────────────┘ └──────┬───────┘           │   │
│  │             ▼                                  ▼                    │   │
│  │      ┌──────────────┐                  ┌──────────────┐           │   │
│  │      │ core-reports │                  │queue-manager │           │   │
│  │      │    v1.0.0    │                  │    v1.1.0    │           │   │
│  │      │   ✓ OK       │                  │   ✓ OK       │           │   │
│  │      └──────────────┘                  └──────────────┘           │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│ ## Dependencies Table                                                       │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Plugin          │ Required │ Installed │ Status    │ Actions           │ │
│ ├─────────────────┼──────────┼───────────┼───────────┼───────────────────┤ │
│ │ core-finance    │ ^1.5.0   │ 1.6.2     │ ✓ OK      │ [View]            │ │
│ │ pdf-generator   │ ^2.0.0   │ 2.1.0     │ ✓ OK      │ [View]            │ │
│ │ email-service   │ ^1.0.0   │ 1.2.0     │ ✓ OK      │ [View]            │ │
│ │ core-reports    │ ^1.0.0   │ 1.0.0     │ ✓ OK      │ [View] (indirect) │ │
│ │ queue-manager   │ ^1.0.0   │ 1.1.0     │ ✓ OK      │ [View] (indirect) │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ## Dependents (plugins that require Invoice Manager)                        │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Plugin               │ Requires         │ Status                        │ │
│ ├──────────────────────┼──────────────────┼───────────────────────────────┤ │
│ │ subscription-billing │ ^2.0.0           │ ✓ Compatible (current: 2.1.0) │ │
│ │ customer-portal      │ ^1.5.0           │ ✓ Compatible (current: 2.1.0) │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ⚠ Warning: Uninstalling this plugin will affect 2 dependent plugins        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 8: Plugin License Manager

### Purpose
Manage licenses for premium plugins including activation, renewal, and status tracking.

### URL
`/admin/plugins/licenses`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Plugin Licenses                                         [+ Add License Key] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ License Overview                                                        │ │
│ │ ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────┐            │ │
│ │ │     5      │ │     4      │ │     1      │ │     0      │            │ │
│ │ │   Total    │ │   Active   │ │  Expiring  │ │  Expired   │            │ │
│ │ └────────────┘ └────────────┘ └────────────┘ └────────────┘            │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Plugin              │ License Key      │ Status  │ Expires   │ Actions │ │
│ ├─────────────────────┼──────────────────┼─────────┼───────────┼─────────┤ │
│ │ Invoice Manager Pro │ XXXX-XXXX-XXXX   │ ● Active│ Dec 2025  │ [⋮]     │ │
│ │ HR Suite Enterprise │ XXXX-XXXX-XXXX   │ ● Active│ Mar 2025  │ [⋮]     │ │
│ │ Advanced Reports    │ XXXX-XXXX-XXXX   │ ● Active│ Jan 2025  │ [⋮]     │ │
│ │ CRM Professional    │ XXXX-XXXX-XXXX   │ ⚠ Soon  │ 15 days   │ [⋮]     │ │
│ │ Inventory Plus      │ Not activated    │ ○ None  │ -         │ [⋮]     │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Actions Menu:                                                               │
│ • View Details                                                              │
│ • Deactivate License                                                        │
│ • Transfer License                                                          │
│ • Renew License                                                             │
│ • View Purchase History                                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

## Add License Modal
┌─────────────────────────────────────────────────────────────────────────────┐
│ Activate Plugin License                                             [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ Plugin                                                                      │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Select plugin...                                                      ▼ │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ License Key                                                                 │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ XXXX-XXXX-XXXX-XXXX                                                     │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ℹ Enter the license key you received after purchase. The license will be  │
│   validated against our license server.                                     │
│                                                                             │
│                                              [Cancel]  [Activate License]   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### License Validation Logic

```php
class LicenseManager
{
    public function activate(string $pluginSlug, string $licenseKey): LicenseResult
    {
        // Validate with remote server
        $response = Http::post($this->licenseServer . '/activate', [
            'license_key' => $licenseKey,
            'plugin' => $pluginSlug,
            'domain' => config('app.url'),
            'instance_id' => $this->getInstanceId(),
        ]);
        
        if ($response->successful()) {
            $data = $response->json();
            
            PluginLicense::updateOrCreate(
                ['plugin_slug' => $pluginSlug],
                [
                    'license_key' => $this->encrypt($licenseKey),
                    'status' => 'active',
                    'expires_at' => $data['expires_at'],
                    'features' => $data['features'],
                    'activated_at' => now(),
                ]
            );
            
            return LicenseResult::success($data);
        }
        
        return LicenseResult::failed($response->json('error'));
    }
    
    public function verify(string $pluginSlug): bool
    {
        $license = PluginLicense::where('plugin_slug', $pluginSlug)->first();
        
        if (!$license || $license->isExpired()) {
            return false;
        }
        
        // Periodic remote verification (cached)
        return Cache::remember(
            "license.{$pluginSlug}.valid",
            now()->addHours(24),
            fn() => $this->remoteVerify($license)
        );
    }
}
```

---

## Common UI Components

### Plugin Card Component
```blade
{{-- resources/views/components/plugin-card.blade.php --}}
@props(['plugin', 'installed' => false])

<div class="plugin-card" data-slug="{{ $plugin['slug'] }}">
    <div class="plugin-icon">
        <img src="{{ $plugin['icon'] }}" alt="{{ $plugin['name'] }}">
    </div>
    
    <div class="plugin-info">
        <h3>{{ $plugin['name'] }}</h3>
        <div class="plugin-meta">
            <x-rating :value="$plugin['rating']" :count="$plugin['reviews_count']" />
            <span class="plugin-author">by {{ $plugin['author']['name'] }}</span>
        </div>
        <p class="plugin-description">{{ $plugin['short_description'] }}</p>
        <div class="plugin-footer">
            <span class="version">v{{ $plugin['version'] }}</span>
            <span class="downloads">{{ number_format($plugin['downloads']) }} installs</span>
            <x-compatibility-badge :status="$plugin['compatibility']" />
        </div>
    </div>
    
    <div class="plugin-actions">
        <a href="{{ route('admin.plugins.show', $plugin['slug']) }}" class="btn-secondary">View</a>
        @if($installed)
            <span class="installed-badge">Installed</span>
        @else
            <button onclick="installPlugin('{{ $plugin['slug'] }}')" class="btn-primary">Install</button>
        @endif
    </div>
</div>
```

### Status Badge Component
```blade
{{-- resources/views/components/plugin-status-badge.blade.php --}}
@props(['status'])

@php
$styles = [
    'active' => 'bg-green-100 text-green-800',
    'inactive' => 'bg-gray-100 text-gray-800',
    'error' => 'bg-red-100 text-red-800',
    'updating' => 'bg-yellow-100 text-yellow-800',
];
$labels = [
    'active' => 'Active',
    'inactive' => 'Inactive',
    'error' => 'Error',
    'updating' => 'Updating...',
];
@endphp

<span class="status-badge {{ $styles[$status] ?? $styles['inactive'] }}">
    <span class="status-dot"></span>
    {{ $labels[$status] ?? ucfirst($status) }}
</span>
```

### Settings Field Component
```blade
{{-- resources/views/components/settings-field.blade.php --}}
@props(['field', 'value', 'errors'])

<div class="settings-field" 
     x-data="{ show: true }"
     @if(isset($field['condition']))
     x-show="$store.settings['{{ $field['condition']['field'] }}'] === {{ json_encode($field['condition']['value']) }}"
     @endif
>
    <label for="{{ $field['key'] }}">{{ $field['label'] }}</label>
    
    @switch($field['type'])
        @case('text')
            <input type="text" 
                   id="{{ $field['key'] }}" 
                   name="{{ $field['key'] }}"
                   value="{{ old($field['key'], $value) }}"
                   placeholder="{{ $field['placeholder'] ?? '' }}"
                   class="@error($field['key']) is-invalid @enderror">
            @break
            
        @case('select')
            <select id="{{ $field['key'] }}" name="{{ $field['key'] }}">
                @foreach($field['options'] as $optionValue => $optionLabel)
                    <option value="{{ $optionValue }}" @selected($value == $optionValue)>
                        {{ $optionLabel }}
                    </option>
                @endforeach
            </select>
            @break
            
        @case('textarea')
            <textarea id="{{ $field['key'] }}" 
                      name="{{ $field['key'] }}"
                      rows="{{ $field['rows'] ?? 5 }}">{{ old($field['key'], $value) }}</textarea>
            @break
            
        @case('checkbox')
            <label class="checkbox-label">
                <input type="checkbox" 
                       id="{{ $field['key'] }}" 
                       name="{{ $field['key'] }}"
                       value="1"
                       @checked($value)>
                {{ $field['checkbox_label'] ?? '' }}
            </label>
            @break
            
        @case('radio')
            <div class="radio-group">
                @foreach($field['options'] as $optionValue => $optionLabel)
                    <label class="radio-label">
                        <input type="radio" 
                               name="{{ $field['key'] }}"
                               value="{{ $optionValue }}"
                               @checked($value == $optionValue)>
                        {{ $optionLabel }}
                    </label>
                @endforeach
            </div>
            @break
            
        @case('group')
            <div class="field-group">
                @foreach($field['fields'] as $subfield)
                    <x-settings-field 
                        :field="$subfield" 
                        :value="$value[$subfield['key']] ?? $subfield['default'] ?? null"
                        :errors="$errors" 
                    />
                @endforeach
            </div>
            @break
    @endswitch
    
    @if(isset($field['hint']))
        <p class="field-hint">{{ $field['hint'] }}</p>
    @endif
    
    @error($field['key'])
        <p class="field-error">{{ $message }}</p>
    @enderror
</div>
```
