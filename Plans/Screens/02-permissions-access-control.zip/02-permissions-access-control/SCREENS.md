# Permissions & Access Control - Screen Specifications

## Screen 1: Roles List

### Purpose
Display all system roles with their permission counts, user counts, and quick actions.

### URL
`/admin/roles`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Roles & Permissions                                         [+ Create Role] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [Roles] [Permission Matrix] [Access Rules] [Audit Log]                      │
│ ════════════════════════════════════════════════════════════════════════════│
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ 🔍 Search roles...                              [Status ▼] [Plugin ▼]  │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌──────────────────────────────────────────────────────────────────────────┐│
│ │                                                                          ││
│ │  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐ ││
│ │  │ 👑 Super Admin     │  │ 🔧 Administrator   │  │ 👔 Manager         │ ││
│ │  │ ─────────────────  │  │ ─────────────────  │  │ ─────────────────  │ ││
│ │  │ System role        │  │ Inherits: -        │  │ Inherits: User     │ ││
│ │  │                    │  │                    │  │                    │ ││
│ │  │ 📋 All permissions │  │ 📋 145 permissions │  │ 📋 87 permissions  │ ││
│ │  │ 👥 2 users         │  │ 👥 5 users         │  │ 👥 12 users        │ ││
│ │  │                    │  │                    │  │                    │ ││
│ │  │ 🔒 System role     │  │ [Edit] [Users]     │  │ [Edit] [Users]     │ ││
│ │  └────────────────────┘  └────────────────────┘  └────────────────────┘ ││
│ │                                                                          ││
│ │  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐ ││
│ │  │ 👤 User            │  │ 📊 Accountant      │  │ 👁 Viewer          │ ││
│ │  │ ─────────────────  │  │ ─────────────────  │  │ ─────────────────  │ ││
│ │  │ Default role       │  │ Inherits: User     │  │ Inherits: -        │ ││
│ │  │                    │  │ Plugin: accounting │  │                    │ ││
│ │  │ 📋 32 permissions  │  │ 📋 45 permissions  │  │ 📋 15 permissions  │ ││
│ │  │ 👥 150 users       │  │ 👥 8 users         │  │ 👥 25 users        │ ││
│ │  │                    │  │                    │  │                    │ ││
│ │  │ [Edit] [Users]     │  │ [Edit] [Users]     │  │ [Edit] [Users]     │ ││
│ │  └────────────────────┘  └────────────────────┘  └────────────────────┘ ││
│ │                                                                          ││
│ └──────────────────────────────────────────────────────────────────────────┘│
│                                                                             │
│ Showing 6 of 12 roles                                    [1] [2] [Next →]   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Requirements

```php
$data = [
    'roles' => Role::withCount(['permissions', 'users'])
        ->with('parent')
        ->when($request->search, fn($q, $s) => $q->search($s))
        ->when($request->plugin, fn($q, $p) => $q->fromPlugin($p))
        ->orderBy('position')
        ->paginate(12),
    'plugins' => Plugin::active()->pluck('name', 'slug'),
];
```

---

## Screen 2: Role Editor

### Purpose
Create or edit a role with permission assignment organized by groups.

### URL
`/admin/roles/{role}/edit` or `/admin/roles/create`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Back to Roles                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│ Edit Role: Manager                                           [Save Changes] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Role Details                                                            │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Role Name *                         Role Slug                           │ │
│ │ ┌───────────────────────────┐      ┌───────────────────────────┐       │ │
│ │ │ Manager                   │      │ manager                   │       │ │
│ │ └───────────────────────────┘      └───────────────────────────┘       │ │
│ │                                                                         │ │
│ │ Description                                                             │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Department managers with elevated access to reports and team mgmt   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Inherits From                        Color                              │ │
│ │ ┌───────────────────────────┐      ┌──────┐ ┌────────────────────┐     │ │
│ │ │ User                    ▼ │      │ 🟢  │ │ Green              │     │ │
│ │ └───────────────────────────┘      └──────┘ └────────────────────┘     │ │
│ │                                                                         │ │
│ │ □ Set as default role for new users                                    │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Permissions                                                             │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 🔍 Search permissions...          [Group ▼] [Plugin ▼] [Select All] │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ 87 permissions selected (55 direct, 32 inherited from User)             │ │
│ │                                                                         │ │
│ │ ▼ 📁 Dashboard (4 permissions)                          [Select All]   │ │
│ │   ┌─────────────────────────────────────────────────────────────────┐  │ │
│ │   │ ☑ dashboard.view          View dashboard              Inherited │  │ │
│ │   │ ☑ dashboard.customize     Customize dashboard         ✓ Direct  │  │ │
│ │   │ ☐ dashboard.manage        Manage all dashboards                 │  │ │
│ │   │ ☐ dashboard.widgets       Manage widgets                        │  │ │
│ │   └─────────────────────────────────────────────────────────────────┘  │ │
│ │                                                                         │ │
│ │ ▼ 📁 Users (8 permissions)                              [Select All]   │ │
│ │   ┌─────────────────────────────────────────────────────────────────┐  │ │
│ │   │ ☑ users.view              View users                  ✓ Direct  │  │ │
│ │   │ ☑ users.create            Create users                ✓ Direct  │  │ │
│ │   │ ☑ users.edit              Edit users                  ✓ Direct  │  │ │
│ │   │ ☐ users.delete            Delete users                          │  │ │
│ │   │ ☐ users.impersonate       Impersonate users                     │  │ │
│ │   │ ☑ users.export            Export user data            ✓ Direct  │  │ │
│ │   │ ☐ users.roles             Manage user roles                     │  │ │
│ │   │ ☐ users.permissions       Override user permissions             │  │ │
│ │   └─────────────────────────────────────────────────────────────────┘  │ │
│ │                                                                         │ │
│ │ ▶ 📁 Invoices (12 permissions) - invoice-manager        [Select All]   │ │
│ │ ▶ 📁 Reports (6 permissions)                            [Select All]   │ │
│ │ ▶ 📁 Settings (4 permissions)                           [Select All]   │ │
│ │ ▶ 📁 Plugins (8 permissions)                            [Select All]   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                       [Cancel] [Delete Role] [Save Changes] │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Permission Tree Data Structure

```php
[
    'groups' => [
        [
            'key' => 'dashboard',
            'label' => 'Dashboard',
            'icon' => 'layout-dashboard',
            'plugin' => null,
            'permissions' => [
                [
                    'id' => 1,
                    'name' => 'dashboard.view',
                    'label' => 'View dashboard',
                    'description' => 'Access the main dashboard',
                    'assigned' => true,
                    'inherited' => true,
                    'inherited_from' => 'User',
                ],
                [
                    'id' => 2,
                    'name' => 'dashboard.customize',
                    'label' => 'Customize dashboard',
                    'assigned' => true,
                    'inherited' => false,
                ],
            ],
        ],
    ],
    'stats' => [
        'total' => 145,
        'assigned' => 87,
        'direct' => 55,
        'inherited' => 32,
    ],
];
```

---

## Screen 3: Permission Matrix

### Purpose
Visual grid showing all roles vs all permissions for quick bulk assignment.

### URL
`/admin/permissions/matrix`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Permission Matrix                                           [Save Changes]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Filter: [Group ▼] [Plugin ▼]    🔍 Search...         [Collapse All]    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌───────────────────────────────────────────────────────────────────────────┐
│ │                    │ Super │ Admin │ Manager │ User │ Viewer │ Account │ │
│ │ Permission         │ Admin │       │         │      │        │         │ │
│ ├────────────────────┼───────┼───────┼─────────┼──────┼────────┼─────────┤ │
│ │ 📁 Dashboard       │       │       │         │      │        │         │ │
│ │ ├─ view            │  ✓ *  │  ☑    │   ☑     │  ☑   │   ☑    │   ☑     │ │
│ │ ├─ customize       │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☐     │ │
│ │ ├─ manage          │  ✓ *  │  ☑    │   ☐     │  ☐   │   ☐    │   ☐     │ │
│ │ └─ widgets         │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☐     │ │
│ ├────────────────────┼───────┼───────┼─────────┼──────┼────────┼─────────┤ │
│ │ 📁 Users           │       │       │         │      │        │         │ │
│ │ ├─ view            │  ✓ *  │  ☑    │   ☑     │  ⊙   │   ☐    │   ☐     │ │
│ │ ├─ create          │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☐     │ │
│ │ ├─ edit            │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☐     │ │
│ │ ├─ delete          │  ✓ *  │  ☑    │   ☐     │  ☐   │   ☐    │   ☐     │ │
│ │ └─ impersonate     │  ✓ *  │  ☐    │   ☐     │  ☐   │   ☐    │   ☐     │ │
│ ├────────────────────┼───────┼───────┼─────────┼──────┼────────┼─────────┤ │
│ │ 📁 Invoices        │       │       │         │      │        │         │ │
│ │ │ invoice-manager  │       │       │         │      │        │         │ │
│ │ ├─ view            │  ✓ *  │  ☑    │   ☑     │  ☑   │   ☑    │   ☑     │ │
│ │ ├─ create          │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☑     │ │
│ │ ├─ edit            │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☑     │ │
│ │ ├─ delete          │  ✓ *  │  ☑    │   ☐     │  ☐   │   ☐    │   ☐     │ │
│ │ ├─ send            │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☑     │ │
│ │ └─ reports         │  ✓ *  │  ☑    │   ☑     │  ☐   │   ☐    │   ☑     │ │
│ └───────────────────────────────────────────────────────────────────────────┘
│                                                                             │
│ Legend: ✓* = All (Super Admin)  ☑ = Granted  ⊙ = Inherited  ☐ = Denied     │
│                                                                             │
│                                              [Reset Changes] [Save Changes] │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Matrix Interaction Logic

```javascript
// Alpine.js component for matrix
function permissionMatrix() {
    return {
        permissions: {},
        changes: {},
        
        toggle(roleId, permissionId) {
            const key = `${roleId}-${permissionId}`;
            const current = this.permissions[key];
            
            if (current === 'inherited') {
                // Can't change inherited permissions
                return;
            }
            
            this.permissions[key] = !current;
            this.changes[key] = !current;
        },
        
        toggleColumn(roleId) {
            // Toggle all permissions for a role
            const rolePerms = Object.keys(this.permissions)
                .filter(k => k.startsWith(`${roleId}-`));
            
            const allChecked = rolePerms.every(k => this.permissions[k]);
            
            rolePerms.forEach(k => {
                if (this.permissions[k] !== 'inherited') {
                    this.permissions[k] = !allChecked;
                    this.changes[k] = !allChecked;
                }
            });
        },
        
        toggleRow(permissionId) {
            // Toggle permission across all roles
            const permRoles = Object.keys(this.permissions)
                .filter(k => k.endsWith(`-${permissionId}`));
            
            const allChecked = permRoles.every(k => this.permissions[k]);
            
            permRoles.forEach(k => {
                if (this.permissions[k] !== 'inherited') {
                    this.permissions[k] = !allChecked;
                    this.changes[k] = !allChecked;
                }
            });
        },
        
        async save() {
            await fetch('/api/v1/admin/permissions/matrix', {
                method: 'POST',
                body: JSON.stringify({ changes: this.changes }),
            });
            this.changes = {};
        },
    };
}
```

---

## Screen 4: User Permissions

### Purpose
View and manage permissions for a specific user, including role assignments and individual overrides.

### URL
`/admin/users/{user}/permissions`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Back to User: John Smith                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ User Permissions                                             [Save Changes] │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ User: John Smith (john@example.com)                                     │ │
│ │ Status: Active | Last Login: 2 hours ago                                │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Assigned Roles                                                          │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐                    │ │
│ │  │ ✓ Manager    │ │ ✓ Accountant │ │ ☐ Admin      │ [+ Add Role]       │ │
│ │  │   87 perms   │ │   45 perms   │ │              │                    │ │
│ │  │   [Remove]   │ │   [Remove]   │ │              │                    │ │
│ │  └──────────────┘ └──────────────┘ └──────────────┘                    │ │
│ │                                                                         │ │
│ │  Effective permissions from roles: 102 (after merging)                 │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Permission Overrides                                      [Clear All]   │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ ⚠ 3 individual permission overrides are set for this user              │ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Permission              │ From Roles │ Override │ Effective │ Action│ │ │
│ │ ├─────────────────────────┼────────────┼──────────┼───────────┼───────┤ │ │
│ │ │ users.delete            │ ☐ Denied   │ ☑ Grant  │ ✓ Allowed │ [×]   │ │ │
│ │ │ invoices.void           │ ☑ Allowed  │ ☐ Deny   │ ✗ Denied  │ [×]   │ │ │
│ │ │ reports.financial       │ ☐ Denied   │ ☑ Grant  │ ✓ Allowed │ [×]   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ [+ Add Override]                                                        │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Effective Permissions                              [Expand All Groups]  │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Total: 105 permissions (102 from roles + 2 granted - 1 denied)         │ │
│ │                                                                         │ │
│ │ 🔍 Search permissions...                                                │ │
│ │                                                                         │ │
│ │ ▼ Dashboard (4/4 allowed)                                              │ │
│ │   ✓ dashboard.view         │ From: Manager                              │ │
│ │   ✓ dashboard.customize    │ From: Manager                              │ │
│ │   ✗ dashboard.manage       │ Not assigned                               │ │
│ │   ✓ dashboard.widgets      │ From: Manager                              │ │
│ │                                                                         │ │
│ │ ▼ Users (5/8 allowed)                                                  │ │
│ │   ✓ users.view             │ From: Manager                              │ │
│ │   ✓ users.create           │ From: Manager                              │ │
│ │   ✓ users.edit             │ From: Manager                              │ │
│ │   ✓ users.delete           │ Override: Granted ⚡                       │ │
│ │   ✗ users.impersonate      │ Not assigned                               │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                              [Cancel] [Save Changes]        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 5: Access Rules

### Purpose
Define conditional access rules that apply additional restrictions based on context (time, IP, team, etc.).

### URL
`/admin/access-rules`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Access Rules                                              [+ Create Rule]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ Access rules add conditional restrictions to permissions. Rules are         │
│ evaluated in priority order; first matching rule wins.                      │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ # │ Name                  │ Target        │ Conditions    │ Status │ ⋮  │ │
│ ├───┼───────────────────────┼───────────────┼───────────────┼────────┼────┤ │
│ │ 1 │ Business Hours Only   │ invoices.*    │ Time: 9-17    │ Active │ ⋮  │ │
│ │   │ Restrict invoice ops  │ delete        │ Days: Mon-Fri │        │    │ │
│ ├───┼───────────────────────┼───────────────┼───────────────┼────────┼────┤ │
│ │ 2 │ Office Network        │ users.delete  │ IP: 10.0.0.*  │ Active │ ⋮  │ │
│ │   │ User deletion from    │               │               │        │    │ │
│ │   │ office IPs only       │               │               │        │    │ │
│ ├───┼───────────────────────┼───────────────┼───────────────┼────────┼────┤ │
│ │ 3 │ Finance Team Invoices │ invoices.void │ Team: Finance │ Active │ ⋮  │ │
│ │   │ Only finance can void │               │ Role: Manager │        │    │ │
│ ├───┼───────────────────────┼───────────────┼───────────────┼────────┼────┤ │
│ │ 4 │ Read-Only Mode        │ *.create      │ Custom:       │ Pause  │ ⋮  │ │
│ │   │ Maintenance window    │ *.edit        │ maintenance   │        │    │ │
│ │   │                       │ *.delete      │ =true         │        │    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ⚠ Note: Access rules can only restrict, not grant, permissions.            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

## Create/Edit Access Rule Modal
┌─────────────────────────────────────────────────────────────────────────────┐
│ Create Access Rule                                                  [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ Rule Name *                                                                 │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Business Hours Only                                                     │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Description                                                                 │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Restrict sensitive operations to business hours                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Target Permissions                                                          │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ ☑ invoices.delete                                                       │ │
│ │ ☑ invoices.void                                                         │ │
│ │ ☐ invoices.create                                                       │ │
│ │ ... [Show all]                                                          │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Conditions (all must match)                              [+ Add Condition] │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ ┌──────────┐ ┌──────────┐ ┌──────────────────────────────┐ ┌───┐       │ │
│ │ │ Time   ▼ │ │ between▼ │ │ 09:00          and    17:00 │ │ × │       │ │
│ │ └──────────┘ └──────────┘ └──────────────────────────────┘ └───┘       │ │
│ │                                                                         │ │
│ │ ┌──────────┐ ┌──────────┐ ┌──────────────────────────────┐ ┌───┐       │ │
│ │ │ Day    ▼ │ │ is one of│ │ Mon, Tue, Wed, Thu, Fri     │ │ × │       │ │
│ │ └──────────┘ └──────────┘ └──────────────────────────────┘ └───┘       │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Action when conditions DO NOT match:  ● Deny Access  ○ Allow (Log Only)    │
│                                                                             │
│ Priority: [1] (lower = evaluated first)                                     │
│                                                                             │
│ □ Enabled                                                                   │
│                                                                             │
│                                              [Cancel] [Save Rule]           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Condition Types

```php
[
    'time' => [
        'label' => 'Time of Day',
        'operators' => ['between', 'not_between', 'before', 'after'],
        'value_type' => 'time_range',
    ],
    'day' => [
        'label' => 'Day of Week',
        'operators' => ['is', 'is_not', 'is_one_of'],
        'value_type' => 'day_select',
    ],
    'date' => [
        'label' => 'Date',
        'operators' => ['between', 'before', 'after', 'is'],
        'value_type' => 'date_range',
    ],
    'ip' => [
        'label' => 'IP Address',
        'operators' => ['is', 'is_not', 'starts_with', 'in_range'],
        'value_type' => 'ip_input',
    ],
    'role' => [
        'label' => 'User Role',
        'operators' => ['is', 'is_not', 'is_one_of'],
        'value_type' => 'role_select',
    ],
    'team' => [
        'label' => 'Team/Department',
        'operators' => ['is', 'is_not', 'is_one_of'],
        'value_type' => 'team_select',
    ],
    'custom' => [
        'label' => 'Custom Field',
        'operators' => ['equals', 'not_equals', 'contains', 'greater_than'],
        'value_type' => 'custom_input',
    ],
];
```

---

## Screen 6: Permission Audit Log

### Purpose
Track all changes to permissions, roles, and access rules for compliance and troubleshooting.

### URL
`/admin/permissions/audit`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Permission Audit Log                                        [Export CSV]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Filters:                                                                │ │
│ │ [Date Range ▼]  [Action ▼]  [User ▼]  [Target Type ▼]  🔍 Search...   │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Time                │ User        │ Action            │ Details         │ │
│ ├─────────────────────┼─────────────┼───────────────────┼─────────────────┤ │
│ │ Today, 14:32        │ Admin       │ Role Updated      │ Manager: +3     │ │
│ │                     │             │                   │ permissions     │ │
│ │                     │             │                   │ [View Details]  │ │
│ ├─────────────────────┼─────────────┼───────────────────┼─────────────────┤ │
│ │ Today, 14:30        │ Admin       │ User Role Changed │ john@ex.com     │ │
│ │                     │             │                   │ +Manager role   │ │
│ │                     │             │                   │ [View Details]  │ │
│ ├─────────────────────┼─────────────┼───────────────────┼─────────────────┤ │
│ │ Today, 11:15        │ Admin       │ Permission        │ users.delete    │ │
│ │                     │             │ Override Added    │ granted to      │ │
│ │                     │             │                   │ john@ex.com     │ │
│ ├─────────────────────┼─────────────┼───────────────────┼─────────────────┤ │
│ │ Yesterday, 16:45    │ System      │ Access Rule       │ "Business Hrs"  │ │
│ │                     │             │ Triggered         │ Denied access   │ │
│ │                     │             │                   │ for jane@ex     │ │
│ ├─────────────────────┼─────────────┼───────────────────┼─────────────────┤ │
│ │ Yesterday, 09:00    │ Admin       │ Role Created      │ "Accountant"    │ │
│ │                     │             │                   │ 45 permissions  │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                               Showing 1-20 of 1,234 entries │
│                                                      [1] [2] [3] ... [62]   │
└─────────────────────────────────────────────────────────────────────────────┘

## Audit Detail Modal
┌─────────────────────────────────────────────────────────────────────────────┐
│ Audit Entry Details                                                 [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ Action: Role Updated                                                        │
│ Time: December 15, 2024 at 14:32:15 UTC                                    │
│ User: Admin (admin@example.com)                                            │
│ IP Address: 10.0.0.50                                                      │
│                                                                             │
│ Target: Role "Manager"                                                      │
│                                                                             │
│ Changes:                                                                    │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Permissions Added (+3):                                                 │ │
│ │   • reports.financial - View financial reports                          │ │
│ │   • reports.export - Export report data                                 │ │
│ │   • analytics.view - View analytics dashboard                           │ │
│ │                                                                         │ │
│ │ Permissions Removed (-1):                                               │ │
│ │   • users.impersonate - Impersonate other users                        │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Affected Users: 12 users with this role                                     │
│                                                                             │
│                                                              [Close]        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Common Components

### Permission Checkbox

```blade
{{-- resources/views/components/permissions/checkbox.blade.php --}}
@props([
    'permission',
    'checked' => false,
    'inherited' => false,
    'disabled' => false,
])

<label class="permission-checkbox {{ $inherited ? 'inherited' : '' }} {{ $disabled ? 'disabled' : '' }}">
    <input type="checkbox"
           name="permissions[]"
           value="{{ $permission['id'] }}"
           @checked($checked || $inherited)
           @disabled($disabled || $inherited)
           class="permission-input">
    
    <span class="permission-info">
        <span class="permission-name">{{ $permission['label'] }}</span>
        @if($inherited)
            <span class="permission-inherited">Inherited from {{ $permission['inherited_from'] }}</span>
        @endif
    </span>
    
    @if($permission['description'])
        <span class="permission-description" title="{{ $permission['description'] }}">
            <x-icon name="info" class="w-4 h-4" />
        </span>
    @endif
</label>
```

### Role Card

```blade
{{-- resources/views/components/permissions/role-card.blade.php --}}
@props(['role'])

<div class="role-card {{ $role->is_system ? 'role-card--system' : '' }}">
    <div class="role-card__icon" style="background-color: {{ $role->color }}">
        <x-icon :name="$role->icon ?? 'shield'" class="w-6 h-6 text-white" />
    </div>
    
    <div class="role-card__content">
        <h3 class="role-card__title">{{ $role->name }}</h3>
        
        @if($role->parent)
            <p class="role-card__inherit">Inherits: {{ $role->parent->name }}</p>
        @endif
        
        @if($role->plugin)
            <span class="role-card__plugin">Plugin: {{ $role->plugin }}</span>
        @endif
        
        <div class="role-card__stats">
            <span><x-icon name="key" class="w-4 h-4" /> {{ $role->permissions_count }} permissions</span>
            <span><x-icon name="users" class="w-4 h-4" /> {{ $role->users_count }} users</span>
        </div>
    </div>
    
    <div class="role-card__actions">
        @if($role->is_system)
            <span class="badge badge-gray">System Role</span>
        @else
            <a href="{{ route('admin.roles.edit', $role) }}" class="btn btn-sm btn-secondary">Edit</a>
            <a href="{{ route('admin.roles.users', $role) }}" class="btn btn-sm btn-secondary">Users</a>
        @endif
    </div>
</div>
```

### Permission Group Accordion

```blade
{{-- resources/views/components/permissions/group-accordion.blade.php --}}
@props(['group', 'roleId' => null, 'selectedPermissions' => []])

<div x-data="{ open: false }" class="permission-group">
    <button @click="open = !open" class="permission-group__header">
        <x-icon :name="$group['icon'] ?? 'folder'" class="w-5 h-5" />
        <span class="permission-group__name">{{ $group['label'] }}</span>
        <span class="permission-group__count">
            {{ count(array_filter($group['permissions'], fn($p) => in_array($p['id'], $selectedPermissions))) }}
            / {{ count($group['permissions']) }}
        </span>
        
        @if($group['plugin'])
            <span class="permission-group__plugin">{{ $group['plugin'] }}</span>
        @endif
        
        <button type="button" @click.stop="selectAll('{{ $group['key'] }}')" class="permission-group__select-all">
            Select All
        </button>
        
        <x-icon name="chevron-down" class="w-5 h-5 transition-transform" :class="{ 'rotate-180': open }" />
    </button>
    
    <div x-show="open" x-collapse class="permission-group__content">
        @foreach($group['permissions'] as $permission)
            <x-permissions.checkbox 
                :permission="$permission"
                :checked="in_array($permission['id'], $selectedPermissions)"
                :inherited="$permission['inherited'] ?? false"
            />
        @endforeach
    </div>
</div>
```
