# Settings & Configuration - Screen Specifications

## Screen 1: Settings Home

### Purpose
Central hub displaying all settings categories with quick access and status indicators.

### URL
`/admin/settings`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Settings                                                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ 🔍 Search settings...                                                       │
│                                                                             │
│ ┌───────────────────────┐ ┌───────────────────────┐ ┌───────────────────────┐
│ │ ⚙️ General            │ │ 🎨 Appearance         │ │ 📧 Email              │
│ │                       │ │                       │ │                       │
│ │ App name, timezone,   │ │ Theme, colors, logo,  │ │ SMTP settings, email  │
│ │ locale, currency      │ │ branding options      │ │ templates, sender     │
│ │                       │ │                       │ │                       │
│ │ [Configure →]         │ │ [Configure →]         │ │ [Configure →]         │
│ └───────────────────────┘ └───────────────────────┘ └───────────────────────┘
│                                                                             │
│ ┌───────────────────────┐ ┌───────────────────────┐ ┌───────────────────────┐
│ │ 🔐 Security           │ │ 🗄️ Storage            │ │ 🔔 Notifications      │
│ │                       │ │                       │ │                       │
│ │ Authentication, 2FA,  │ │ File storage, S3,     │ │ Push notifications,   │
│ │ password policies     │ │ upload limits         │ │ channels, preferences │
│ │                       │ │                       │ │                       │
│ │ [Configure →]         │ │ [Configure →]         │ │ [Configure →]         │
│ └───────────────────────┘ └───────────────────────┘ └───────────────────────┘
│                                                                             │
│ Plugin Settings                                                             │
│ ─────────────────────────────────────────────────────────────────────────── │
│                                                                             │
│ ┌───────────────────────┐ ┌───────────────────────┐ ┌───────────────────────┐
│ │ 📄 Invoice Manager    │ │ 📦 Inventory          │ │ 💳 Payment Gateway    │
│ │                       │ │                       │ │                       │
│ │ Invoice numbering,    │ │ Stock alerts, units,  │ │ API keys, sandbox     │
│ │ templates, defaults   │ │ warehouse settings    │ │ mode, webhooks        │
│ │                       │ │                       │ │                       │
│ │ [Configure →]         │ │ [Configure →]         │ │ [Configure →]         │
│ └───────────────────────┘ └───────────────────────┘ └───────────────────────┘
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Quick Actions                                                           │ │
│ │ [Export Settings] [Import Settings] [View History] [Clear Cache]        │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 2: General Settings

### Purpose
Configure core application settings like name, timezone, locale, and basic preferences.

### URL
`/admin/settings/general`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ General Settings                                           [Save Changes]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [Application] [Regional] [Display] [Maintenance]                            │
│ ═══════════════════════════════════════════════════════════════════════════ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Application                                                             │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Application Name *                                                      │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ My Application                                                      │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │ Displayed in the browser title and throughout the application          │ │
│ │                                                                         │ │
│ │ Application URL *                                                       │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ https://myapp.example.com                                           │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │ Used for generating links in emails and notifications                  │ │
│ │                                                                         │ │
│ │ Admin Email                                                             │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ admin@example.com                                                   │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │ System notifications will be sent to this address                      │ │
│ │                                                                         │ │
│ │ Logo                                                                    │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ [Current Logo Preview]              [Upload New] [Remove]           │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Favicon                                                                 │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ [Current Favicon]                   [Upload New] [Remove]           │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Regional                                                                │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Timezone                              Default Language                  │ │
│ │ ┌───────────────────────────┐        ┌───────────────────────────┐     │ │
│ │ │ America/New_York       ▼  │        │ English (US)            ▼ │     │ │
│ │ └───────────────────────────┘        └───────────────────────────┘     │ │
│ │                                                                         │ │
│ │ Date Format                           Time Format                       │ │
│ │ ┌───────────────────────────┐        ┌───────────────────────────┐     │ │
│ │ │ MM/DD/YYYY             ▼  │        │ 12-hour (AM/PM)         ▼ │     │ │
│ │ └───────────────────────────┘        └───────────────────────────┘     │ │
│ │ Preview: 12/15/2024                  Preview: 2:30 PM                  │ │
│ │                                                                         │ │
│ │ Default Currency                      Number Format                     │ │
│ │ ┌───────────────────────────┐        ┌───────────────────────────┐     │ │
│ │ │ USD - US Dollar        ▼  │        │ 1,234.56               ▼  │     │ │
│ │ └───────────────────────────┘        └───────────────────────────┘     │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                                          [Save Changes]     │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 3: Plugin Settings

### Purpose
Configure settings specific to a plugin with dynamically generated form based on plugin's setting definitions.

### URL
`/admin/plugins/{plugin}/settings`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Back to Plugins                                                           │
│                                                                             │
│ Invoice Manager Settings                                   [Save Changes]   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [General] [Numbering] [Templates] [Notifications]                           │
│ ═══════════════════════════════════════════════════════════════════════════ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Invoice Numbering                                                       │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Number Format                                                           │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ INV-{YEAR}-{NUMBER}                                                 │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │ Available variables: {YEAR}, {MONTH}, {NUMBER}, {CUSTOMER}             │ │
│ │ Preview: INV-2024-00127                                                │ │
│ │                                                                         │ │
│ │ Next Number                           Padding                           │ │
│ │ ┌───────────────────────────┐        ┌───────────────────────────┐     │ │
│ │ │ 127                       │        │ 5 digits               ▼  │     │ │
│ │ └───────────────────────────┘        └───────────────────────────┘     │ │
│ │                                                                         │ │
│ │ Reset Numbering                                                         │ │
│ │ ● Never reset                                                           │ │
│ │ ○ Reset yearly                                                          │ │
│ │ ○ Reset monthly                                                         │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Default Values                                                          │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Default Payment Terms                 Default Tax Rate                  │ │
│ │ ┌───────────────────────────┐        ┌───────────────────────────┐     │ │
│ │ │ Net 30                  ▼ │        │ 10                      % │     │ │
│ │ └───────────────────────────┘        └───────────────────────────┘     │ │
│ │                                                                         │ │
│ │ Default Currency                      Auto-calculate Due Date           │ │
│ │ ┌───────────────────────────┐        ┌───────────────────────────┐     │ │
│ │ │ USD - US Dollar        ▼  │        │ ☑ Yes                     │     │ │
│ │ └───────────────────────────┘        └───────────────────────────┘     │ │
│ │                                                                         │ │
│ │ Default Notes                                                           │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Thank you for your business!                                        │ │ │
│ │ │                                                                     │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                  [Reset to Defaults] [Save Changes]         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 4: Settings History

### Purpose
View audit log of all settings changes with ability to restore previous values.

### URL
`/admin/settings/history`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Settings History                                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Filter: [All Groups ▼] [All Users ▼] [Date Range: Last 30 days ▼]      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Today                                                                   │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ ┌───────────────────────────────────────────────────────────────────┐   │ │
│ │ │ 🔧 app.timezone                                        2:45 PM    │   │ │
│ │ │ Changed by Admin                                                  │   │ │
│ │ │                                                                   │   │ │
│ │ │ America/Los_Angeles → America/New_York                           │   │ │
│ │ │                                                                   │   │ │
│ │ │                                               [Restore Previous]  │   │ │
│ │ └───────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ │ ┌───────────────────────────────────────────────────────────────────┐   │ │
│ │ │ 📧 mail.from_address                                  10:30 AM    │   │ │
│ │ │ Changed by Admin                                                  │   │ │
│ │ │                                                                   │   │ │
│ │ │ no-reply@old.com → no-reply@newdomain.com                        │   │ │
│ │ │                                                                   │   │ │
│ │ │                                               [Restore Previous]  │   │ │
│ │ └───────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │ Yesterday                                                               │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ ┌───────────────────────────────────────────────────────────────────┐   │ │
│ │ │ 📄 invoice-manager.next_number                        4:15 PM     │   │ │
│ │ │ Changed by Manager                                                │   │ │
│ │ │                                                                   │   │ │
│ │ │ 100 → 127                                                         │   │ │
│ │ │                                                                   │   │ │
│ │ │                                               [Restore Previous]  │   │ │
│ │ └───────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                               Showing 1-20 of 156 changes   │
│                                                           [Load More]       │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 5: Import/Export Settings

### Purpose
Backup settings to file or restore settings from a previous backup.

### URL
`/admin/settings/transfer`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Import / Export Settings                                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────┐ ┌─────────────────────────────────┐ │
│ │ Export Settings                     │ │ Import Settings                 │ │
│ ├─────────────────────────────────────┤ ├─────────────────────────────────┤ │
│ │                                     │ │                                 │ │
│ │ Export current settings to a JSON   │ │ Restore settings from a         │ │
│ │ file for backup or migration.       │ │ previously exported file.       │ │
│ │                                     │ │                                 │ │
│ │ Include:                            │ │ ┌─────────────────────────────┐ │ │
│ │ ☑ General Settings                  │ │ │                             │ │ │
│ │ ☑ Plugin Settings                   │ │ │   Drop file here or click   │ │ │
│ │ ☐ Sensitive Data (encrypted)        │ │ │        to browse            │ │ │
│ │ ☐ Environment-specific              │ │ │                             │ │ │
│ │                                     │ │ │     📁 .json files only     │ │ │
│ │ Format:                             │ │ │                             │ │ │
│ │ ● JSON (recommended)                │ │ └─────────────────────────────┘ │ │
│ │ ○ YAML                              │ │                                 │ │
│ │                                     │ │ Import Mode:                    │ │
│ │                                     │ │ ● Merge (keep existing)         │ │
│ │ [Download Export]                   │ │ ○ Replace (overwrite all)       │ │
│ │                                     │ │                                 │ │
│ │                                     │ │ [Import Settings]               │ │
│ │                                     │ │                                 │ │
│ └─────────────────────────────────────┘ └─────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Recent Exports                                                          │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │ settings-backup-2024-12-15.json          Dec 15, 2024    [Download]    │ │
│ │ settings-backup-2024-12-01.json          Dec 1, 2024     [Download]    │ │
│ │ settings-backup-2024-11-15.json          Nov 15, 2024    [Download]    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Common Components

### Setting Field Component

```blade
{{-- resources/views/components/settings/setting-field.blade.php --}}
@props(['setting'])

<div class="setting-field" x-data="{ value: @js($setting['value']) }">
    <label class="setting-field__label">
        {{ $setting['label'] }}
        @if($setting['required'] ?? false)
            <span class="text-red-500">*</span>
        @endif
    </label>
    
    @switch($setting['type'])
        @case('text')
        @case('string')
            <input type="text" 
                   name="{{ $setting['key'] }}"
                   x-model="value"
                   placeholder="{{ $setting['placeholder'] ?? '' }}"
                   class="setting-field__input"
                   @if($setting['required'] ?? false) required @endif>
            @break
            
        @case('textarea')
            <textarea name="{{ $setting['key'] }}"
                      x-model="value"
                      rows="{{ $setting['rows'] ?? 3 }}"
                      class="setting-field__textarea"></textarea>
            @break
            
        @case('number')
        @case('integer')
            <input type="number" 
                   name="{{ $setting['key'] }}"
                   x-model="value"
                   min="{{ $setting['min'] ?? '' }}"
                   max="{{ $setting['max'] ?? '' }}"
                   step="{{ $setting['step'] ?? 1 }}"
                   class="setting-field__input">
            @break
            
        @case('boolean')
        @case('toggle')
            <label class="setting-field__toggle">
                <input type="checkbox" 
                       name="{{ $setting['key'] }}"
                       x-model="value"
                       class="sr-only">
                <span class="toggle-track"></span>
            </label>
            @break
            
        @case('select')
            <select name="{{ $setting['key'] }}" x-model="value" class="setting-field__select">
                @foreach($setting['options'] as $optValue => $optLabel)
                    <option value="{{ $optValue }}">{{ $optLabel }}</option>
                @endforeach
            </select>
            @break
            
        @case('color')
            <input type="color" 
                   name="{{ $setting['key'] }}"
                   x-model="value"
                   class="setting-field__color">
            @break
            
        @case('file')
        @case('image')
            <x-file-upload 
                name="{{ $setting['key'] }}"
                :accept="$setting['accept'] ?? '*'"
                :current="$setting['value']" />
            @break
            
        @case('encrypted')
            <input type="password" 
                   name="{{ $setting['key'] }}"
                   placeholder="••••••••"
                   class="setting-field__input">
            <span class="text-xs text-gray-500">Leave empty to keep current value</span>
            @break
    @endswitch
    
    @if($setting['help'] ?? null)
        <p class="setting-field__help">{{ $setting['help'] }}</p>
    @endif
</div>
```

### Settings Group Component

```blade
{{-- resources/views/components/settings/settings-group.blade.php --}}
@props(['group', 'settings'])

<div class="settings-group" x-data="{ open: true }">
    <button @click="open = !open" class="settings-group__header">
        <span class="settings-group__title">
            @if($group['icon'] ?? null)
                <x-icon :name="$group['icon']" class="w-5 h-5" />
            @endif
            {{ $group['label'] }}
        </span>
        <x-icon name="chevron-down" class="w-4 h-4 transition-transform" :class="{ 'rotate-180': !open }" />
    </button>
    
    <div x-show="open" x-collapse class="settings-group__content">
        @foreach($settings as $setting)
            <x-settings.setting-field :setting="$setting" />
        @endforeach
    </div>
</div>
```
