# Entity & Data Management - Screen Specifications

## Screen 1: Entity List

### Purpose
Display records of any entity type with dynamic columns, sorting, filtering, and bulk actions.

### URL
`/admin/{entity}` (e.g., `/admin/invoices`, `/admin/products`)

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Invoices                                                     [+ New Invoice]│
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ 🔍 Search invoices...                    [Filters ▼] [Columns ▼] [⋮]   │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Active Filters: Status: Pending ×  |  Date: Last 30 days ×  [Clear All]│ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ □ │ Number ↑    │ Customer       │ Date       │ Total    │ Status │ ⋮  │ │
│ ├───┼─────────────┼────────────────┼────────────┼──────────┼────────┼────┤ │
│ │ □ │ INV-001     │ Acme Corp      │ 2024-12-10 │ $1,250   │ 🟡 Pend│ ⋮  │ │
│ │ □ │ INV-002     │ Tech Solutions │ 2024-12-09 │ $3,400   │ 🟡 Pend│ ⋮  │ │
│ │ □ │ INV-003     │ Global Inc     │ 2024-12-08 │ $890     │ 🟢 Paid│ ⋮  │ │
│ │ □ │ INV-004     │ StartupXYZ     │ 2024-12-07 │ $2,100   │ 🟡 Pend│ ⋮  │ │
│ │ □ │ INV-005     │ Enterprise Co  │ 2024-12-06 │ $5,600   │ 🔴 Over│ ⋮  │ │
│ │ □ │ INV-006     │ Local Shop     │ 2024-12-05 │ $340     │ 🟢 Paid│ ⋮  │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Selected: 0                           Showing 1-20 of 156  [◀] [1][2][3] [▶]│
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Bulk Actions: [Select action ▼] [Apply]    [Export ▼] [Import]          │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

## Filters Dropdown
┌────────────────────────────────────┐
│ Filters                            │
├────────────────────────────────────┤
│ Status                             │
│ ┌────────────────────────────────┐ │
│ │ ▼ Select status...             │ │
│ │   ☑ Pending                    │ │
│ │   ☐ Paid                       │ │
│ │   ☐ Overdue                    │ │
│ │   ☐ Cancelled                  │ │
│ └────────────────────────────────┘ │
│                                    │
│ Customer                           │
│ ┌────────────────────────────────┐ │
│ │ Search customer...             │ │
│ └────────────────────────────────┘ │
│                                    │
│ Date Range                         │
│ ┌────────────────────────────────┐ │
│ │ From: [          ] - To: [   ] │ │
│ └────────────────────────────────┘ │
│                                    │
│ Amount                             │
│ ┌────────────────────────────────┐ │
│ │ Min: [    ] - Max: [    ]      │ │
│ └────────────────────────────────┘ │
│                                    │
│ [Reset] [Apply Filters]            │
└────────────────────────────────────┘

## Columns Dropdown
┌────────────────────────────────────┐
│ Visible Columns                    │
├────────────────────────────────────┤
│ ☑ Number                           │
│ ☑ Customer                         │
│ ☑ Date                             │
│ ☑ Total                            │
│ ☑ Status                           │
│ ☐ Due Date                         │
│ ☐ Items Count                      │
│ ☐ Created By                       │
│ ☐ Notes                            │
│                                    │
│ [Reset to Default]                 │
└────────────────────────────────────┘
```

### Data Requirements

```php
$data = [
    'entity' => $entityDefinition,
    'fields' => $entityDefinition->getListFields(),
    'records' => $entityDefinition->getModel()::query()
        ->withFilters($request->filters)
        ->withSearch($request->search)
        ->orderBy($request->sort_by, $request->sort_dir)
        ->paginate($request->per_page ?? 20),
    'filters' => $entityDefinition->getFilterableFields(),
    'bulkActions' => $entityDefinition->getBulkActions(),
];
```

---

## Screen 2: Entity Detail

### Purpose
Display complete information about a single record with related data and actions.

### URL
`/admin/{entity}/{id}`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ← Back to Invoices                                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌───────────────────────────────────────────┐ ┌───────────────────────────┐ │
│ │ Invoice INV-001                           │ │ Actions                   │ │
│ │                                           │ ├───────────────────────────┤ │
│ │ Status: 🟡 Pending                        │ │ [Edit]                    │ │
│ │ Created: Dec 10, 2024 by Admin            │ │ [Send Email]              │ │
│ │ Updated: Dec 11, 2024                     │ │ [Download PDF]            │ │
│ │                                           │ │ [Duplicate]               │ │
│ └───────────────────────────────────────────┘ │ [Delete]                  │ │
│                                               └───────────────────────────┘ │
│                                                                             │
│ [Details] [Items] [Payments] [Activity] [Related]                           │
│ ═══════════════════════════════════════════════════════════════════════════ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Details                                                                 │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Invoice Number          Customer                    Issue Date          │ │
│ │ INV-001                 Acme Corp                   December 10, 2024   │ │
│ │                         123 Business St                                 │ │
│ │                         New York, NY 10001                              │ │
│ │                                                                         │ │
│ │ Due Date                Payment Terms               Currency            │ │
│ │ January 10, 2025        Net 30                      USD                 │ │
│ │                                                                         │ │
│ │ ─────────────────────────────────────────────────────────────────────── │ │
│ │                                                                         │ │
│ │ Subtotal                                                    $1,150.00   │ │
│ │ Tax (10%)                                                     $115.00   │ │
│ │ Discount                                                      -$15.00   │ │
│ │ ─────────────────────────────────────────────────────────────────────── │ │
│ │ Total                                                       $1,250.00   │ │
│ │ Amount Paid                                                    $0.00    │ │
│ │ Balance Due                                                 $1,250.00   │ │
│ │                                                                         │ │
│ │ Notes:                                                                  │ │
│ │ Payment expected by end of month. Contact billing@acme.com for queries. │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Custom Fields                                                           │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │ Project Code: PRJ-2024-001                                              │ │
│ │ Department: Engineering                                                  │ │
│ │ Approval Status: Approved by Jane Doe on Dec 9, 2024                    │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 3: Entity Create/Edit Form

### Purpose
Dynamic form for creating or editing entity records.

### URL
`/admin/{entity}/create` or `/admin/{entity}/{id}/edit`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Create Invoice                                                [Save Draft]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [Basic Info] [Line Items] [Payment] [Custom Fields]                         │
│ ═══════════════════════════════════════════════════════════════════════════ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Basic Information                                                       │ │
│ ├─────────────────────────────────────────────────────────────────────────┤ │
│ │                                                                         │ │
│ │ Invoice Number *                    Status                              │ │
│ │ ┌───────────────────────────┐      ┌───────────────────────────┐       │ │
│ │ │ INV-007 (auto-generated)  │      │ Draft                   ▼ │       │ │
│ │ └───────────────────────────┘      └───────────────────────────┘       │ │
│ │                                                                         │ │
│ │ Customer *                                                              │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ 🔍 Search customers...                                              │ │ │
│ │ │   ┌─────────────────────────────────────────────────────────────┐   │ │ │
│ │ │   │ Acme Corp - New York                                        │   │ │ │
│ │ │   │ Tech Solutions - San Francisco                              │   │ │ │
│ │ │   │ Global Inc - London                                         │   │ │ │
│ │ │   └─────────────────────────────────────────────────────────────┘   │ │ │
│ │ │ [+ Create New Customer]                                             │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Issue Date *                        Due Date *                          │ │
│ │ ┌───────────────────────────┐      ┌───────────────────────────┐       │ │
│ │ │ 📅 December 15, 2024      │      │ 📅 January 14, 2025       │       │ │
│ │ └───────────────────────────┘      └───────────────────────────┘       │ │
│ │                                                                         │ │
│ │ Payment Terms                       Currency                            │ │
│ │ ┌───────────────────────────┐      ┌───────────────────────────┐       │ │
│ │ │ Net 30                  ▼ │      │ USD - US Dollar         ▼ │       │ │
│ │ └───────────────────────────┘      └───────────────────────────┘       │ │
│ │                                                                         │ │
│ │ Notes                                                                   │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Enter any additional notes or terms...                              │ │ │
│ │ │                                                                     │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                         [Cancel] [Save Draft] [Save & Send] │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 4: Field Manager

### Purpose
Configure fields for an entity including types, validation, and display options.

### URL
`/admin/entities/{entity}/fields`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Invoice Fields                                               [+ Add Field]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Field              │ Type      │ Required │ In List │ Filterable │ ⋮    │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ number           │ Text      │ ✓        │ ✓       │ ✓          │ ⋮    │ │
│ │   Invoice Number   │ Auto-gen  │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ customer_id      │ Relation  │ ✓        │ ✓       │ ✓          │ ⋮    │ │
│ │   Customer         │ BelongsTo │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ issue_date       │ Date      │ ✓        │ ✓       │ ✓          │ ⋮    │ │
│ │   Issue Date       │           │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ due_date         │ Date      │ ✓        │ ✓       │ ✓          │ ⋮    │ │
│ │   Due Date         │           │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ total            │ Currency  │ ✓        │ ✓       │ ✓          │ ⋮    │ │
│ │   Total            │ Computed  │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ status           │ Select    │ ✓        │ ✓       │ ✓          │ ⋮    │ │
│ │   Status           │           │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ notes            │ Textarea  │          │         │            │ ⋮    │ │
│ │   Notes            │           │          │         │            │      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Custom Fields                                                [+ Add Field]  │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ ≡ project_code     │ Text      │          │         │            │ ⋮    │ │
│ │   Project Code     │           │          │         │            │      │ │
│ ├────────────────────┼───────────┼──────────┼─────────┼────────────┼──────┤ │
│ │ ≡ department       │ Select    │          │         │ ✓          │ ⋮    │ │
│ │   Department       │           │          │         │            │      │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

## Field Editor Modal
┌─────────────────────────────────────────────────────────────────────────────┐
│ Edit Field: status                                                  [×]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ [General] [Options] [Display] [Validation]                                  │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ Field Key *                         Label *                             │ │
│ │ ┌───────────────────────────┐      ┌───────────────────────────┐       │ │
│ │ │ status                    │      │ Status                    │       │ │
│ │ └───────────────────────────┘      └───────────────────────────┘       │ │
│ │                                                                         │ │
│ │ Field Type *                                                            │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Select (Single Choice)                                            ▼ │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Options (one per line)                                                  │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ draft|Draft                                                         │ │ │
│ │ │ pending|Pending                                                     │ │ │
│ │ │ paid|Paid                                                           │ │ │
│ │ │ overdue|Overdue                                                     │ │ │
│ │ │ cancelled|Cancelled                                                 │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ Default Value                                                           │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ draft                                                               │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ ☑ Required field                                                       │ │
│ │ ☑ Show in list view                                                    │ │
│ │ ☑ Enable filtering                                                     │ │
│ │ ☐ Enable sorting                                                       │ │
│ │                                                                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                              [Cancel] [Delete] [Save Field] │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 5: Import Interface

### Purpose
Import records from CSV, Excel, or JSON files with field mapping and validation.

### URL
`/admin/{entity}/import`

### Wireframe
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Import Invoices                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ Step 2 of 4: Map Fields                                                     │
│ ═══════════════════════════════════════════════════════════════════════════ │
│ [1. Upload] ─── [2. Map Fields] ─── [3. Validate] ─── [4. Import]           │
│     ✓              ●                    ○                  ○                │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ File: invoices_december.csv (156 rows detected)                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ CSV Column          │ Maps To             │ Sample Data                 │ │
│ ├─────────────────────┼─────────────────────┼─────────────────────────────┤ │
│ │ inv_number          │ [number         ▼]  │ INV-001, INV-002, INV-003   │ │
│ │ client_name         │ [customer_id    ▼]  │ Acme Corp, Tech Sol...      │ │
│ │ invoice_date        │ [issue_date     ▼]  │ 2024-12-01, 2024-12-02      │ │
│ │ due                 │ [due_date       ▼]  │ 2024-12-31, 2025-01-01      │ │
│ │ amount              │ [total          ▼]  │ 1250.00, 3400.00            │ │
│ │ state               │ [status         ▼]  │ pending, paid               │ │
│ │ project             │ [project_code   ▼]  │ PRJ-001, PRJ-002            │ │
│ │ comments            │ [notes          ▼]  │ First invoice, Rush...      │ │
│ │ extra_col           │ [-- Skip --     ▼]  │ ...                         │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│ Options:                                                                    │
│ ☑ Skip first row (header)                                                  │
│ ☐ Update existing records (match by: number)                               │
│ ☐ Send notifications after import                                          │
│                                                                             │
│                                               [← Back] [Validate & Preview] │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Common Components

### Field Renderer

```blade
{{-- resources/views/components/entity/field-renderer.blade.php --}}
@props(['field', 'value' => null, 'mode' => 'edit'])

@php
    $component = match($field['type']) {
        'text', 'string' => 'input-text',
        'number', 'integer', 'decimal' => 'input-number',
        'currency' => 'input-currency',
        'date' => 'input-date',
        'datetime' => 'input-datetime',
        'time' => 'input-time',
        'select' => 'input-select',
        'multiselect' => 'input-multiselect',
        'checkbox' => 'input-checkbox',
        'toggle' => 'input-toggle',
        'textarea' => 'input-textarea',
        'richtext' => 'input-richtext',
        'file' => 'input-file',
        'image' => 'input-image',
        'relation' => 'input-relation',
        'json' => 'input-json',
        'color' => 'input-color',
        'computed' => 'display-computed',
        default => 'input-text',
    };
@endphp

@if($mode === 'view')
    <x-entity.field-display :field="$field" :value="$value" />
@else
    <x-dynamic-component 
        :component="$component"
        :field="$field"
        :value="$value"
        :name="$field['key']"
    />
@endif
```

### Filter Panel

```blade
{{-- resources/views/components/entity/filter-panel.blade.php --}}
@props(['fields', 'activeFilters' => []])

<div x-data="filterPanel(@js($activeFilters))" class="filter-panel">
    <div class="filter-panel__header">
        <h3>Filters</h3>
        <button @click="clearAll()" x-show="hasFilters" class="text-sm text-gray-500">
            Clear All
        </button>
    </div>
    
    <div class="filter-panel__content">
        @foreach($fields as $field)
            @if($field['filterable'] ?? false)
                <div class="filter-group">
                    <label class="filter-group__label">{{ $field['label'] }}</label>
                    
                    @switch($field['filter_type'] ?? $field['type'])
                        @case('select')
                        @case('multiselect')
                            <select x-model="filters.{{ $field['key'] }}" class="filter-input">
                                <option value="">Any</option>
                                @foreach($field['options'] as $value => $label)
                                    <option value="{{ $value }}">{{ $label }}</option>
                                @endforeach
                            </select>
                            @break
                            
                        @case('date')
                        @case('datetime')
                            <div class="filter-date-range">
                                <input type="date" x-model="filters.{{ $field['key'] }}_from" placeholder="From">
                                <input type="date" x-model="filters.{{ $field['key'] }}_to" placeholder="To">
                            </div>
                            @break
                            
                        @case('number')
                        @case('currency')
                            <div class="filter-number-range">
                                <input type="number" x-model="filters.{{ $field['key'] }}_min" placeholder="Min">
                                <input type="number" x-model="filters.{{ $field['key'] }}_max" placeholder="Max">
                            </div>
                            @break
                            
                        @case('boolean')
                            <select x-model="filters.{{ $field['key'] }}" class="filter-input">
                                <option value="">Any</option>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                            @break
                            
                        @default
                            <input type="text" 
                                   x-model="filters.{{ $field['key'] }}" 
                                   placeholder="Filter..."
                                   class="filter-input">
                    @endswitch
                </div>
            @endif
        @endforeach
    </div>
    
    <div class="filter-panel__footer">
        <button @click="apply()" class="btn btn-primary btn-sm">Apply Filters</button>
    </div>
</div>
```

### Bulk Actions

```blade
{{-- resources/views/components/entity/bulk-actions.blade.php --}}
@props(['actions', 'entity'])

<div x-data="bulkActions()" class="bulk-actions">
    <span class="bulk-actions__count">
        <span x-text="selectedCount"></span> selected
    </span>
    
    <select x-model="selectedAction" class="bulk-actions__select">
        <option value="">Select action...</option>
        @foreach($actions as $action)
            @if(auth()->user()->can($action['permission'] ?? "{$entity}.{$action['key']}"))
                <option value="{{ $action['key'] }}">{{ $action['label'] }}</option>
            @endif
        @endforeach
    </select>
    
    <button @click="execute()" 
            :disabled="!selectedAction || selectedCount === 0"
            class="btn btn-secondary btn-sm">
        Apply
    </button>
</div>
```
