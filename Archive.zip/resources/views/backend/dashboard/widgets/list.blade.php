{{-- List Widget Component --}}
<div class="widget-list-items" data-widget-id="{{ $widget->widget_id }}">
    {{-- List items will be loaded via AJAX --}}
    <div class="list-placeholder">
        <span>Loading items...</span>
    </div>
</div>
