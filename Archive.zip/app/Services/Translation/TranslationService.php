<?php

declare(strict_types=1);

namespace App\Services\Translation;

use App\Models\Translation;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Model;

/**
 * Translation Service - Handles internationalization.
 * 
 * Features:
 * - Model field translations
 * - View label translations
 * - Selection option translations
 * - Menu translations
 * - Code string translations
 * - PO file import/export
 * - Cache management
 */
class TranslationService
{
    /**
     * Cache prefix for translations.
     */
    protected const CACHE_PREFIX = 'translations:';

    /**
     * Cache TTL in seconds.
     */
    protected int $cacheTtl = 3600;

    /**
     * Current tenant ID.
     */
    protected ?int $tenantId = null;

    /**
     * Loaded translations cache.
     */
    protected array $loadedTranslations = [];

    /**
     * Supported languages.
     */
    protected array $supportedLanguages = [
        'en' => 'English',
        'ar' => 'العربية',
        'fr' => 'Français',
        'es' => 'Español',
        'de' => 'Deutsch',
        'zh' => '中文',
        'ja' => '日本語',
        'pt' => 'Português',
        'ru' => 'Русский',
        'it' => 'Italiano',
    ];

    /**
     * Set tenant context.
     */
    public function setTenant(?int $tenantId): self
    {
        $this->tenantId = $tenantId;
        return $this;
    }

    /**
     * Get current language.
     */
    public function getCurrentLang(): string
    {
        return App::getLocale();
    }

    /**
     * Set current language.
     */
    public function setLang(string $lang): void
    {
        App::setLocale($lang);
    }

    /**
     * Get supported languages.
     */
    public function getSupportedLanguages(): array
    {
        return $this->supportedLanguages;
    }

    /**
     * Add a supported language.
     */
    public function addLanguage(string $code, string $name): void
    {
        $this->supportedLanguages[$code] = $name;
    }

    /**
     * Translate a string.
     */
    public function translate(
        string $source,
        ?string $lang = null,
        string $type = Translation::TYPE_CODE,
        ?string $module = null
    ): string {
        $lang = $lang ?? $this->getCurrentLang();
        
        // English is typically the source language
        if ($lang === 'en') {
            return $source;
        }

        $cacheKey = $this->getCacheKey($type, $source, $lang, $module);
        
        // Check memory cache first
        if (isset($this->loadedTranslations[$cacheKey])) {
            return $this->loadedTranslations[$cacheKey];
        }

        // Check persistent cache
        $translation = Cache::remember($cacheKey, $this->cacheTtl, function () use ($source, $lang, $type, $module) {
            $query = Translation::forLang($lang)
                ->ofType($type)
                ->where('source', $source)
                ->forTenant($this->tenantId);

            if ($module) {
                $query->forModule($module);
            }

            return $query->value('value');
        });

        $result = $translation ?: $source;
        $this->loadedTranslations[$cacheKey] = $result;

        return $result;
    }

    /**
     * Shorthand for translate.
     */
    public function __(string $source, ?string $lang = null): string
    {
        return $this->translate($source, $lang);
    }

    /**
     * Translate a model field value.
     */
    public function translateField(
        Model $model,
        string $field,
        ?string $lang = null
    ): ?string {
        $lang = $lang ?? $this->getCurrentLang();
        
        if ($lang === 'en') {
            return $model->$field;
        }

        $modelName = get_class($model);
        $name = "{$modelName},{$field}";

        $translation = Translation::forLang($lang)
            ->ofType(Translation::TYPE_MODEL)
            ->forName($name)
            ->forResource($model->getKey())
            ->forTenant($this->tenantId)
            ->value('value');

        return $translation ?: $model->$field;
    }

    /**
     * Translate a field label.
     */
    public function translateFieldLabel(
        string $entityName,
        string $fieldName,
        ?string $lang = null
    ): string {
        $lang = $lang ?? $this->getCurrentLang();
        
        $source = $this->humanize($fieldName);
        
        if ($lang === 'en') {
            return $source;
        }

        $name = "{$entityName},{$fieldName}";
        
        $translation = Translation::forLang($lang)
            ->ofType(Translation::TYPE_FIELD)
            ->forName($name)
            ->forTenant($this->tenantId)
            ->value('value');

        return $translation ?: $source;
    }

    /**
     * Translate selection options.
     */
    public function translateSelection(
        string $entityName,
        string $fieldName,
        array $options,
        ?string $lang = null
    ): array {
        $lang = $lang ?? $this->getCurrentLang();
        
        if ($lang === 'en') {
            return $options;
        }

        $translated = [];
        foreach ($options as $key => $label) {
            $name = "{$entityName},{$fieldName},{$key}";
            
            $translation = Translation::forLang($lang)
                ->ofType(Translation::TYPE_SELECTION)
                ->forName($name)
                ->forTenant($this->tenantId)
                ->value('value');

            $translated[$key] = $translation ?: $label;
        }

        return $translated;
    }

    /**
     * Translate a view definition.
     */
    public function translateView(array $viewDefinition, ?string $lang = null): array
    {
        $lang = $lang ?? $this->getCurrentLang();
        
        if ($lang === 'en') {
            return $viewDefinition;
        }

        return $this->translateViewRecursive($viewDefinition, $lang);
    }

    /**
     * Recursively translate view elements.
     */
    protected function translateViewRecursive(array $element, string $lang): array
    {
        // Translate label if present
        if (isset($element['label'])) {
            $element['label'] = $this->translate($element['label'], $lang, Translation::TYPE_VIEW);
        }

        // Translate placeholder if present
        if (isset($element['placeholder'])) {
            $element['placeholder'] = $this->translate($element['placeholder'], $lang, Translation::TYPE_VIEW);
        }

        // Translate help text if present
        if (isset($element['help'])) {
            $element['help'] = $this->translate($element['help'], $lang, Translation::TYPE_VIEW);
        }

        // Translate button text
        if (isset($element['text'])) {
            $element['text'] = $this->translate($element['text'], $lang, Translation::TYPE_VIEW);
        }

        // Recursively translate children
        if (isset($element['children']) && is_array($element['children'])) {
            foreach ($element['children'] as $i => $child) {
                $element['children'][$i] = $this->translateViewRecursive($child, $lang);
            }
        }

        // Translate fields
        if (isset($element['fields']) && is_array($element['fields'])) {
            foreach ($element['fields'] as $i => $field) {
                $element['fields'][$i] = $this->translateViewRecursive($field, $lang);
            }
        }

        // Translate columns
        if (isset($element['columns']) && is_array($element['columns'])) {
            foreach ($element['columns'] as $i => $column) {
                $element['columns'][$i] = $this->translateViewRecursive($column, $lang);
            }
        }

        return $element;
    }

    /**
     * Set a translation.
     */
    public function setTranslation(
        string $source,
        string $value,
        string $lang,
        string $type = Translation::TYPE_CODE,
        ?string $module = null,
        ?int $resId = null,
        ?string $name = null
    ): Translation {
        $data = [
            'type' => $type,
            'name' => $name ?? $source,
            'lang' => $lang,
            'source' => $source,
        ];

        if ($resId) {
            $data['res_id'] = $resId;
        }

        $translation = Translation::updateOrCreate(
            array_merge($data, ['tenant_id' => $this->tenantId]),
            [
                'value' => $value,
                'module' => $module,
                'state' => 'translated',
            ]
        );

        // Clear cache
        $this->clearCache($type, $source, $lang, $module);

        return $translation;
    }

    /**
     * Set field translation.
     */
    public function setFieldTranslation(
        Model $model,
        string $field,
        string $value,
        string $lang
    ): Translation {
        $modelName = get_class($model);
        $name = "{$modelName},{$field}";
        
        return $this->setTranslation(
            $model->$field,
            $value,
            $lang,
            Translation::TYPE_MODEL,
            null,
            $model->getKey(),
            $name
        );
    }

    /**
     * Import translations from PO file.
     */
    public function importPo(string $filePath, string $lang, ?string $module = null): array
    {
        $content = file_get_contents($filePath);
        $translations = $this->parsePo($content);
        
        $imported = 0;
        $errors = [];

        foreach ($translations as $entry) {
            if (empty($entry['msgid']) || empty($entry['msgstr'])) {
                continue;
            }

            try {
                $this->setTranslation(
                    $entry['msgid'],
                    $entry['msgstr'],
                    $lang,
                    Translation::TYPE_CODE,
                    $module
                );
                $imported++;
            } catch (\Throwable $e) {
                $errors[] = "Failed to import '{$entry['msgid']}': {$e->getMessage()}";
            }
        }

        return [
            'imported' => $imported,
            'errors' => $errors,
        ];
    }

    /**
     * Parse PO file content.
     */
    protected function parsePo(string $content): array
    {
        $translations = [];
        $current = [];
        $lines = explode("\n", $content);
        $multilineKey = null;

        foreach ($lines as $line) {
            $line = trim($line);
            
            // Skip comments and empty lines
            if (empty($line) || str_starts_with($line, '#')) {
                if (!empty($current)) {
                    $translations[] = $current;
                    $current = [];
                }
                $multilineKey = null;
                continue;
            }

            // msgid
            if (str_starts_with($line, 'msgid ')) {
                $current['msgid'] = $this->extractPoString($line, 'msgid ');
                $multilineKey = 'msgid';
                continue;
            }

            // msgstr
            if (str_starts_with($line, 'msgstr ')) {
                $current['msgstr'] = $this->extractPoString($line, 'msgstr ');
                $multilineKey = 'msgstr';
                continue;
            }

            // Multiline continuation
            if (str_starts_with($line, '"') && $multilineKey) {
                $current[$multilineKey] .= $this->extractPoString($line, '');
            }
        }

        if (!empty($current)) {
            $translations[] = $current;
        }

        return $translations;
    }

    /**
     * Extract string from PO line.
     */
    protected function extractPoString(string $line, string $prefix): string
    {
        $str = substr($line, strlen($prefix));
        $str = trim($str, '"');
        
        // Unescape
        $str = str_replace(['\\n', '\\"', '\\\\'], ["\n", '"', '\\'], $str);
        
        return $str;
    }

    /**
     * Export translations to PO file.
     */
    public function exportPo(
        string $lang,
        ?string $module = null,
        ?string $type = null
    ): string {
        $query = Translation::forLang($lang)->forTenant($this->tenantId);
        
        if ($module) {
            $query->forModule($module);
        }
        
        if ($type) {
            $query->ofType($type);
        }

        $translations = $query->get();
        
        $output = [];
        $output[] = '# Translation file';
        $output[] = '# Language: ' . $lang;
        $output[] = '# Generated: ' . now()->toIso8601String();
        $output[] = 'msgid ""';
        $output[] = 'msgstr ""';
        $output[] = '"Content-Type: text/plain; charset=UTF-8\\n"';
        $output[] = '"Language: ' . $lang . '\\n"';
        $output[] = '';

        foreach ($translations as $translation) {
            $output[] = $this->formatPoEntry($translation);
        }

        return implode("\n", $output);
    }

    /**
     * Format a PO entry.
     */
    protected function formatPoEntry(Translation $translation): string
    {
        $lines = [];
        
        // Add comment with context
        $lines[] = "#. Type: {$translation->type}";
        if ($translation->name !== $translation->source) {
            $lines[] = "#. Name: {$translation->name}";
        }
        if ($translation->module) {
            $lines[] = "#. Module: {$translation->module}";
        }

        // msgid
        $lines[] = 'msgid ' . $this->escapePoString($translation->source);
        
        // msgstr
        $lines[] = 'msgstr ' . $this->escapePoString($translation->value ?? '');
        
        $lines[] = '';

        return implode("\n", $lines);
    }

    /**
     * Escape string for PO format.
     */
    protected function escapePoString(string $str): string
    {
        $str = str_replace(['\\', '"', "\n"], ['\\\\', '\\"', '\\n'], $str);
        return '"' . $str . '"';
    }

    /**
     * Get untranslated strings.
     */
    public function getUntranslated(
        string $lang,
        ?string $module = null,
        ?string $type = null
    ): \Illuminate\Database\Eloquent\Collection {
        $query = Translation::forLang($lang)
            ->forTenant($this->tenantId)
            ->where(function ($q) {
                $q->whereNull('value')
                    ->orWhere('value', '')
                    ->orWhere('state', 'to_translate');
            });
        
        if ($module) {
            $query->forModule($module);
        }
        
        if ($type) {
            $query->ofType($type);
        }

        return $query->get();
    }

    /**
     * Sync translations from source code/entities.
     */
    public function syncFromSource(string $module, array $sources): array
    {
        $created = 0;
        $updated = 0;

        foreach ($sources as $source) {
            foreach ($this->supportedLanguages as $lang => $name) {
                if ($lang === 'en') {
                    continue; // Skip source language
                }

                $existing = Translation::forLang($lang)
                    ->forModule($module)
                    ->where('source', $source['source'])
                    ->forTenant($this->tenantId)
                    ->first();

                if (!$existing) {
                    Translation::create([
                        'tenant_id' => $this->tenantId,
                        'type' => $source['type'] ?? Translation::TYPE_CODE,
                        'name' => $source['name'] ?? $source['source'],
                        'lang' => $lang,
                        'source' => $source['source'],
                        'value' => null,
                        'module' => $module,
                        'state' => 'to_translate',
                    ]);
                    $created++;
                } else {
                    // Update source if changed
                    if ($existing->source !== $source['source']) {
                        $existing->source = $source['source'];
                        $existing->state = 'to_translate';
                        $existing->save();
                        $updated++;
                    }
                }
            }
        }

        return [
            'created' => $created,
            'updated' => $updated,
        ];
    }

    /**
     * Bulk translate using callback (e.g., AI translation service).
     */
    public function bulkTranslate(
        string $lang,
        callable $translator,
        ?string $module = null,
        int $batchSize = 50
    ): array {
        $translated = 0;
        $errors = [];

        $untranslated = $this->getUntranslated($lang, $module);
        
        foreach ($untranslated->chunk($batchSize) as $batch) {
            $sources = $batch->pluck('source')->toArray();
            
            try {
                $translations = $translator($sources, $lang);
                
                foreach ($batch as $i => $record) {
                    if (isset($translations[$i]) && !empty($translations[$i])) {
                        $record->value = $translations[$i];
                        $record->state = 'translated';
                        $record->save();
                        $translated++;
                    }
                }
            } catch (\Throwable $e) {
                $errors[] = "Batch translation failed: {$e->getMessage()}";
                Log::error('Bulk translation error', [
                    'lang' => $lang,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return [
            'translated' => $translated,
            'errors' => $errors,
        ];
    }

    /**
     * Clear translation cache.
     */
    public function clearCache(
        ?string $type = null,
        ?string $source = null,
        ?string $lang = null,
        ?string $module = null
    ): void {
        if ($type && $source && $lang) {
            $cacheKey = $this->getCacheKey($type, $source, $lang, $module);
            Cache::forget($cacheKey);
            unset($this->loadedTranslations[$cacheKey]);
        } else {
            // Clear all translation cache
            if (method_exists(Cache::getStore(), 'tags')) {
                Cache::tags(['translations'])->flush();
            }
            $this->loadedTranslations = [];
        }
    }

    /**
     * Get cache key for a translation.
     */
    protected function getCacheKey(
        string $type,
        string $source,
        string $lang,
        ?string $module
    ): string {
        $key = self::CACHE_PREFIX . md5("{$type}:{$source}:{$lang}:{$module}:{$this->tenantId}");
        return $key;
    }

    /**
     * Convert snake_case to human-readable.
     */
    protected function humanize(string $str): string
    {
        return ucfirst(str_replace('_', ' ', $str));
    }

    /**
     * Get translation statistics.
     */
    public function getStats(?string $module = null): array
    {
        $stats = [];

        foreach ($this->supportedLanguages as $lang => $name) {
            if ($lang === 'en') {
                continue;
            }

            $query = Translation::forLang($lang)->forTenant($this->tenantId);
            
            if ($module) {
                $query->forModule($module);
            }

            $total = (clone $query)->count();
            $translated = (clone $query)->where('state', 'translated')->count();
            $pending = $total - $translated;

            $stats[$lang] = [
                'name' => $name,
                'total' => $total,
                'translated' => $translated,
                'pending' => $pending,
                'percentage' => $total > 0 ? round(($translated / $total) * 100, 1) : 0,
            ];
        }

        return $stats;
    }
}
