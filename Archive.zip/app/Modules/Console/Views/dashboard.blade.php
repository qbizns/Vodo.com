@extends('console::layouts.app', [
    'currentPage' => 'dashboard',
    'currentPageLabel' => 'Dashboard',
    'currentPageIcon' => 'layoutDashboard',
    'hidePageTitle' => true,
])

@section('page-title', 'Dashboard')

@section('page-content')
@include('backend.dashboard.index', [
    'widgets' => $widgets,
    'unusedWidgets' => $unusedWidgets,
    'currentDashboard' => $currentDashboard,
])
@endsection
