<?php

declare(strict_types=1);

namespace App\Providers;

use App\Services\Translation\TranslationService;
use Illuminate\Support\ServiceProvider;

/**
 * Translation Service Provider.
 */
class TranslationServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->singleton(TranslationService::class, function ($app) {
            return new TranslationService();
        });

        // Register helper function
        if (!function_exists('__t')) {
            /**
             * Translate a string using TranslationService.
             */
            function __t(string $source, ?string $lang = null): string
            {
                return app(TranslationService::class)->translate($source, $lang);
            }
        }
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        // Set tenant context from authenticated user
        $this->app->resolving(TranslationService::class, function (TranslationService $service, $app) {
            if ($user = $app['auth']->user()) {
                $tenantId = $user->tenant_id ?? null;
                $service->setTenant($tenantId);
            }
        });
    }
}
