
<div class="widget-quick-actions">
    <div class="quick-action-grid">
        <a href="/system/settings" class="quick-action-item">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'settings'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>Settings</span>
        </a>
        <a href="/system/plugins" class="quick-action-item">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'plug'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>Plugins</span>
        </a>
        <a href="/navigation-board" class="quick-action-item">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'layoutGrid'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>Navigation</span>
        </a>
        <a href="/users" class="quick-action-item">
            <?php echo $__env->make('backend.partials.icon', ['icon' => 'users'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>Users</span>
        </a>
    </div>
</div>
<?php /**PATH /var/www/resources/views/backend/dashboard/widgets/quick-actions.blade.php ENDPATH**/ ?>