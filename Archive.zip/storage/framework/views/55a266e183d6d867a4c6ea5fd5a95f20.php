<?php $__env->startSection('plugin-title', 'Hello World'); ?>

<?php $__env->startSection('plugin-header', 'Hello World'); ?>

<?php $__env->startSection('plugin-header-actions'); ?>
    <a href="<?php echo e(route('plugins.hello-world.greetings')); ?>" class="plugin-btn plugin-btn-primary">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
        </svg>
        View Greetings
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin-content'); ?>
    <div class="plugin-stats">
        <div class="plugin-stat-card">
            <div class="plugin-stat-value"><?php echo e($greetingsCount); ?></div>
            <div class="plugin-stat-label">Total Greetings</div>
        </div>
        <div class="plugin-stat-card">
            <div class="plugin-stat-value"><?php echo e($plugin->version); ?></div>
            <div class="plugin-stat-label">Plugin Version</div>
        </div>
        <div class="plugin-stat-card">
            <div class="plugin-stat-value"><?php echo e($plugin->isActive() ? 'Active' : 'Inactive'); ?></div>
            <div class="plugin-stat-label">Status</div>
        </div>
    </div>

    <div class="plugin-card" style="margin-top: var(--spacing-6);">
        <div class="plugin-card-header">
            <h3 class="plugin-card-title">Welcome Message</h3>
        </div>
        <div class="plugin-card-body">
            <div style="display: flex; align-items: center; gap: var(--spacing-4);">
                <div style="font-size: 64px;">👋</div>
                <div>
                    <h2 style="font-size: var(--text-2xl); color: var(--text-primary); margin-bottom: var(--spacing-2);">
                        <?php echo e($greeting); ?>

                    </h2>
                    <p style="color: var(--text-secondary);">
                        This is a demonstration of the Vodo plugin system capabilities.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="plugin-card">
        <div class="plugin-card-header">
            <h3 class="plugin-card-title">About This Plugin</h3>
        </div>
        <div class="plugin-card-body">
            <p style="line-height: 1.7; color: var(--text-secondary);">
                The Hello World plugin demonstrates the core capabilities of the Vodo plugin system:
            </p>
            <ul style="margin-top: var(--spacing-4); margin-left: var(--spacing-6); color: var(--text-secondary); line-height: 2;">
                <li><strong>Routes:</strong> Custom routes prefixed with <code>/plugins/hello-world</code></li>
                <li><strong>Views:</strong> Blade templates with plugin namespace</li>
                <li><strong>Migrations:</strong> Database migrations for plugin data</li>
                <li><strong>Models:</strong> Eloquent models for data management</li>
                <li><strong>Navigation:</strong> Sidebar menu integration</li>
                <li><strong>Hooks:</strong> Action and filter hooks for extensibility</li>
            </ul>
        </div>
    </div>

    <div class="plugin-card">
        <div class="plugin-card-header">
            <h3 class="plugin-card-title">Plugin Information</h3>
        </div>
        <div class="plugin-card-body">
            <table class="plugin-table">
                <tr>
                    <th style="width: 200px;">Name</th>
                    <td><?php echo e($plugin->name); ?></td>
                </tr>
                <tr>
                    <th>Slug</th>
                    <td><code><?php echo e($plugin->slug); ?></code></td>
                </tr>
                <tr>
                    <th>Version</th>
                    <td><?php echo e($plugin->version); ?></td>
                </tr>
                <tr>
                    <th>Author</th>
                    <td><?php echo e($plugin->author ?? 'Vodo'); ?></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><?php echo e($plugin->description); ?></td>
                </tr>
                <tr>
                    <th>Activated At</th>
                    <td><?php echo e($plugin->activated_at?->format('F j, Y, g:i a') ?? 'Not activated'); ?></td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-styles'); ?>
<style>
    code {
        background: var(--bg-surface-1);
        padding: 2px 6px;
        border-radius: var(--radius-sm);
        font-family: monospace;
        font-size: 0.9em;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('hello-world::layouts.plugin', [
    'currentPage' => 'hello-world',
    'currentPageLabel' => 'Hello World',
    'currentPageIcon' => 'smile',
    'pageTitle' => 'Hello World',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Plugins/hello-world/Views/index.blade.php ENDPATH**/ ?>