<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('page-content'); ?>
<?php echo $__env->make('backend.dashboard.index', [
    'widgets' => $widgets,
    'unusedWidgets' => $unusedWidgets,
    'currentDashboard' => $currentDashboard,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.app', [
    'currentPage' => 'dashboard',
    'currentPageLabel' => 'Dashboard',
    'currentPageIcon' => 'layoutDashboard',
    'hidePageTitle' => true,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/dashboard.blade.php ENDPATH**/ ?>