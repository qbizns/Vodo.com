
<div class="widget-stats">
    <div class="stats-items" data-widget-id="<?php echo e($widget->widget_id); ?>">
        
        <div class="stats-placeholder">
            <span>Loading statistics...</span>
        </div>
    </div>
</div>
<?php /**PATH /var/www/resources/views/backend/dashboard/widgets/stats.blade.php ENDPATH**/ ?>