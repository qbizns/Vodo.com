<?php $__env->startSection('login-title'); ?>
    <?php echo $__env->yieldContent('page-login-title', 'Sign in'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('login-subtitle'); ?>
    <?php echo $__env->yieldContent('page-login-subtitle', 'Welcome back to Vodo Admin'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldContent('page-content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.guest', [
    'brandName' => 'Vodo Admin',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/layouts/guest.blade.php ENDPATH**/ ?>