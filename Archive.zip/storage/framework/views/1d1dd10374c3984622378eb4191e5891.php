


<div class="dashboard-page" data-dashboard="<?php echo e($currentDashboard); ?>">
    
    <div class="widget-grid" id="widgetGrid">
        <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('backend.dashboard.widgets.wrapper', ['widget' => $widget], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php if($widgets->isEmpty()): ?>
        <div class="dashboard-empty">
            <div class="dashboard-empty-icon">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'layoutDashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <h3>No Widgets</h3>
            <p>Add widgets to customize your dashboard.</p>
            <?php if(count($unusedWidgets ?? []) > 0): ?>
                <button type="button" class="btn-primary" id="addFirstWidgetBtn">
                    <?php echo $__env->make('backend.partials.icon', ['icon' => 'plus'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    Add Widget
                </button>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>


<?php echo $__env->make('backend.dashboard.partials.add-widget-modal', ['unusedWidgets' => $unusedWidgets ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('backend.dashboard.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('backend.dashboard.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /var/www/resources/views/backend/dashboard/index.blade.php ENDPATH**/ ?>