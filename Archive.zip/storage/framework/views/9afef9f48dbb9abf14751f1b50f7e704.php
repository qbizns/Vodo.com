<?php $__env->startSection('page-title', ($currentPlugin['title'] ?? 'Plugin Dashboard')); ?>

<?php $__env->startSection('page-content'); ?>
<?php echo $__env->make('backend.dashboard.index', [
    'widgets' => $widgets,
    'unusedWidgets' => $unusedWidgets,
    'currentDashboard' => $currentDashboard,
    'currentPlugin' => $currentPlugin ?? null,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.app', [
    'currentPage' => 'dashboard',
    'currentPageLabel' => ($currentPlugin['title'] ?? 'Plugin Dashboard'),
    'currentPageIcon' => ($currentPlugin['icon'] ?? 'layoutDashboard'),
    'hidePageTitle' => true,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/app/Modules/Admin/Views/dashboard-plugin.blade.php ENDPATH**/ ?>