


<div class="settings-container">
    
    <div class="settings-sidebar">
        
        <nav class="settings-nav">
            
            <a href="?section=general" 
               class="settings-nav-item <?php echo e($activeSection === 'general' ? 'active' : ''); ?>"
               data-section="general">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'settings'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <span>General Settings</span>
            </a>

            
            <?php if(count($pluginsWithSettings) > 0): ?>
                <div class="settings-nav-divider" style="display: none !important; visibility: hidden;">
                    <span>Plugins</span>
                </div>
                
                <?php $__currentLoopData = $pluginsWithSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plugin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="?section=plugin:<?php echo e($plugin['slug']); ?>" 
                       class="settings-nav-item <?php echo e($activeSection === 'plugin:' . $plugin['slug'] ? 'active' : ''); ?>"
                       data-section="plugin:<?php echo e($plugin['slug']); ?>">
                        <?php echo $__env->make('backend.partials.icon', ['icon' => $plugin['icon']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <span><?php echo e($plugin['name']); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </nav>
    </div>

    
    <div class="settings-content">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'checkCircle'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <span><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-error">
                <?php echo $__env->make('backend.partials.icon', ['icon' => 'alertCircle'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <span><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <div id="settingsContent">
            <?php if($sectionContent['type'] === 'general'): ?>
                <?php echo $__env->make('backend.settings.partials.general', [
                    'definitions' => $sectionContent['definitions'],
                    'values' => $sectionContent['values'],
                    'saveUrl' => $sectionContent['saveUrl'],
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif($sectionContent['type'] === 'plugin'): ?>
                <?php echo $__env->make('backend.settings.partials.plugin', [
                    'slug' => $sectionContent['slug'],
                    'name' => $sectionContent['name'] ?? null,
                    'fields' => $sectionContent['fields'],
                    'values' => $sectionContent['values'],
                    'saveUrl' => $sectionContent['saveUrl'],
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php echo $__env->make('backend.settings.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('backend.settings.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /var/www/resources/views/backend/settings/index.blade.php ENDPATH**/ ?>